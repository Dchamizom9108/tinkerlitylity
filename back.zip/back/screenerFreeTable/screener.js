const dateInput = document.getElementById('date-input');
const epowerProxyURL = "https://bots.consumerlaw.com/proxy"
const epowerProxyGetSugarDataURL = "https://bots.consumerlaw.com/proxy_sugar_data"

let adjustedDate = new Date();
adjustedDate.setUTCHours(adjustedDate.getUTCHours() - 5);
let end = adjustedDate.toISOString().slice(0, 10);
dateInput.value = end;
let dataTable = [];

window.onload = function() {
	updateData(end);
}

dateInput.addEventListener('change', (event) => {
	let end = event.target.value;
	updateData(end);
});

const salesTable = new Tabulator("#sales-container", {
	data:dataTable,
	layout:"fitDataTable",
	columns: [
    {title:"Agent", field:"agent", hozAlign:"center", sorter:"string"},
    {
      title: "Month P1 Free",
      field: "total_leads",
      hozAlign: "center",
      sorter: "number",
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams){
      var ventas = cell.getValue();
      var diasTrabajados = end.split('-')[2];
      var ventasPromedio = ventas / diasTrabajados;					
      var color = "white";					
      if (ventasPromedio <= 1 && ventas < 45) {
        color = "#e41749";
        } else if (ventasPromedio < 2 && ventasPromedio > 1 && ventas < 45) {
        color = "#ff4b07";
        } else {
        color = "#00b300";
        }						
        return "<div style='background-color: " + color + "; color: white; font-weight: bold; height: 20px; width: 100%'>" + ventas + "</div>";
      }
    },
    {
      title: "Today", 
      titleFormatter: function(cell, formatterParams) {
        return end;
      },
      field: "today_total_leads", 
      hozAlign: "center", 
      sorter: "number", 
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams) {
        var sold = cell.getRow().getData().today_total_leads;
        if(sold == 0) {
          return "<div style='background-color: #e41749; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else if(sold == 1) {
          return "<div style='background-color: #f2a600; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else {
          return "<div style='background-color: #00b300; color: white; font-weight: bold;'>" + sold + "</div>";
        }
      }
    },
    // {
    //   title: "Month Engaged",
    //   field: "closed_leads",
    //   hozAlign: "center",
    //   sorter: "number",
    //   topCalc: "sum",
    //   headerSort: true,
    //   formatter: function(cell, formatterParams){
    //   var ventas = cell.getValue();
    //   var diasTrabajados = end.split('-')[2];
    //   var ventasPromedio = ventas / diasTrabajados;					
    //   var color = "white";					
    //   if (ventasPromedio <= 1 && ventas < 45) {
    //     color = "#e41749";
    //     } else if (ventasPromedio < 2 && ventasPromedio > 1 && ventas < 45) {
    //     color = "#ff4b07";
    //     } else {
    //     color = "#00b300";
    //     }						
    //     return "<div style='background-color: " + color + "; color: white; font-weight: bold; height: 20px; width: 100%'>" + ventas + "</div>";
    //   }
    // },
  ],
});

async function updateData(end) {
  try {
    const teamScreenersLocal = "0c225d22-cb69-11ee-8b72-dadc21ba0c54";
    const local = await getDataFromSugarTeam(teamScreenersLocal);
    const teamScreenersNational = "8d00bf60-cb69-11ee-96a7-dadc21ba0c54";
    const national = await getDataFromSugarTeam(teamScreenersNational);
    const teamScreeners = [...local, ...national];
    let start = getStartDate(end);

    const apiAllFromURLMonth = `https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_free_data&fechaInicio=${start}&fechaFin=${end}`;
    const apiAllFromURLToday = `https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_free_data&fechaInicio=${end}&fechaFin=${end}`;

    const monthDataP1 = await getDataGET(apiAllFromURLMonth)
    const todayDataP1 = await getDataGET(apiAllFromURLToday)

    const P1Today = groupAndCountLeads(todayDataP1);
    const P1Month = groupAndCountLeads(monthDataP1);

    // Obtener los IDs de los usuarios de teamP1
    const teamScreenersIds = teamScreeners.map(user => user.id);

    // Filtrar P1Today y P1Month para excluir los usuarios en teamP1
    const filteredP1Today = P1Today.filter((lead) => teamScreenersIds.includes(lead.user_id));
    const filteredP1Month = P1Month.filter((lead) => teamScreenersIds.includes(lead.user_id));
    console.log('filteredP1', filteredP1Today, filteredP1Month);

      // add user data
    let userMonthDataP1 = await addUserData(filteredP1Month, teamScreeners);
    userMonthDataP1 = userMonthDataP1.map(lead => {
      return {
        user_id: lead.user_id,
        agent: lead.fullname,
        closed_leads: lead.closed_leads,
        total_leads: lead.total_leads
      }
    })
    console.log('userMonthDataP1', userMonthDataP1);
    let userTodayDataP1 = await addUserData(filteredP1Today, teamScreeners);
    userTodayDataP1 = userTodayDataP1.map(lead => {
      return {
        user_id: lead.user_id,
        agent: lead.fullname,
        today_total_leads: lead.total_leads
      }
    })
    console.log('userTodayDataP1', userTodayDataP1);

    const result = userMonthDataP1.map(item1 => {
      const item2 = userTodayDataP1.find(item => item.agent === item1.agent); 
      return {
        ...item1,
        ...(item2 ? item2 : { today_total_leads: 0 }),
      };
    });	
    console.log('result', result);			  

    let finalData = result;
    // ordenar result por cantidad de p1
    finalData.sort((a, b) => {return b.closed_leads - a.closed_leads;});
    /////////////////////////////////////////START OF CODE/////////////////////////////////////////
    salesTable.setData(finalData);
    document.getElementById("download-xlsx").addEventListener("click", function(){
      salesTable.download("csv", "data.csv");
    });

  } catch (error) {
    console.error(error);
  }
}

function getStartDate (date) {
  const year = date.split("-")[0];
  const month = date.split("-")[1];
  const start = `${year}-${month}-01`;
  return start;
}

async function getDataGET(url) {
	return new Promise((resolve, reject) => {
		$.ajax({
			url: epowerProxyURL,
			method: "POST",
			timeout: 0,
			crossDomain: true,
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			data: JSON.stringify({
				parameters: {},
				url: `${url}`,
			}),
			success: function (response) {
				resolve(response);
			},
			error: function (xhr, status, error) {
				reject(
					new Error(`Error fetching data from ${url}. Status: ${status}`)
				);
			},
		});
	});
}

function groupAndCountLeads(p1Data) {
  const result = p1Data.reduce((acc, lead) => {
    const userId = lead.user_id;
    const status = lead.status;

    if (!acc[userId]) {
      acc[userId] = {
        user_id: userId,
        total_leads: 0,
        closed_leads: 0,
      };
    }

    acc[userId].total_leads += 1;

    if (status === "Engaged" || status === "Converted") {
      acc[userId].closed_leads += 1;
    }

    return acc;
  }, {});

  return Object.values(result);
}

async function getDataFromSugarTeam(teamId) {
  try {
    const usersBySugarTeamURLAPI = `https://home.justicialaboral.com/bot_db/api/get_users_by_team.php?teamId=${teamId}`;
    const datosConExtension = await getDataGET(usersBySugarTeamURLAPI);

    return datosConExtension;
  } catch (error) {
    console.error(error);
    return [];
  }
}

async function addUserData(data, users) {
  return data.map((item) => {
    const user = users.find((u) => u.id === item.user_id);
    if (user) {
      const { fullname, phone_ext_c } = user;
      return { ...item, fullname, phone_ext_c };
    } else {
      return item;
    }
  });
}