const puppeteer = require("puppeteer");
const mysql = require("mysql2");
const fs = require("fs");

const connection = mysql.createConnection({
  host: "137.184.226.50",
  user: "admin",
  password: "_1kK756!r(2NORK7",
  database: "logVar",
});

(async () => {
  let date = new Date();
  date.setUTCHours(date.getUTCHours() - 5);
  const isoDate = date.toISOString();
  // const isoDate = moment().subtract(10, "days").format("YYYY-MM-DD");
  console.log(isoDate);

  // const browser = await puppeteer.launch({
  //   headless: false,
  // });
  const browser = await puppeteer.launch({ args: ["--no-sandbox"]  });

  const page = await browser.newPage();
  await page.goto("https://consumerlaw.my3cx.us/#/app/queues");
  await page.type('input[ng-model="$ctrl.user.username"]', "666");
  await page.type('input[type="password"]', "@dm1nB0t23");
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  // const bucket1 = await getDataForQueue(904);
  const bucket2 = await getDataForQueue(905);

  await processDataForQueues(
    // bucket1, 
    bucket2, isoDate
  );

  await browser.close();

  async function getDataForQueue(queueNumber) {
    const activeUsersArray = [];

    const searchBar = await page.$("input[id='inputSearch']");
    await searchBar.focus();
    await page.keyboard.type(queueNumber.toString());

    await new Promise((r) => setTimeout(r, 500));

    const selectReport = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/list-control/div/div/div[2]/div/div[3]/table/tbody/tr/td[1]'
    );
    await selectReport[0].click();
    await new Promise((r) => setTimeout(r, 250));

    const editButton = await page.$("button[id='btnEdit']");
    await editButton.click();
    await new Promise((r) => setTimeout(r, 500));

    const agentsTab = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/ul/li[2]'
    );
    await agentsTab[0].click();
    await new Promise((r) => setTimeout(r, 1000));

    // Encontrar el elemento activo actual
    const activeElement = await page.$("div#pagerId ul li.ng-scope.active");
    const activePageNumber = await activeElement.evaluate((node) =>
      parseInt(node.textContent.trim())
    );

    // Iterar sobre cada número de página hasta el último
    let currentPage = activePageNumber;
    while (true) {
      // Esperar a que los datos de la página carguen completamente
      await page.waitForSelector("tbody tr");
      await new Promise((r) => setTimeout(r, 250));
      // Leer los datos de la página actual
      let actualTable = await page.$$("tbody tr");

      const extensions = await Promise.all(
        actualTable.map(async (tr) => {
          const phone = await tr.$("td:nth-child(2)");
          const firstnameE = await tr.$("td:nth-child(3)");
          const lastnameE = await tr.$("td:nth-child(4)");
          const ext = await phone.evaluate((node) => node.innerText);
          const fullname =
            (await firstnameE.evaluate((node) => node.innerText)) +
            " " +
            (await lastnameE.evaluate((node) => node.innerText));
          return { ext, fullname };
        })
      );

      activeUsersArray.push(...extensions);

      // Hacer clic en el siguiente enlace
      currentPage++;
      const nextPageButton = await page.$x(
        `//div[@id='pagerId']//li[contains(@class, 'ng-scope')]/a[text()='${currentPage}']`
      );
      if (nextPageButton.length === 0) {
        const cancelButton = await page.$("button[id='btnCancel']");
        const saveButton = await page.$("button[id='btnSave']");
        await cancelButton.click();
        await new Promise((r) => setTimeout(r, 500));
        break; // Si no hay más páginas, salir del bucle
      }
      await nextPageButton[0].click();
    }

    return activeUsersArray;
  }
})();

async function processDataForQueues(
  // data904, 
  data905, 
  isoDate
  ) {
  // const transformedData904 = transformData(data904, 904, isoDate);
  const transformedData905 = transformData(data905, 905, isoDate);

  // Combinar los datos transformados de ambos Q
  const combinedData = combineData(
    // transformedData904, 
    transformedData905
  );

  // fs.writeFileSync('combinedData.json', JSON.stringify(combinedData, null, 2));
  await clearOldData();
  // Insertar o actualizar los datos en la base de datos
  await insertDataToDatabase(combinedData);

  connection.end();
}

function transformData(agents, queue, dateChecked) {
  return agents.map((agent) => ({
    ext: agent.ext,
    fullname: agent.fullname,
    bottom_bucket_status: queue === 904 ? 1 : 0,
    top_bucket_status: queue === 905 ? 1 : 0,
    last_checked: dateChecked,
  }));
}

function combineData(
  // data904, 
  data905
) {
  const combinedData = [];
  const exts = new Set([
    // ...data904.map((agent) => agent.ext), 
    ...data905.map((agent) => agent.ext)
  ]);

  for (const ext of exts) {
    // const agent904 = data904.find((agent) => agent.ext === ext);
    const agent905 = data905.find((agent) => agent.ext === ext);

    // const bottom_bucket_status = agent904 ? 1 : 0;
    const bottom_bucket_status = agent905 ? 1 : 0;
    const top_bucket_status = agent905 ? 1 : 0;
    // const fullname = agent904 ? agent904.fullname : agent905.fullname;
    const fullname = agent905.fullname;

    combinedData.push({
      ext,
      fullname,
      bottom_bucket_status,
      top_bucket_status,
      last_checked: agent905 ? agent905.last_checked : 'null',
      // last_checked: agent904 ? agent904.last_checked : agent905.last_checked,
    });
  }

  return combinedData;
}

function getDifference(dataA, dataB) {
  return dataA.filter((agentA) => !dataB.some((agentB) => agentB.ext === agentA.ext));
}

async function insertDataToDatabase(data) {
  try {
    // Insertar o actualizar los datos en la base de datos
    const placeholders = data.map(() => "(?, ?, ?, ?, ?)").join(", ");
    const values = data.flatMap((item) => [
      item.ext,
      item.fullname,
      item.bottom_bucket_status,
      item.top_bucket_status,
      item.last_checked,
    ]);
    const sql = `
    INSERT INTO sales_q_status (ext, fullname, bottom_bucket_status, top_bucket_status, last_checked)
    VALUES ${placeholders}
    ON DUPLICATE KEY UPDATE
      fullname = VALUES(fullname),
      bottom_bucket_status = VALUES(bottom_bucket_status),
      top_bucket_status = VALUES(top_bucket_status),
      last_checked = VALUES(last_checked)
  `;
    const [result, fields] = await connection.promise().execute(sql, values);
    console.log(`Datos insertados o actualizados correctamente`);
  } catch (error) {
    console.error(
      "Error al insertar o actualizar datos en la base de datos:",
      error
    );
  }
}

async function clearOldData() {
  // busca todos los token existentes y coloca active = 0
  const sqlQuery = `DELETE FROM sales_q_status`;

  connection.query(sqlQuery, (error, results) => {
    if (error) {
      console.error("Error al eliminar los usuarios", error);
    } else {
      console.log("Usuarios desactivados correctamente");
    }
  });
}