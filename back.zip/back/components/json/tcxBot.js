const puppeteer = require("puppeteer");
const mysql = require("mysql2");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser"); // Paquete para procesar CSV
const moment = require("moment");

// Configuración de la conexión a la base de datos
const connection = mysql.createConnection({
  host: "137.184.226.50",
  user: "admin",
  password: "_1kK756!r(2NORK7",
  database: "daily",
});

// Función para procesar el CSV a JSON
async function processCsvToJson(filePath) {
  return new Promise((resolve, reject) => {
    const results = [];
    fs.createReadStream(filePath)
      .pipe(csv())
      .on("data", (data) => results.push(data))
      .on("end", () => resolve(results))
      .on("error", (error) => reject(error));
  });
}

(async () => {
  let date = new Date();
  date.setUTCHours(date.getUTCHours() - 5);
  const isoDate = date.toISOString().substring(0, 10);
  const time = date.toISOString().substring(11, 19);

  // Configurar una carpeta de descargas
  const downloadPath = path.resolve(__dirname, "downloads");
  if (!fs.existsSync(downloadPath)) {
    fs.mkdirSync(downloadPath);
  }

  const browser = await puppeteer.launch({
    args: ["--no-sandbox"],
    // headless: false,
    defaultViewport: null,
  });

  const page = await browser.newPage();

  // Configurar el comportamiento de descargas
  const client = await page.target().createCDPSession();
  await client.send("Page.setDownloadBehavior", {
    behavior: "allow",
    downloadPath: downloadPath,
  });

  await page.goto(
    "https://consumerlaw.my3cx.us/#/office/reports/extension-statistic"
  );
  await page.waitForSelector('input[id="loginInput"]');

  // Inicio de sesión
  await page.type('input[id="loginInput"]', "666");
  await new Promise((resolve) => setTimeout(resolve, 300));
  await page.type('input[id="passwordInput"]', "@dm1nB0t23");
  await new Promise((resolve) => setTimeout(resolve, 300));
  await page.click('button[type="submit"]');

  await new Promise((resolve) => setTimeout(resolve, 50000));

  await page.click('button[data-qa="export-report"]');
  console.log("click y descargando");

  await new Promise((resolve) => setTimeout(resolve, 40000));

  const files = fs.readdirSync(downloadPath);
  const csvFile = files.find((file) => file.endsWith(".csv"));
  if (!csvFile) {
    console.error("No se encontró ningún archivo CSV descargado.");
    await browser.close();
    return;
  }

  const csvFilePath = path.join(downloadPath, csvFile);
  let jsonData = await processCsvToJson(csvFilePath);

  const exportData = jsonData
    .map((row) => {
      return {
        agent: row["Agent Extension"],
        inboundAnswered: row["Inbound Answered"],
        inboundUnanswered: row["Inbound Unanswered"],
        outboundAnswered: row["Outbound Answered"],
        outboundUnanswered: row["Outbound Unanswered"],
        totalAnswered: row["Total Answered"],
        totalUnanswered: row["Total Unanswered"],
        totalTalkingTime: row["Total Talking Time"],
        data_date: isoDate,
        timeSet: time,
      };
    })
//    .filter((row) => {
//      return (
//        parseInt(row.totalUnanswered) > 0 || row.totalTalkingTime !== "00:00:00"
//      );
//   });



  async function insertData(tcxData, dataDate, timeSet) {
    console.log("Insertando tcx data", dataDate);
    return new Promise((resolve, reject) => {
      if (tcxData.length === 0) {
        console.log("No hay tcx data para insertar");
        return resolve();
      }

      function clearDuplicateData() {
        //Elimina los datos duplicados de la tabla data_wallboard
        const sqlQuery = `
        DELETE t1 FROM tcxFull t1
        INNER JOIN (
          SELECT data_date, agent, MAX(id) AS max_id
          FROM tcxFull
          GROUP BY data_date, agent
          HAVING COUNT(*) > 1
        ) t2
        ON t1.data_date = t2.data_date AND t1.agent = t2.agent AND t1.id < t2.max_id;
      `;
        connection.query(sqlQuery, (error, results) => {
          if (error) {
            console.error("Error al eliminar los datos duplicados:", error);
          } else {
            console.log("Datos duplicados eliminados correctamente");
          }
        });
      }
    
      clearDuplicateData();

      const sql = `INSERT INTO tcxFull (agent, data_date, inboundAnswered, inboundUnanswered, outboundAnswered, outboundUnanswered, totalAnswered, totalUnanswered, totalTalkingTime, timeSet) VALUES ?`;

      // Mapear los usuarios en un formato adecuado para la inserción
      const values = tcxData.map((data) => [
        data.agent,
        data.data_date,
        data.inboundAnswered,
        data.inboundUnanswered,
        data.outboundAnswered,
        data.outboundUnanswered,
        data.totalAnswered,
        data.totalUnanswered,
        data.totalTalkingTime,
        data.timeSet,
      ]);

      // Ejecutar la consulta SQL
      connection.query(
        sql,
        [values],
        (insertError, insertResults) => {
          if (insertError) {
            console.error(
              "Error al insertar los nuevos Second Voice:",
              insertError
            );
            return reject(insertError);
          }
          resolve();
        }
      );
    });
  }

  await new Promise((resolve) => setTimeout(resolve, 2000));

  // Insertar los datos en la base de datos
  insertData(exportData, isoDate, time).then(() => {
    console.log("Datos insertados correctamente");
    
  });

  function clearDuplicateData() {
    //Elimina los datos duplicados de la tabla data_wallboard
    const sqlQuery = `
    DELETE t1 FROM tcxFull t1
    INNER JOIN (
      SELECT data_date, agent, MAX(id) AS max_id
      FROM tcxFull
      GROUP BY data_date, agent
      HAVING COUNT(*) > 1
    ) t2
    ON t1.data_date = t2.data_date AND t1.agent = t2.agent AND t1.id < t2.max_id;
  `;
    connection.query(sqlQuery, (error, results) => {
      if (error) {
        console.error("Error al eliminar los datos duplicados:", error);
      } else {
        console.log("Datos duplicados eliminados correctamente");
      }
    });
  }

  clearDuplicateData();

  await new Promise((resolve) => setTimeout(resolve, 2000));

  // Eliminar el archivo CSV
  try {
    fs.unlinkSync(csvFilePath);
    console.log(`Archivo ${csvFile} eliminado correctamente.`);
  } catch (error) {
    console.error(`Error al eliminar el archivo ${csvFile}:`, error);
  }

  // Cerrar el navegador y la conexión a la base de datos
  await browser.close();
  connection.end();
})();
