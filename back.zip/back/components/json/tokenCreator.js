const mysql = require("mysql2");
const axios = require("axios");
const moment = require("moment");
const fs = require("fs");

const dateAsk = moment().format("YYYY-MM-DD");

const connection = mysql.createConnection({
  host: "137.184.226.50",
  user: "admin",
  password: "_1kK756!r(2NORK7",
  database: "logVar",
});

const user = "kennethp";
const password = "Sugar6232!";

console.log(user, password);

let data = JSON.stringify({
  username: `${user}`,
  password: `${password}`,
});

let config = {
  method: "post",
  maxBodyLength: Infinity,
  url: "https://bots.consumerlaw.com/proxy_sugar_token",
  headers: {
    "Content-Type": "application/json",
  },
  data: data,
};

axios
  .request(config)
  .then((response) => {
    console.log(response.data);
    const token = response.data;

    insertDataToDatabase(token, dateAsk);
  })
  .catch((error) => {
    console.error(error);
  });

function insertDataToDatabase(token, date) {
  clearOldToken();
  const sql = `INSERT INTO token (date_entered, active, token) VALUES (?, ?, ?)`;
  const values = [date, 1, token];

  connection.query(sql, values, (error, results) => {
    if (error) {
      console.error("Error al insertar el token:", error);
      connection.end();
      return;
    } else {
      console.log("Token insertados correctamente");
      connection.end();
      return;
    }
  });
}

function clearOldToken() {
  // busca todos los token existentes y coloca active = 0
  const sqlQuery = ` UPDATE token SET active = 0 `;

  connection.query(sqlQuery, (error, results) => {
    if (error) {
      console.error("Error al editar los token", error);
    } else {
      console.log("Tokens desactivados correctamente");
    }
  });
}
