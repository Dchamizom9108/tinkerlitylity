const mysql = require("mysql2");
const axios = require("axios");
const moment = require("moment");
// const fs = require("fs");

const endDate = moment().format("YYYY-MM-DD");
const startDate = moment().startOf("month").format("YYYY-MM-DD");

const epowerProxyGetSugarDataURL =
  "https://bots.consumerlaw.com/proxy_sugar_data";

const connection = mysql.createConnection({
  host: "137.184.226.50",
  user: "admin",
  password: "_1kK756!r(2NORK7",
  database: "logVar",
});

let token;

GetToken()
  .then((result) => {
    token = result;

    const P1Today = `https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${startDate}&endDate=${endDate}&groupBy=aset.id`;

    getSugarDataNode(P1Today, token)
      .then((response) => {
        response = JSON.parse(response);
        console.log(response.length);
        const p1Data = response.filter((data) => data.p1_sold_total);
        insertDataToP1(p1Data);
      })
      .catch((error) => {
        console.error(error);
      });

    const P2Today = `https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${startDate}&endDate=${endDate}&groupBy=dc.id`;

    getSugarDataNode(P2Today, token)
      .then((response) => {
        response = JSON.parse(response);
        console.log(response.length);
        const p2Data = response.filter((data) => data.engaged_total);
        insertDataToP2(p2Data);
      })
      .catch((error) => {
        console.error(error);
      });

    const p1SecondVoice = `https://sugar.consumerlaw.com/rest/v11_20/total-gross?startDate=${startDate}&endDate=${endDate}&groupBy=sv1.id`;

    getSugarDataNode(p1SecondVoice, token)
      .then((response) => {
        response = JSON.parse(response);
        console.log(response.length);
        const p1Second = response.filter((data) => data.p1_sold_total);
        insertDataToP1Second(p1Second);
      })
      .catch((error) => {
        console.error(error);
      });

    const p2SecondVoice = `https://sugar.consumerlaw.com/rest/v11_20/total-gross?startDate=${startDate}&endDate=${endDate}&groupBy=sv.id`;

    getSugarDataNode(p2SecondVoice, token)
      .then((response) => {
        response = JSON.parse(response);
        console.log(response.length);
        const p2Second = response.filter((data) => data.engaged_total);
        insertDataToP2Second(p2Second);
      })
      .catch((error) => {
        console.error(error);
      });

      setTimeout(() => {
        connection.end();
        process.exit();
      }, 35000);
  })
  .catch((error) => {
    console.error("Error al obtener el token:", error);
  });

function getDataGET(url) {
  return new Promise((resolve, reject) => {
    const config = {
      url: "https://bots.consumerlaw.com/proxy",
      method: "post",
      timeout: 0,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        parameters: {},
        url: `${url}`,
      },
    };

    axios(config)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
  });
}

function getSugarDataNode(url, tokenSugar) {
  // nodejs function
  return new Promise((resolve, reject) => {
    const config = {
      url: epowerProxyGetSugarDataURL,
      method: "post",
      timeout: 0,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        parameters: {},
        url: `${url}`,
        token: tokenSugar,
      },
    };
    axios(config)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
  });
}

async function GetToken() {
  return getDataGET(
    "https://home.justicialaboral.com/bot_db/api/credentials.php?tokenFor=getSalesBot&typeOfPetition=get_token"
  )
    .then((response) => {
      const token = response[0].token;
      console.log(token);
      return token;
    })
    .catch((error) => {
      console.error(error);
    });
}

async function insertDataToP1(p1Data) {
  return new Promise((resolve, reject) => {
    if (p1Data.length === 0) {
      console.log("No hay ventas P1 para insertar");
      return resolve();
    }

    // limpiar la tabla de ventas P1 para el mes actual
    connection.query(
      `DELETE FROM p_one_data_month`,
      (deleteError, deleteResults) => {
        if (deleteError) {
          console.error("Error al eliminar ventas P1 antiguos:", deleteError);
          return reject(deleteError);
        }
        console.log("Ventas P1 antiguas eliminadas correctamente");
        insertNewData();
      }
    );

    function insertNewData() {
      const sql = `INSERT INTO p_one_data_month (aset_id, as_name, branch, p1_amount, p1_sold_total) VALUES ?`;

      // Mapear los usuarios en un formato adecuado para la inserción
      const values = p1Data.map((data) => [
        data.aset_id,
        data.as_name,
        data.branch,
        data.p1_amount,
        data.p1_sold_total,
      ]);

      // Ejecutar la consulta SQL
      connection.query(sql, [values], (insertError, insertResults) => {
        if (insertError) {
          console.error("Error al insertar los nuevos ventas P1:", insertError);
          return reject(insertError);
        }
        console.log("Nuevas ventas P1 insertados correctamente");
        resolve();
      });
    }
  });
}

async function insertDataToP2(p2Data) {
  return new Promise((resolve, reject) => {
    if (p2Data.length === 0) {
      console.log("No hay ventas P2 para insertar");
      return resolve();
    }

    // limpiar la tabla de ventas P2 para el mes actual
    connection.query(
      `DELETE FROM p_two_data_month`,
      (deleteError, deleteResults) => {
        if (deleteError) {
          console.error("Error al eliminar ventas P2 antiguos:", deleteError);
          return reject(deleteError);
        }
        console.log("Ventas P2 antiguas eliminadas correctamente");
        insertNewData();
      }
    );

    function insertNewData() {
      const sql = `INSERT INTO p_two_data_month (dc_id, dc_name, engaged_total, p2_amount, p2_sold_total, local_amount, total_amount) VALUES ?`;

      // Mapear los usuarios en un formato adecuado para la inserción
      const values = p2Data.map((data) => [
        data.dc_id,
        data.dc_name,
        data.engaged_total,
        data.p2_amount,
        data.p2_sold_total,
        data.local_amount,
        data.total_amount,
      ]);

      // Ejecutar la consulta SQL
      connection.query(sql, [values], (insertError, insertResults) => {
        if (insertError) {
          console.error("Error al insertar los nuevos ventas P2:", insertError);
          return reject(insertError);
        }
        resolve();
      });
    }
  });
}

async function insertDataToP1Second(p1Data) {
  return new Promise((resolve, reject) => {
    if (p1Data.length === 0) {
      console.log("No hay Second Voice para insertar");
      return resolve();
    }

    // limpiar la tabla de Second Voice para el mes actual
    connection.query(
      `DELETE FROM sv_one_data_month`,
      (deleteError, deleteResults) => {
        if (deleteError) {
          console.error(
            "Error al eliminar Second Voice antiguos:",
            deleteError
          );
          return reject(deleteError);
        }
        console.log("Second Voice antiguas eliminadas correctamente");
        insertNewData();
      }
    );

    function insertNewData() {
      const sql = `INSERT INTO sv_one_data_month (sv1_id, sv1_name, sv1_engaged_total) VALUES ?`;

      // Mapear los usuarios en un formato adecuado para la inserción
      const values = p1Data.map((data) => [
        data.sv1_id,
        data.sv1_name,
        data.p1_sold_total,
      ]);

      // Ejecutar la consulta SQL
      connection.query(sql, [values], (insertError, insertResults) => {
        if (insertError) {
          console.error(
            "Error al insertar los nuevos Second Voice:",
            insertError
          );
          return reject(insertError);
        }
        resolve();
      });
    }
  });
}

async function insertDataToP2Second(p2SecondData) {
  return new Promise((resolve, reject) => {
    if (p2SecondData.length === 0) {
      console.log("No hay Second Voice P2 para insertar");
      return resolve();
    }

    // limpiar la tabla de Second Voice P2 para el mes actual
    connection.query(
      `DELETE FROM sv_two_data_month`,
      (deleteError, deleteResults) => {
        if (deleteError) {
          console.error(
            "Error al eliminar Second Voice P2 antiguos:",
            deleteError
          );
          return reject(deleteError);
        }
        console.log("Second Voice P2 antiguas eliminadas correctamente");
        insertNewData();
      }
    );

    function insertNewData() {
      const sql = `INSERT INTO sv_two_data_month (sv_id, sv_name, sv_engaged_total, sv_engaged_gross) VALUES ?`;

      // Mapear los usuarios en un formato adecuado para la inserción
      const values = p2SecondData.map((data) => [
        data.sv_id,
        data.sv_name,
        data.engaged_total,
        data.p2_amount,
      ]);

      // Ejecutar la consulta SQL
      connection.query(sql, [values], (insertError, insertResults) => {
        if (insertError) {
          console.error(
            "Error al insertar los nuevos Second Voice P2:",
            insertError
          );
          return reject(insertError);
        }
        console.log("Nuevas Second Voice P2 insertados correctamente");
        resolve();
      });
    }
  });
}

