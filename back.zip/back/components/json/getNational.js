const axios = require("axios");
const moment = require("moment");

const tokenStrappi = 'f5fe7ee410eaa7ef1e2098f4922c603f99d415bb0758f08dd91288bb51fc78030b491e5d80e7b900899a41fc93ee3429c78e63553568491b2086e9dc4e85875abdd2c2858632fd50d309a5ce04a0e6de191b85a03a1a303bc401301d2a8d37320aeb9d3db1a4c85cf970a278081c50c04b232089f6c12448dd6e3cfdf18d3e4c'

// URL de la API de Strapi para crear registros en la colección "Performance"
const apiEndpoint = 'https://itback.consumerlaw.com/api/performances';

// Configuración de la petición POST
const axiosConfig = {
  headers: {
    Authorization: `Bearer ${tokenStrappi}`,
  },
};

const epowerProxyGetSugarDataURL =
  "https://bots.consumerlaw.com/proxy_sugar_data";

let token;

// Función que se ejecutará cada 3 minutos
const executeProcess = () => {
  const now = new Date();
  console.log(`Proceso ejecutado a las ${now.toLocaleTimeString()}`);

  // Si es después de las 9 PM, detener el proceso
  if (now.getHours() >= 22 || now.getHours() < 9) {
    clearInterval(intervalId);
    console.log(`Proceso detenido a las ${now.toLocaleTimeString()}`);
    process.exit(0); // Termina el proceso de Node.js
  }

  // Ejecución principal
  GetToken()
    .then((result) => {
      token = result;
      const dateToday = moment().format("YYYY-MM-DD");
      const startMonthDate = moment().startOf("month").format("YYYY-MM-DD");
      return getNationalData(startMonthDate, dateToday, token);
    })
    .then((result) => {
      try {
        insertDataToNational(result);
      } catch (error) {
        console.error("Error al insertar datos:", error);
      }
    })
    .catch((error) => {
      console.error("Error al obtener datos:", error);
    });
};

// Configura el intervalo de 3 minutos (180,000 milisegundos)
const intervalId = setInterval(executeProcess, 240000);

// Ejecuta la primera vez inmediatamente
executeProcess();

async function GetToken() {
  return getDataGET(
    "https://home.justicialaboral.com/bot_db/api/credentials.php?tokenFor=getSalesBot&typeOfPetition=get_token"
  )
    .then((response) => {
      const token = response[0].token;
      return token;
    })
    .catch((error) => {
      console.error(error);
    });
}

async function getNationalData(startDate, endDate, token) {
  const P1Today = `https://sugar.consumerlaw.com/rest/v11_20/total-gross-details?startDate=${startDate}&endDate=${endDate}&groupBy=leads.id&filter="opp_sum.branch = 'National'"`;

  return getSugarDataNode(P1Today, token)
    .then((response) => {
      response = JSON.parse(response);
      console.log(response.length);
      return response;
    })
    .catch((error) => {
      console.error(error);
    });
}

async function insertDataToNational(natData) {
  try {
    if (natData.length === 0) {
      console.log("No hay ventas P1 para insertar");
      return resolve();
    }

    // console.log(natData);
    // limpiar la tabla de ventas P1 para el mes actual
    const today = moment().format("YYYY-MM-DD");
    console.log('fecha en el server', today, 'hora en el server', moment().format("HH:mm:ss"));

    const response = await axios.get(`${apiEndpoint}?filters[date]=${today}`, axiosConfig);
    // console.log(response.data.data);
    if (response.data.data.length > 0) {
      await axios.put(`${apiEndpoint}/${response.data.data[0].id}`, {data: { data: natData}}, axiosConfig);
      console.log("Ventas antiguas eliminadas correctamente");
    } else {
      await axios.post(apiEndpoint, {data: { 
        date : today,
        data: natData
      }}, axiosConfig);
      console.log("Ventas insertadas correctamente");
    }

  } catch (error) {
    console.error(error);
  }
}

function getDataGET(url) {
  return new Promise((resolve, reject) => {
    const config = {
      url: "https://bots.consumerlaw.com/proxy",
      method: "post",
      timeout: 0,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        parameters: {},
        url: `${url}`,
      },
    };

    axios(config)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
  });
}

function getSugarDataNode(url, tokenSugar) {
  // nodejs function
  return new Promise((resolve, reject) => {
    const config = {
      url: epowerProxyGetSugarDataURL,
      method: "post",
      timeout: 0,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        parameters: {},
        url: `${url}`,
        token: tokenSugar,
      },
    };
    axios(config)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
  });
}