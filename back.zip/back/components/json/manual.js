const axios = require('axios');
const fs = require('fs');
const moment = require('moment');

const secondUrlRedash = "https://reports.consumerlaw.com/api/queries/322/results?api_key=pG6ZGeHrzyW3Fbs2yzEm8LFC1cYVrrc8D0UpUfJO";

async function fetchAndStore() {


  const startDate = moment().startOf('month');
  const endDate = moment();
  const inicioMesAnterior = endDate.clone().subtract(1, 'month').startOf('month');

  const newDataByDateP1 = {};
  const newDataByDateP2 = {};
  const newDataByDateSecond = {};
  const updatedData = {};

  const existingJsonP1 = fs.readFileSync('p1.json', 'utf8');
  let  existingDataP1 = JSON.parse(existingJsonP1);
  const existingJson = fs.readFileSync('p2.json', 'utf8');
  let  existingDataP2 = JSON.parse(existingJson);
  const existingJsonSecond = fs.readFileSync('second.json', 'utf8');
  let existingDataSecond = JSON.parse(existingJsonSecond);

  const existingDatesP1 = Object.keys(existingDataP1);    // Obtener las fechas faltantes entre las fechas actuales y las existentes
  const existingDatesP2 = Object.keys(existingDataP2);
  const existingDatesSecond = Object.keys(existingDataSecond);
  const missingDatesP1 = getMissingDates(inicioMesAnterior, endDate, existingDatesP1);
  const missingDatesP2 = getMissingDates(inicioMesAnterior, endDate, existingDatesP2);
  const missingDatesSecond = getMissingDates(inicioMesAnterior, endDate, existingDatesSecond);

  for (const date of missingDatesP1) {  // Solicitar y almacenar los datos para las fechas faltantes
    const data = await getDataForP1(date);
    newDataByDateP1[date] = data;
    console.log(newDataByDateP1);
  }

  for (const date of missingDatesP2) {
    const data = await getDataForP2(date);
    newDataByDateP2[date] = data;
    console.log(newDataByDateP2);
  }

  for (const date of missingDatesSecond) {// Solicitar y almacenar los datos para las fechas faltantes
    const data = await getDataForSecondVoice(date);
    newDataByDateSecond[date] = data;
    console.log(newDataByDateSecond);
  }

  newDataByDateP1[endDate.format("YYYY-MM-DD")] = await getDataForP1(endDate);  // Solicitar y almacenar los datos para la fecha actual
  newDataByDateP2[endDate.format("YYYY-MM-DD")] = await getDataForP2(endDate);
  newDataByDateSecond[endDate.format("YYYY-MM-DD")] = await getDataForSecondVoice(endDate);

  const updatedDataP1 = { ...existingDataP1, ...newDataByDateP1 };// Combinar los datos nuevos con los existentes
  const updatedDataP2 = { ...existingDataP2, ...newDataByDateP2 };
  const updatedDataSecond = { ...existingDataSecond, ...newDataByDateSecond };
  removeZeroAmountEntries(updatedDataP1, "p1_amount");  
  removeZeroAmountEntries(updatedDataP2, "todayGross");
  removeZeroAmountEntries(updatedDataSecond, "second_voice_total");  

  const jsonDataP1 = JSON.stringify(updatedDataP1, null, 2);  // Guardar los datos actualizados en un archivo JSON
  fs.writeFileSync('./p1.json', jsonDataP1, 'utf8');
  const jsonDataP2 = JSON.stringify(updatedDataP2, null, 2);
  fs.writeFileSync('./p2.json', jsonDataP2, 'utf8');
  const jsonDataSecond = JSON.stringify(updatedDataSecond, null, 2);
  fs.writeFileSync('./second.json', jsonDataSecond, 'utf8');

  for (const date in updatedDataP1) {
    updatedData[date] = updatedDataP1[date].map((entry) => {
      const p2Entry = updatedDataP2[date].find((p2Entry) => p2Entry.user_id === entry.user_id);
      const secondEntry = updatedDataSecond[date].find((secondEntry) => secondEntry.user_id === entry.user_id);
      const p2_sold_total = p2Entry ? p2Entry.p2_sold_total : 0;// Inicializar valores por defecto
      const todayGross = p2Entry ? p2Entry.todayGross : 0;
      const second_voice_total = secondEntry ? secondEntry.second_voice_total : 0;
      const second_voice_engaged = secondEntry ? secondEntry.second_voice_engaged : 0;

      return {
        user_id: entry.user_id,
        fullName: entry.fullName,
        p1_sold_total: parseInt(entry.p1_sold_total),
        p1_amount: parseInt(entry.p1_amount),
        p2_sold_total,
        todayGross,
        second_voice_total,
        second_voice_engaged,
      };
    });

    // Agregar entradas que faltan en updatedDataP1 pero existen en p2 y second
    updatedData[date] = updatedData[date].concat(
      updatedDataP2[date]
        .filter((p2Entry) => !updatedDataP1[date].some((entry) => entry.user_id === p2Entry.user_id))
        .map((p2Entry) => ({
          user_id: p2Entry.user_id,
          fullName: p2Entry.fullName,
          p1_sold_total: 0,
          p1_amount: 0,
          p2_sold_total: p2Entry.p2_sold_total,
          todayGross: p2Entry.todayGross,
          second_voice_total: 0,
          second_voice_engaged: 0,
        })),
      updatedDataSecond[date]
        .filter((secondEntry) => !updatedDataP1[date].some((entry) => entry.user_id === secondEntry.user_id))
        .map((secondEntry) => ({
          user_id: secondEntry.user_id,
          fullName: secondEntry.fullName,
          p1_sold_total: 0,
          p1_amount: 0,
          p2_sold_total: 0,
          todayGross: 0,
          second_voice_total: secondEntry.second_voice_total,
          second_voice_engaged: secondEntry.second_voice_engaged,
        }))
    );
  }

  // Guardar los datos actualizados en un archivo JSON
  const jsonData = JSON.stringify(updatedData, null, 2);
  fs.writeFileSync('./dbtest.json', jsonData, 'utf8');
}

function getMissingDates(startDate, endDate, existingDates) {
  const missingDates = [];
  const currentDate = startDate.clone();
  
  while (currentDate.isSameOrBefore(endDate)) {
    const formattedDate = currentDate.format("YYYY-MM-DD");
    if (!existingDates.includes(formattedDate)) {
      missingDates.push(formattedDate);
    }
    currentDate.add(1, 'days');
  }
  
  return missingDates;
}

async function getDataForP1(date) {
  const formattedDate = moment(date).format("YYYY-MM-DD");
  try {
    let todayDataP1 = [];
    const response = await getDataGET(`https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${formattedDate}&endDate=${formattedDate}&groupBy=aset.id`)
    return todayDataP1 = JSON.parse(response).map((row) => {
      return {
        user_id: row.aset_id,
        fullName: row.as_name,
        p1_sold_total: row.p1_sold_total,
        p1_amount: row.p1_amount,
      };
    });
  } catch (error) {
    console.error(`Error fetching data for ${formattedDate}:`, error);
    return [];
  }
}

async function getDataForP2(date) {
  const formattedDate = moment(date).format("YYYY-MM-DD");
  try {
    let todayDataP2 = [];
    const response = await getDataGET(`https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${formattedDate}&endDate=${formattedDate}&groupBy=dc.id`)
    return todayDataP2 = JSON.parse(response).map((row) => {
      return {
        user_id: row.dc_id,
        fullName: row.dc_name,
        p2_sold_total: row.engaged_total,
        todayGross: parseInt(row.p2_amount) + parseInt(row.local_amount),
      };
    });
  } catch (error) {
    console.error(`Error fetching data for ${formattedDate}:`, error);
    return [];
  }
}

async function getDataForSecondVoice(date) {
  const formattedDate = moment(date).format("YYYY-MM-DD");
  try {
    const response = await getDataPOST(secondUrlRedash, formattedDate, formattedDate);
    return response.query_result.data.rows.map((row) => {
      return {
        user_id: row.user_id,
        fullName: row.second_voice_user_name_json,
        second_voice_total: row.second_voice_total,
        second_voice_engaged: row.engaged,
      };
    });
  } catch (error) {
    console.error(`Error fetching data for ${formattedDate}:`, error);
    return [];
  }
}

function getDataGET(url) {
  return new Promise((resolve, reject) => {
    const config = {
      url: "https://node.consumerlaw.com/proxy",
      method: "post",
      timeout: 0,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        parameters: {},
        url: `${url}`,
      },
    };

    axios(config)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
  });
}

function getDataPOST(url, start, end) {
  return new Promise((resolve, reject) => {
    const config = {
      url: "https://node.consumerlaw.com/proxy_post",
      method: "post",
      timeout: 0,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: {
        parameters: {
          datestart: `${start}`,
          dateend: `${end}`,
        },
        url: `${url}`,
      },
    };

    axios(config)
      .then(function (response) {
        resolve(response.data);
      })
      .catch(function (error) {
        reject(error);
      });
  });
}

function removeZeroAmountEntries(data, amountProperty) {
  for (const date in data) {
    data[date] = data[date].filter((entry) => {
      const amountValue = parseInt(entry[amountProperty]);
      return amountValue !== 0;
    });
  }
}

// Llamada a la función principal
fetchAndStore();
