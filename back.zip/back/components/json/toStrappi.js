const axios = require('axios');
const fs = require('fs');

// Datos del archivo JSON
const jsonData = require('./db.json'); // Asegúrate de que el archivo p1.json esté en el mismo directorio

// URL de la API de Strapi para crear registros en la colección "Performance"
const apiEndpoint = 'https://itback.consumerlaw.com/api/performances';

// Token de autorización del API de Strapi
const apiToken = 'f28c403d1ce10f2e9c5c3821d743ae65e5d5dc9d0e4e77966e33db02869790f7494bbea640a793f5ec0ceb116188cfe63ef6d04e50a5e3c7a74904888956ad3509ba4cd4eebcf077e56cb4faa6670254cb541812b37db20852bda93c85292bac6911735053e7d257c5886159c5c414ecc7c6d827de9ff35f64e319d428d4aadd';

// Configuración de la petición POST
const axiosConfig = {
  headers: {
    Authorization: `Bearer ${apiToken}`,
  },
};

// Función para leer el strappi.json
async function readStrappiData() {
  const response = await axios.get(apiEndpoint, axiosConfig);
  console.log(response.data.data);
  return response;
}

readStrappiData();
/*
// Función para importar datos
async function importData() {
  for (const entry of jsonData['2023-08-01']) {
    try {
      const response = await axios.post(apiEndpoint, entry, axiosConfig);
      console.log(`Registro creado con éxito para ${entry.fullName}`);
    } catch (error) {
      console.error(`Error al crear el registro para ${entry.fullName}: ${error.message}`);
    }
  }
}

// Llamar a la función para importar datos
importData();
*/