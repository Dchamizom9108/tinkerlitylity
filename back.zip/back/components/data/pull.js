const puppeteer = require("puppeteer");
const moment = require("moment");

(async () => {
  const isoDate = moment().subtract(25, "days").format("DD-MMMM-YYYY");
  console.log(isoDate);

  const browser= await puppeteer.launch({headless: 'true'});
  
  //const browser = await puppeteer.launch({ headless: false, args: ['--no-sandbox', '--start-maximized', '--download.default_directory=./tmp/'] , defaultViewport: null});
  
  const page = await browser.newPage();
  await page.goto(
    "https://consumerlaw.my3cx.us/#/app/call_reports/call_reports"
  );
  await page.type('input[ng-model="$ctrl.user.username"]', "666");
  await page.type('input[type="password"]', "@dm1nB0t23");
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  await page.waitForSelector("button#btnAdd");
  await page.click("button#btnAdd");
  await page.select( 'select[name="MainParams.ReportType"]', "GraphQueueAllCalls" );
  await page.type('input[name="ReportName"]', isoDate);
  await page.type('input[name="SendToEmail"]', "imurillo@consumerlaw.com");
  await page.evaluate(
    () => (document.querySelector('input[name="PeriodDate"]').value = "")
  );
  await page.type('input[ng-model="parameters.GraphPeriod.value.PeriodDate"]', isoDate);

  await page.click('button[translate="REPORTS.add_queues"]');
  await new Promise((r) => setTimeout(r, 800));
  await page.type('input[id="inputSearch"]', "904");
  await new Promise((r) => setTimeout(r, 1000));
  await page.click('label[role="button"]');
  await new Promise((r) => setTimeout(r, 800));
  await page.click('button[ng-click="addClick()"]');
  await new Promise((r) => setTimeout(r, 800));
  await page.click(
    'button[translate="CALL_REPORTS.STATISTICS.SCHEDULE_REPORT_BTN"]'
  );

    await browser.close();  
})();


