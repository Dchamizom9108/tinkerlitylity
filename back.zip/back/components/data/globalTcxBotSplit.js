const puppeteer = require("puppeteer");
const mysql = require("mysql2");
const moment = require("moment");
const fs = require("fs");

const connection = mysql.createConnection({
  host: "137.184.226.50",
  user: "admin",
  password: "_1kK756!r(2NORK7",
  database: "daily",
});

(async () => {
  const isoDate = moment().subtract(1, "days").format("YYYY-MM-DD");
  console.log(isoDate);

  const browser = await puppeteer.launch({
    headless: false,
    args: ["--no-sandbox"],
  });
  
  const page = await browser.newPage();
  page.setDefaultNavigationTimeout(0);
  await page.goto(
    "https://consumerlaw.my3cx.us/#/app/call_reports/call_reports"
  );
  await page.type('input[ng-model="$ctrl.user.username"]', "666");
  await page.type('input[type="password"]', "@dm1nB0t23");
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  await page.waitForSelector("button#btnAdd");
  await page.click("button#btnAdd");
  await page.select( 'select[name="MainParams.ReportType"]', "ExtensionsStatistics" );
  await page.type('input[name="ReportName"]', "globalTcxBot");
  await page.type('input[name="SendToEmail"]', "none@consumerlaw.com");
  await page.select('select[name="RangeType"]', "Yesterday");

  await page.select('select[name="ExtensionsFilterType"]', "ExtensionsFilter");
  await page.type(
    'input[name="ExtensionFilter"]',
    "101-620"
  );

  await page.click(
    'button[translate="CALL_REPORTS.STATISTICS.SCHEDULE_REPORT_BTN"]'
  );

  /////////////////////////////////////////////////end new page///////////////////////////
  await new Promise((r) => setTimeout(r, 8000));  

  openReport(page, "globalTcxBot").then( () => {
    console.log("12");
    readReport("globalTcxBot", isoDate).then( () => {

        console.log("Terminado");
        connection.end(); // Cerrar la conexión a la base de datos después de terminar las inserciones
        browser.close();

    });

  });

  async function openReport(page, selector) {
    await page.reload({ waitUntil: "networkidle0" });
    const inputSearch = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/list-control/div/div/div/div/div[3]/div[1]/input'
    );
    await inputSearch[0].type(selector);
    await new Promise((r) => setTimeout(r, 1000));
    var selectReport = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/list-control/div/div/div/div/div[3]/table/tbody/tr[1]/td[3]/a'
    );
    await selectReport[0].click();
    var deleteReport = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/list-control/div/div/div/div/div[3]/table/tbody/tr[1]/td[4]/button'
    );
    await deleteReport[0].click();
    await page.click('button[translate="REPOS.BUTTONS.DELETE_BTN"]');
    await new Promise((r) => setTimeout(r, 500));

    return true;
  }

  async function readReport(time, dataDate) {
    console.log(time, dataDate)

    const pages = await browser.pages();
    const newTab = pages[2];
    const syncData = await newTab.evaluate(() => {
      const rows = Array.from(document.querySelectorAll("table tr"));
      const tcxData = rows.map((row) => {
        const columns = row.querySelectorAll("td");
        const columnData = Array.from(columns, (column) => column.innerText);
        const rowData = {};
        rowData.extension = columnData[0].split(" ")[0];
        const parts = columnData[0].split(" ");
        if (parts.length >= 4) {
          rowData.agent = `${parts[1]} ${parts[2]} ${parts[3]}`;
        } else {
          rowData.agent = `${parts[1]} ${parts[2]}`;
        }
        rowData.inboundAnswered = columnData[1];
        rowData.inboundUnanswered = columnData[2];
        rowData.outboundAnswered = columnData[3];
        rowData.outboundUnanswered = columnData[4];
        rowData.totalAnswered = columnData[5];
        rowData.totalUnanswered = columnData[6];
        rowData.totalTalkingTime = columnData[7];
        return rowData;
      }).filter(
        (item) =>
          item.extension !== "" &&
          item.extension > 100 &&
          item.extension < 621 &&
          !item.agent.includes("Avalaible")
      );
      return tcxData;
    });
    
    console.log("agent.json")
    insertDataToDatabase(syncData, time, dataDate);

    await new Promise((r) => setTimeout(r, 19000));
    await newTab.close();
  }  

})();

async function insertDataToDatabase(data, part, date) {
  // Inserta los datos en la tabla data_wallboard
  if (data) {
    // Cambia la fecha según tu elección
    data.forEach((entry) => {
      const {
        extension,
        agent,
        inboundAnswered,
        inboundUnanswered,
        outboundAnswered,
        outboundUnanswered,
        totalAnswered,
        totalUnanswered,
        totalTalkingTime,
      } = entry;

      const sql = `INSERT INTO tcxSplitGlobal (split_time, data_date, extension, agent, inboundAnswered, inboundUnanswered, outboundAnswered, outboundUnanswered, totalAnswered, totalUnanswered, totalTalkingTime ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
      const values = [
        part,
        date,
        extension,
        agent,
        inboundAnswered,
        inboundUnanswered,
        outboundAnswered,
        outboundUnanswered,
        totalAnswered,
        totalUnanswered,
        totalTalkingTime,
      ];

      connection.query(sql, values, (error, results) => {
        if (error) {
          console.error("Error al insertar los datos:", error);
        } 
      });
      console.log("Datos insertados correctamente");
    });

    clearDuplicateData(); // Eliminar los datos duplicados de la tabla
  }
}

async function clearDuplicateData() {
  // Elimina los datos duplicados de la tabla data_wallboard
  const sqlQuery = `
  DELETE t1 FROM tcxSplitGlobal t1
  INNER JOIN (
    SELECT data_date, extension, MAX(id) AS max_id, split_time
    FROM tcxSplitGlobal
    GROUP BY data_date, extension, split_time
    HAVING COUNT(*) > 1
  ) t2
  ON t1.data_date = t2.data_date AND t1.extension = t2.extension AND t1.split_time = t2.split_time AND t1.id < t2.max_id;
`;
  connection.query(sqlQuery, (error, results) => {
    if (error) {
      console.error("Error al eliminar los datos duplicados:", error);
    } else {
      console.log("Datos duplicados eliminados correctamente");
    }
  });
}