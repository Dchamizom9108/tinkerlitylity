import { getDataGET, getStartDate, obtenerPhoneExtValores, fetchTeamData, mapAndFilterDataP1 } from "./functions.js";
import { getExtensionsP1, getTeamUrlRedash, getP2Id } from "./global.js?v1";

let adjustedDate = new Date();
adjustedDate.setUTCHours(adjustedDate.getUTCHours() - 5);
let end = adjustedDate.toISOString().substring(0, 10);

const dayValue = 130;
const monthValue = 3000;
const dayGoodValueP1 = 3;
const monthGoodValueP1 = end.substring(8, 10);

const p1Extensions = getExtensionsP1();
const propertiesToInclude = ['id', 'phone_ext_c'];
const teamURL = getTeamUrlRedash();
const teamP2Id = getP2Id();
const teamP2Extensions = await fetchTeamData(teamURL, teamP2Id, propertiesToInclude);

let p2Extensions = obtenerPhoneExtValores(teamP2Extensions);

updateData(end);

setInterval(() => {
  updateData(end);
}, 180000);

///////////////////////////////////////////// VARIABLES ///////////////////////////////////////////////////
let loading = true;
let firstDataLoad = true;
let previousTop10TodayP1 = [];
let newSalesTodayP1 = [];
let previousTop10TodayP2 = [];
let newSalesTodayP2 = [];

let todayGauge = Gauge(document.getElementById("today_test"), {
  max: dayValue,
  value: 0,
  label: function (value) {
    return value + " / " + dayValue;
  },
  color: function (value) {
    let percentage = (value / dayValue) * 100; // Calcular el porcentaje
    let hue = (percentage / 100) * 120; // Rango de colores de rojo a verde (120 grados)
    let color = "hsl(" + hue + ", 100%, 50%)"; // Crear el color HSL
    return color;
  },
});

let monthGauge = Gauge(document.getElementById("month_test"), {
  max: monthValue,
  value: 0,
  label: function (value) {
    return value + " / 3K";
  },
  color: function (value) {
    let percentage = (value / monthValue) * 100; // Calcular el porcentaje
    let hue = (percentage / 100) * 120; // Rango de colores de rojo a verde (120 grados)
    let color = "hsl(" + hue + ", 100%, 50%)"; // Crear el color HSL
    return color;
  },
});

const tBuildTodayP1 = $("<table>").addClass("p1-table");
const p1AppendToday = $(".p1Data");
const tBuildTodayP2 = $("<table>").addClass("p2-table");
const p2AppendToday = $(".p2Data");

///////////////////////////////////////////// TABLES /////////////////////////////////////////////////

async function updateData(end) {
	let start = getStartDate(end);
	let tiempo = calcularTiempoMinimo();

  // let minCalls = ( convertirTiempoASegundos(tiempo) / 60 ) / 2;
  let minCalls = 35;
  console.log('minCalls', minCalls, 'tiempo', tiempo)

	Promise.all([
		getDataGET(`http://home.justicialaboral.com/bot_db/api/performance.php?fechaInicio=${start}&fechaFin=${end}`),
		getDataGET(`https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${end}&endDate=${end}&groupBy=dc.id`),
		getDataGET(`https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${end}&endDate=${end}&groupBy=aset.id`),
    getDataGET(`https://sugar.consumerlaw.com/rest/v11_1/total-gross?startDate=${start}&endDate=${end}&groupBy=aset.id`),
	]).then(([monthData, dataP2, dataP1, monthDataP1]) => {
    monthDataP1 = JSON.parse(monthDataP1);
		dataP1 = JSON.parse(dataP1);
		dataP2 = JSON.parse(dataP2);

		dataP2 = dataP2.map((lead) => {
				const names = lead.dc_name.split(" ");
				const agentName = names[0] + " " + names[1];
				return {
					agent: agentName,
					Info: parseInt(lead.p2_sold_total),
					Gross: parseInt(lead.p2_amount) + parseInt(lead.local_amount),
					id: lead.dc_id,
				};
			}).filter((item) => item.agent !== "" && item.Info > 0);

		////////////////////////////////////// P1 /////////////////////////////////////////
		monthDataP1 = mapAndFilterDataP1(monthDataP1, 'as_name', ['p1_sold_total', 'p1_amount'], ['Info', 'p1_amount']);
		dataP1 = mapAndFilterDataP1(dataP1, 'as_name', ['p1_sold_total', 'p1_amount'], ['Info', 'p1_amount']);
		////////////////////////////////////// P1 /////////////////////////////////////////

//     console.log(dataP1, dataP2)
//     const sampleP1Start = [
//       {
//           "agent": "Josafat Maheda",
//           "Info": 3,
//           "p1_amount": 450,
//           "monthInfo": 40
//       },
//       {
//           "agent": "Reinaldo Kauil",
//           "Info": 2,
//           "p1_amount": 300,
//           "monthInfo": 46
//       },
//       {
//           "agent": "Maria Alejandra",
//           "Info": 2,
//           "p1_amount": 300,
//           "monthInfo": 35
//       },
//       {
//           "agent": "Josue Jonathan",
//           "Info": 2,
//           "p1_amount": 300,
//           "monthInfo": 34
//       },
//       {
//           "agent": "Josue Israel",
//           "Info": 2,
//           "p1_amount": 300,
//           "monthInfo": 25
//       },
//       {
//           "agent": "Angel Alexis",
//           "Info": 2,
//           "p1_amount": 500,
//           "monthInfo": 16
//       },
//       {
//           "agent": "Giezis Eduardo",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 42
//       },
//       {
//           "agent": "Juan Chable",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 41
//       },
//       {
//           "agent": "Sheyna Alejandra",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 41
//       },
//       {
//           "agent": "Hilda Rebeca",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 40
//       },
//       {
//           "agent": "Anamelys Maria",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 40
//       },
//       {
//           "agent": "Alma Paola",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 39
//       },
//       {
//           "agent": "Paloma Vega",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 36
//       },
//       {
//           "agent": "Diego Gaspar",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 34
//       },
//       {
//           "agent": "Gerardo Almanza",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 32
//       },
//       {
//           "agent": "Sandra Luz",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 31
//       },
//       {
//           "agent": "Laura Gabriela",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 30
//       },
//       {
//           "agent": "Christel Galeana",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 30
//       },
//       {
//           "agent": "Rosmary Maite",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 29
//       },
//       {
//           "agent": "Magali Beatriz",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 29
//       },
//       {
//           "agent": "Yennyfer Lizet",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 28
//       },
//       {
//           "agent": "Efrain Eliasib",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 28
//       },
//       {
//           "agent": "Jose Ivan",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 23
//       },
//       {
//           "agent": "Jesus Ismael",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 23
//       },
//       {
//           "agent": "Evelyn Stephanie",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 21
//       },
//       {
//           "agent": "Jesus Ivan",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 17
//       },
//       {
//           "agent": "Deysi Alejandra",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 14
//       },
//       {
//           "agent": "Karen Denisse",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 11
//       },
//       {
//           "agent": "Oscar Chavez",
//           "Info": 1,
//           "p1_amount": 150,
//           "monthInfo": 5
//       }
//   ]

//   const sampleP2Start = [
//     {
//         "agent": "Hector Raul",
//         "Info": 1,
//         "Gross": 9000,
//         "id": "5e2d7f90-3a38-11eb-95e6-dadc21ba0c54",
//         "monthInfo": "32"
//     },
//     {
//         "agent": "David Cruz",
//         "Info": 1,
//         "Gross": 9000,
//         "id": "0d99b774-fcef-11e9-9ba6-dadc21ba0c54",
//         "monthInfo": "17"
//     },
//     {
//         "agent": "Berenice Hernandez",
//         "Info": 1,
//         "Gross": 6000,
//         "id": "7d0bcb10-1aee-11eb-bb07-dadc21ba0c54",
//         "monthInfo": "26"
//     },
//     {
//         "agent": "Edgar Manolo",
//         "Info": 1,
//         "Gross": 1500,
//         "id": "6ba3a302-dd90-11ea-9df0-dadc21ba0c54",
//         "monthInfo": "27"
//     }
// ]

// if (!firstDataLoad) {
//   newSalesTodayP1 = sampleP1Start.filter( (item) => !previousTop10TodayP1.some(
//     (prevItem) => prevItem.agent === item.agent ) );
//   newSalesTodayP2 = sampleP2Start.filter( (item) => !previousTop10TodayP2.some(
//     (prevItem) => prevItem.agent === item.agent ) );
//   if (newSalesTodayP1.length > 0) { // por cada elemento correr la función de la marquesina
//     newSalesTodayP1.forEach((element) => {
//       setMarqueeText(`${element.agent} P1 SOLD Let's Do This!!!`);
//     });
//   } else if (newSalesTodayP2.length > 0) {
//     newSalesTodayP2.forEach((element) => {
//       setMarqueeText(
//         `${element.agent} Engaged ${element.Gross}K Let's Do This!!!`
//       );
//     });
//   }
// }
previousTop10TodayP1 = dataP1;
previousTop10TodayP2 = dataP2;


		if (!firstDataLoad) {
			newSalesTodayP1 = dataP1.filter( (item) => !previousTop10TodayP1.some(
				(prevItem) => prevItem.agent === item.agent ) );
			newSalesTodayP2 = dataP2.filter( (item) => !previousTop10TodayP2.some(
				(prevItem) => prevItem.agent === item.agent ) );
      if (newSalesTodayP1.length > 0) { //por cada elemento correr la función de la marquesina
        newSalesTodayP1.forEach((element) => {
          setMarqueeText(`${element.agent} P1 SOLD Let's Do This!!!`);
        });
      } else if (newSalesTodayP2.length > 0) {
        newSalesTodayP2.forEach((element) => {
          setMarqueeText(
            `${element.agent} Engaged ${element.Gross}K Let's Do This!!!`
          );
        });
      }
		}
		previousTop10TodayP1 = dataP1;
		previousTop10TodayP2 = dataP2;

		let getP1Month = monthDataP1.reduce((acc, item) => acc + parseInt(item.Info), 0);
		let getP1Today = dataP1.reduce((acc, item) => acc + parseInt(item.Info), 0);
		let getP2Today = dataP2.reduce((acc, item) => acc + parseInt(item.Info), 0);
		let getP2Month = monthData.reduce((acc, item) => acc + parseInt(item.total_p2_sold), 0);

		dataP1.forEach((element) => {
			const monthDataElement = monthDataP1.find( (item) => item.agent === element.agent );
			element.monthInfo = monthDataElement ? monthDataElement.Info : 0;
		});

		dataP2.forEach((element) => {
			const monthDataElement = monthData.find( (item) => item.user_id === element.id );
			element.monthInfo = monthDataElement ? monthDataElement.total_p2_sold : 0;
		});

		let top10TodayP1 = dataP1.sort(salesCustomSort).slice(0, 12);
		let top10TodayP2 = dataP2.sort((a, b) => b.Gross - a.Gross).slice(0, 12);

		$(".p1-table").empty();
		const theadsP1 = [ 'P1 Data', getP1Today.toString(), getP1Month.toString() ];
		buildTable( top10TodayP1, tBuildTodayP1, theadsP1 , p1AppendToday, "p1" );
		todayGauge.setValue(getP1Today);

		$(".p2-table").empty();
		const theadsP2 = [ 'P2 Data', getP2Today.toString(), getP2Month.toString() ];
		buildTable(	top10TodayP2, tBuildTodayP2, theadsP2 , p2AppendToday, "p2" );
		monthGauge.setValue(getP1Month);

    getDataGET( `http://home.justicialaboral.com/bot_db/api/tcx.php?fechaInicio=${end}&fechaFin=${end}`).then((callsDataTcx) => {
      callsDataTcx = filtrarPorTalkingTime(callsDataTcx, tiempo)
        // PART 1:
          const processCallsData = (callsData, extensions, excludedNames, minCalls) => 
            callsData.map((item) => {
              const names = item.agent.split(' ');
              const agentName = names.slice(0, 2).join(' ');
              const totalCalls = parseInt(item.inbound) + parseInt(item.outboundTcx);
              return {
                Name: agentName,
                ["Talk Time"]: item.totalTalkingTime,
                totalTalkingTime: item.totalTalkingTime,
                "Total Calls": totalCalls,
                extension: item.extension,
              };
            })
              .filter((item) => item.Name !== "" && item["Total Calls"] >= minCalls)
              .sort(customSort)
              .filter((item) => extensions.includes(item.extension) && !excludedNames.includes(item.Name))
              .slice(0, 12)
              .map((item) => ({
                Name: item.Name,
                ["Talk Time"]: item.totalTalkingTime,
              }));

        let p2 = processCallsData(callsDataTcx, p2Extensions, ["Jhony Quintero", "Yamil Salomon"], minCalls);
        let callDataP1 = processCallsData(callsDataTcx, p1Extensions, [], minCalls).slice(0, 12);
        // END OF PART 1

      $(".p1-effort-table").empty();
      crearTabla(callDataP1, "p1Effort");

      $(".p2-effort-table").empty();
      crearTabla(p2, "p2Effort");

      if (loading) {
        loading = !loading;
        $(".loading").hide(); // Ocultar el loading
      }
      newSalesTodayP1 = [];
      newSalesTodayP2 = [];
      firstDataLoad = false;
    }).catch((error) => console.error(error));
	})
	.catch((error) => console.error(error));
}

function buildTable(tData, table, theads, appendVar, tipeOfTable) {
  const theadConstruct = $("<thead>").appendTo(table);
	const headerRow = $("<tr>").appendTo(theadConstruct);

	theads.forEach((thead) => {
  headerRow.append($("<th>").text(thead));
	});
  const tbody = $("<tbody>").appendTo(table);

  $.each(tData, function (i, item) {
    const row = $("<tr>").appendTo(tbody);

    const agentCell = $("<td>").text(item.agent).appendTo(row);
    const infoCell = $("<td>").text(item.Info).appendTo(row);
		const monthCell = $("<td>").text(item.monthInfo).appendTo(row);

    row.addClass(i === 0 ? "first-row" : "");
    if (tipeOfTable === "p1") {
      agentCell.addClass(
        appendVar === p1AppendToday && item.Info >= dayGoodValueP1 ? "highlight" : ""
      );
      infoCell.addClass(
        appendVar === p1AppendToday && item.Info >= dayGoodValueP1 ? "highlight" : ""
      );
			monthCell.addClass(
				appendVar === p1AppendToday && item.monthInfo > (monthGoodValueP1 * 1.5) ? "highlight" : ""
			);
    } else if (tipeOfTable === "p2") {
      agentCell.addClass(
        appendVar === p2AppendToday && item.Info >= 2 ? "highlight" : ""
      );
      infoCell.addClass(
        appendVar === p2AppendToday && item.Info >= 2 ? "highlight" : ""
      );
    }
  });

  appendVar.append(table);
}

function setMarqueeText(text) {
  const audio = new Audio("./win.mp3");
  audio.play();
  // Mostrar el contenedor de la marquesina
  const marqueeContainer = document.getElementById("marqueeContainer");
  marqueeContainer.style.display = "block";

  const marqueeText = document.getElementById("marqueeText");
  marqueeText.textContent = text;

  // Mostrar la marquesina
  marqueeText.style.display = "inline-block";

  // Reiniciar la animación
  marqueeText.style.animation = "none";
  void marqueeText.offsetWidth;
  marqueeText.style.animation = null;

  // Ocultar la marquesina después de 5 segundos
  setTimeout(function () {
    marqueeText.style.display = "none";
    marqueeContainer.style.display = "none";
  }, 10000);
}

function calcularTiempoMinimo() {
  const horaActual = new Date().getHours();

	const horasDesde10AM = horaActual - 10;
	const minutosAdicionales = horasDesde10AM * 30; // 23 minutos adicionales por cada hora desde las 10 am
	const horas = Math.floor(minutosAdicionales / 60);
	const minutos = minutosAdicionales % 60;
	return `${horas}:${minutos < 10 ? "0" : ""}${minutos}:00`;

}

function filtrarPorTalkingTime(datos, tiempoMinimo) { // Convierte el tiempo mínimo en segundos para facilitar la comparación
  const tiempoMinimoSegundos = convertirTiempoASegundos(tiempoMinimo);

  // Filtra los datos por "Talking Time" mayor o igual al tiempo mínimo
  const datosFiltrados = datos.filter((element) => {
    const tiempoTalkingTimeSegundos = convertirTiempoASegundos( element.totalTalkingTime );
    return tiempoTalkingTimeSegundos <= tiempoMinimoSegundos;
  });

  return datosFiltrados;
}

function convertirTiempoASegundos(timeString) {
  // Función para convertir el formato de tiempo "hh:mm:ss" a segundos
  const [hours, minutes, seconds] = timeString.split(":").map(Number);
  return hours * 3600 + minutes * 60 + seconds;
}

function crearTabla(datos, tableId) {
	const contenedorTabla = document.getElementById(tableId);

	const tabla = document.createElement("table");
	const encabezado = tabla.createTHead();
	const filaEncabezado = encabezado.insertRow();

	for (const propiedad in datos[0]) {  // Crear las celdas del encabezado
		const celda = filaEncabezado.insertCell();
		celda.textContent = propiedad;
	}

	datos.forEach((filaDatos) => {	// Crear las filas de datos
		const fila = tabla.insertRow();
		for (const propiedad in filaDatos) {
			const celda = fila.insertCell();
			celda.textContent = filaDatos[propiedad];
		}
	});

	contenedorTabla.appendChild(tabla); // Agregar la tabla al contenedor
}

function customSort(a, b) {
  // Función de comparación para ordenar primero por "Engaged P1" y luego por "Talking Time"
  if (a["Engaged"] < b["Engaged"]) {
    return -1;
  } else if (a["Engaged"] > b["Engaged"]) {
    return 1;
  } else {
    // Si "Engaged P1" es igual, ordena por "Talking Time"
    const timeA = convertirTiempoASegundos(a.totalTalkingTime);
    const timeB = convertirTiempoASegundos(b.totalTalkingTime);
    return timeA - timeB;
  }
}

function salesCustomSort(a, b) {
	if (a.Info > b.Info) {
			return -1; // Orden descendente por Info (ventas del día)
	} else if (a.Info < b.Info) {
			return 1;
	} else {
			// Si las ventas del día son iguales, ordenar por monthInfo (ventas del mes)
			if (a.monthInfo > b.monthInfo) {
					return -1; // Orden descendente por monthInfo
			} else if (a.monthInfo < b.monthInfo) {
					return 1;
			} else {
					return 0; // Si ambos valores son iguales, no se cambia el orden
			}
	}
}

/*

/// PART 1
      let p2 = callsDataTcx.filter((element) => {
        return p2Extensions.includes(element.extension);
      })
        .map((item) => {
          const names = item.agent.split(' ');
          const agentName = names[0] + ' ' + names[1];
          return {
            Name: agentName,
            ["Talking Time"]: item.totalTalkingTime,
            totalTalkingTime: item.totalTalkingTime,
            "Total Calls": parseInt(item.inbound) + parseInt(item.outboundTcx),
          };
      })
        .filter((item) => item.Name !== "Jhony Quintero" && item.Name !== "Yamil Salomon" && item["Total Calls"] >= minCalls)
          .sort(customSort)
            .slice(0, 12)
              .map((item) => {
                return {
                  Name: item.Name,
                  ["Talk Time"]: item.totalTalkingTime,
                }
              })

      let callDataP1 = callsDataTcx.map((item) => {
        const names = item.agent.split(" ");
        const agentName = names[0] + " " + names[1];
        return {
          Name: agentName,
          extension: item.extension,
          totalTalkingTime: item.totalTalkingTime,
          "Total Calls":
            parseInt(item.inbound) + parseInt(item.outboundTcx),
        };
      }).filter((item) => item.Name !== "" && item["Total Calls"] >= minCalls)
        .sort(customSort)
          .filter((item) => {
            return p1Extensions.includes(item.extension);
          })
            .map((item) => {
                return {
                  Name: item.Name,
                  ["Talk Time"]: item.totalTalkingTime,
                };
            }).slice(0, 12);
*/