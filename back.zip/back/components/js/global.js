const epowerProxyURL = "https://bots.consumerlaw.com/proxy"

function getDataGET(url) {
	return new Promise((resolve, reject) => {
		$.ajax({
			url: epowerProxyURL,
			method: "POST",
			timeout: 0,
			crossDomain: true,
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			data: JSON.stringify({
				parameters: {},
				url: `${url}`,
			}),
			success: function (response) {
				resolve(response);
			},
			error: function (xhr, status, error) {
				reject(
					new Error(`Error fetching data from ${url}. Status: ${status}`)
				);
			},
		});
	});
}

async function getDataFromSugarTeam(teamId) {
  try {
    const usersBySugarTeamURLAPI = `https://home.justicialaboral.com/bot_db/api/get_users_by_team.php?teamId=${teamId}`;
    const datosConExtension = await getDataGET(usersBySugarTeamURLAPI);

    return datosConExtension;
  } catch (error) {
    console.error(error);
    return [];
  }
}


const callRedashUrl =
  "https://reports.consumerlaw.com/api/queries/461/results?api_key=pG6ZGeHrzyW3Fbs2yzEm8LFC1cYVrrc8D0UpUfJO";
const secondP1UrlRedash =
  "https://reports.consumerlaw.com/api/queries/322/results?api_key=tWyiv3ZZIGeng3kA1MROHFJUWwrgPRZDFevZgtHX";
const secondPOP1UrlRedash =
  "https://reports.consumerlaw.com/api/queries/479/results?api_key=q3QFlPSfTd23naD8kpaB4xIX6AUDO3PjUJoaoIaC";
const teamURL =
  "https://reports.consumerlaw.com/api/queries/489/results?api_key=YHgjebUZzWXbpkg9Y0vJOEgmh9bRJMFHR4FH0tgl"; // to delete

const team1Id = "c0c79ed8-5d67-11ee-acec-dadc21ba0c54";
const team2Id = "5c95114e-5e10-11ee-b25d-dadc21ba0c54";
const team3Id = "3a493bfa-5e11-11ee-a009-dadc21ba0c54";
const team4Id = "f5711a2c-5e13-11ee-8b98-dadc21ba0c54";
const team5Id = "c3f3599c-ac10-11ee-8c8c-dadc21ba0c54";
const trainingSalesId = "5e0229f2-b57e-11ee-b4d4-dadc21ba0c54";
const teamP2Id = "00857dc2-c74c-11ed-9c75-dadc21ba0c54";
const teamScreenersId = "18aba630-7f0f-11ee-b854-dadc21ba0c54";
const teamLocalId = "2766439e-c74d-11ed-b772-dadc21ba0c54";
const teamARId = "6743433c-e355-11e6-8b95-005056951e6f";
const teamP1Id = "9f354f26-c74a-11ed-9b02-dadc21ba0c54";

export const team1 = await getDataFromSugarTeam(team1Id)
export const team2 = await getDataFromSugarTeam(team2Id)
export const team3 = await getDataFromSugarTeam(team3Id)
export const team4 = await getDataFromSugarTeam(team4Id)
export const team5 = await getDataFromSugarTeam(team5Id)
export const trainingSales = await getDataFromSugarTeam(trainingSalesId)
export const teamP1 = [team1, team2, team3, team4, team5, trainingSales].flat();
export const teamP2 = await getDataFromSugarTeam(teamP2Id)
export const teamLocal = await getDataFromSugarTeam(teamLocalId)
export const teamAR = await getDataFromSugarTeam(teamARId)

export function getTeamsExt() {
  return [
    { 
      label: "team1",
      data : team1,
    }, 
    {
      label: "team2",
      data : team2,
    },
    {
      label: "team3",
      data : team3,
    },
    {
      label: "team4",
      data : team4,
    },
    {
      label: "team5",
      data : team5,
    },
    {
      label: "trainingSales",
      data : trainingSales,
    },
    {
      label: "teamP1",
      data : teamP1,
    },
    {
      label: "teamP2",
      data : teamP2,
    },
    {
      label: "teamLocal",
      data : teamLocal,
    },
    {
      label: "teamAR",
      data : teamAR,
    }
  ]
}

export function getCallRedashUrl() {
  return callRedashUrl;
}

export function getSecondP1UrlRedash() {
  return secondP1UrlRedash;
}

export function getSecondPOP1UrlRedash() {
  return secondPOP1UrlRedash;
}

export function getTeamUrlRedash() {
  // to delete
  return teamURL;
}

export function getTeams123Id() {
  return [team1Id, team2Id, team3Id, team4Id, team5Id, teamTrainingId];
}

export function getP2Id() {
  return teamP2Id;
}

export function getLocalId() {
  return teamLocalId;
}

export function getScreenersId() {
  return teamScreenersId;
}
