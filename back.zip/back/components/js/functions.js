const sugarTokenUrl = 'https://home.justicialaboral.com/bot_db/api/credentials.php?tokenFor=functionsJs&typeOfPetition=get_token';
let tokenCounter = 0;

const epowerProxyURL = "https://bots.consumerlaw.com/proxy"
const epowerProxyGetSugarDataURL = "https://bots.consumerlaw.com/proxy_sugar_data"

export function getDataGET(url) {
	return new Promise((resolve, reject) => {
		$.ajax({
			url: epowerProxyURL,
			method: "POST",
			timeout: 0,
			crossDomain: true,
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			data: JSON.stringify({
				parameters: {},
				url: `${url}`,
			}),
			success: function (response) {
				resolve(response);
			},
			error: function (xhr, status, error) {
				reject(
					new Error(`Error fetching data from ${url}. Status: ${status}`)
				);
			},
		});
	});
}

export function getStartDate (date) {
  console.log('date split', date);
  const year = date.split("-")[0];
  const month = date.split("-")[1];
  const start = `${year}-${month}-01`;
  return start;
}

export const startValue = () => {
  let date = new Date();
  date.setUTCHours(date.getUTCHours() - 5);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const end = `${year}-${month}-01`;
  return end;
}

export const endValue = () => {
  let date = new Date();
  date.setUTCHours(date.getUTCHours() - 5);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const end = `${year}-${month}-${day}`;
  return end;
}

export function clearContainers(containers) {
  console.log("clearing containers", containers);
  containers.forEach((container) => {
    container.innerHTML = "";
  });
}

export function getDataPOST(url, start, end) {
  return new Promise((resolve, reject) => {
    const settings = {
      url: "https://node.consumerlaw.com/proxy_post",
      method: "POST",
      timeout: 0,
      crossDomain: true,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: JSON.stringify({
        parameters: {
          datestart: `${start}`,
          dateend: `${end}`,
        },
        url: `${url}`,
      }),
    };

    $.ajax(settings)
    .done(function(response) {
      resolve(response);
    })
    .fail(function(error) {
      reject(error);
    });
  });
}

export function getAuthToken() {
  return new Promise((resolve, reject) => {
    getDataGET(sugarTokenUrl).then((response) => {
      console.log('response', response);
      response = response[0].token;
      localStorage.setItem("tokenSugar", response);
      resolve(response);
    });
  });
}

export function getSugarData(url) { // to delete
  return new Promise((resolve, reject) => {
    var tempToken = localStorage.getItem("tokenSugar");
    var settings = {
      "url": epowerProxyGetSugarDataURL,
      "method": "POST",
      "timeout": 0,
      "headers": {
        "Content-Type": "application/json"
      },
      "data": JSON.stringify({
        "url": `${url}`,
        "token": tempToken,
      }),
    };
    
    $.ajax(settings).done(function (response) {
      if (response.status == 401) {
        tokenCounter ++;
        if (tokenCounter > 5) {
          // Si se excede el límite de intentos, mostrar mensaje y redirigir
          alert("Contacte con IT"); // Mensaje de advertencia
          window.location.href = "https://home.justicialaboral.com/bot_db/"; // Redirección
          return; // Detener la ejecución
        }
        getAuthToken();
        console.log('response', response);
        setTimeout(function () {
          getSugarData(url);
        }, 3000);
      } else {
        resolve(response);
      }
    }).fail(function(xhr, status, error) {
      console.error('Error:', error);
      reject(error);
    });
  });
};

export function getDataTeam(url, teamId) { // to delete
  return new Promise((resolve, reject) => {
    const settings = {
      url: "https://node.consumerlaw.com/proxy_post",
      method: "POST",
      timeout: 0,
      crossDomain: true,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: JSON.stringify({
        parameters: {
          team: `${teamId}`,
        },
        url: `${url}`,
      }),
    };

    $.ajax(settings)
    .done(function(response) {
      resolve(response);
    })
    .fail(function(error) {
      reject(error);
    });
  });
}

export function mapAndFilterSecondVoiceP1(data, keyName, otherKeys) {
  return data.map((lead) => {
    const names = lead[keyName].trim().split(" ");
    const agentName = names[0] + " " + names[1] + " " + names[2];
    const newData = { agent: agentName };

    otherKeys.forEach((key) => {
      newData[key] = parseInt(lead[key]) || 0;
    });

    return newData;
  });
}

export function mapAndFilterDataP1(data, keyName, otherKeys, newKeyNames) {  // Map and filter the data for P1
  return data
    .map((lead) => {
      const names = lead[keyName].trim().split(" ");
      // const agentName = names[0] + " " + names[1] + " " + names[2];
      const agentName = names[0] + " " + names[1] ;
      const newData = { agent: agentName };

      otherKeys.forEach((key, index) => {
        const newKeyName = newKeyNames[index];
        newData[newKeyName] = parseInt(lead[key]) || 0;
      });

      return newData;
    })
    .filter((item) => item.agent !== "" && otherKeys.every((key) => item[key] !== 0)
  );
}

export function mapAndFilterDataP2(data, keyName, otherKeys) {
  return data
    .map((lead) => {
      const names = lead[keyName].trim().split(" ");
      const agentName = names[0] + " " + names[1];
      const newData = { agent: agentName };

      otherKeys.forEach((key) => {
        newData[key] =
          key === "monthGross" || key === "todayGross"
            ? parseInt(lead.p2_amount) + parseInt(lead.local_amount)
            : key === "todayEngaged" || key === "monthEngaged"
            ? parseInt(lead.engaged_total) || 0
            : parseInt(lead[key]) || 0;
      });

      return newData;
    })
    .filter(
      (item) =>
        item.agent !== "" && (item.todayEngaged > 0 || item.monthEngaged > 0)
    );
}

export function obtenerUserFullNames(data) {
  return data.map(function (item) {
    return {
      user_id: item.user_id,
      fullname: item.fullname,
      department: item.department,
    };
  });
}

export function dividirDatosPorExtension(datos, p2Extensions) {
  const p2 = [];

  datos.forEach((element) => {
    const extension = element.Ext;
    if (p2Extensions.includes(extension)) {
      p2.push(element);
    } 
  });

  return { p2 };
}

export function obtenerPhoneExtValores(datos) {// Funcion para obtener los valores de phone_ext_c 
  const phoneExtValores = [];
  datos.data.forEach((item) => {
    const phoneExt = item.phone_ext_c;
    if (phoneExt !== null && !isNaN(phoneExt)) {
      phoneExtValores.push(phoneExt.toString());
    }
  });

  return phoneExtValores;
}

export async function fetchTeamData(teamURL, teamId, propertiesToInclude) { // to delete
  try {
    const response = await getDataTeam(teamURL, teamId);
    return response.query_result.data.rows.map((item) => {
      const selectedProperties = {};

      if (Array.isArray(propertiesToInclude)) {
        propertiesToInclude.forEach((prop) => {
          if (item.hasOwnProperty(prop)) {
            selectedProperties[prop] = item[prop];
          }
        });
      }

      return selectedProperties;
    });
  } catch (error) {
    console.log('error', error);
    return [];
  }
}

export function convertirTiempoASegundos(timeString) { // Función para convertir el formato de tiempo "hh:mm:ss" a segundos
  const [hours, minutes, seconds] = timeString.split(":").map(Number);
  return hours * 3600 + minutes * 60 + seconds;
}

export function convertirSegundosATiempo(seconds) { // Función para convertir los segundos a formato "hh:mm:ss"
  const hours = seconds / 3600;
  const minutes = (seconds % 3600) / 60;
  return [hours, minutes, seconds % 60].map((val) => Math.floor(val).toString().padStart(2, "0")).join(":");
}