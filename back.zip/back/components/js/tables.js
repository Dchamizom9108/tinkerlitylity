import { attendanceColumns, lateColumns } from "./columns.js?v3";
const dataTable = [];

export const attendanceTable = new Tabulator("#datos-container", {
    data: dataTable,
    layout: "fitColumns",
    dataTree: true,
    dataTreeStartExpanded: false,
    columns: attendanceColumns,
    rowFormatter: function(row) {
      let cell = row.getCell("status");
      if (cell.getValue() === "late") {
        row.getElement().classList.add("warning"); // Aplicar el estilo solo a la celda "status"
      }
    },
});

export const exportAttendanceTable = new Tabulator("#export-attendance-container", {
  data: dataTable,
  layout: "fitColumns",
  dataTree: true,
  dataTreeStartExpanded: true,
  columns: attendanceColumns,
  rowFormatter: function(row) {
    let cell = row.getCell("status");
    if (cell.getValue() === "late") {
      row.getElement().classList.add("warning"); // Aplicar el estilo solo a la celda "status"
    }
  },
});

export const lateTable = new Tabulator("#late-container", {
  data: dataTable,
  dataTree: true,
  layout: "fitColumns",
  columns: lateColumns,
});

export const pastDueTable = new Tabulator("#pDue", {
    data: dataTable,
    layout: "fitDataTable",
    dataTree: true,
    dataTreeStartExpanded: false,
    initialSort:[
      {column:"amount", dir:"desc"},
    ],
    columns: pastDueColumns,
    rowFormatter: function(row) {
      var cell = row.getCell("warning");
      if (cell.getValue() === "contactlate") {
        row.getElement().classList.add("warning");
      }
    },
});
