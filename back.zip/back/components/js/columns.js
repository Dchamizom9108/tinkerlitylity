const red = "#e41749";
const yellow = "#f2a600";
const green = "#00b300";

export const attendanceColumns = [
  {
    title: "Nombre",
    field: "fullname",
    sorter: "string",
    hozAlign: "center"
  },
  {
    title: "Fecha",
    field: "date_bio",
    sorter: "string",
    hozAlign: "center",
    visible: true
  },
  {
    title: "Departamento",
    field: "department",
    sorter: "string",
    visible: false
  },
  {
    title: "Horario",
    field: "checkInOut",
    hozAlign: "center"
  },
  {
    title: "Status",
    field: "status",
    hozAlign: "center",
    visible: true,
  },
  {
    title: "Biometric Count",
    field: "bio_count",
    hozAlign: "center",
    visible: true,
  },
];

export const exportAttendanceColumns = [
  {
    title: "Nombre",
    field: "fullname",
    sorter: "string",
    hozAlign: "center"
  },
  {
    title: "Fecha",
    field: "date_bio",
    sorter: "string",
    hozAlign: "center",
    visible: true
  },
  {
    title: "Departamento",
    field: "department",
    sorter: "string",
    visible: false
  },
  {
    title: "Horario",
    field: "checkInOut",
    hozAlign: "center"
  },
  {
    title: "Status",
    field: "status",
    hozAlign: "center",
    visible: true,
  },
  {
    title: "Biometric Count",
    field: "bio_count",
    hozAlign: "center",
    visible: true,
  },
];

export const lateColumns = [
  {
  title: "Nombre",
  field: "fullname",
  sorter: "string",
  hozAlign: "center"
  },
  {
    title: "Fecha",
    field: "date_bio",
    sorter: "string",
    hozAlign: "center"
  },
  {
    title: "Horario",
    field: "checkInOut",
    hozAlign: "center"
  },
  {
    title: "Status",
    field: "status",
    sorter: "number",
    hozAlign: "center"
  },
  {
    title: "Departamento",
    field: "department",
    sorter: "string",
    visible: true
  },
];
/*
export const pastDueColumns = [
  {title:"CM", field:"cm", hozAlign:"left", sorter:"string"},
  { 
    title: "Cases", 
    field: "caseId", 
    hozAlign: "center", 
    sorter: "number",
    topCalc: "sum",
    formatter: function(cell, formatterParams, onRendered) {
      if (cell.getData()._children) { // Si la celda es un nodo padre
        return cell.getValue(); // Devuelve el valor de la celda sin formato
      } else { // Si la celda es un nodo hijo
        var leadLinkValue = cell.getRow().getData().leadLink;
        return "<a href='https://sugar.consumerlaw.com/#Leads/" + leadLinkValue + "' target='_blank'>" + cell.getValue() + "</a>";
      }
    },
  },
  {title: "Lead Link", field: "leadLink", hozAlign: "left", sorter: "number", visible: false},
  {title:"Payment Status", field:"paymentStatus", hozAlign:"left", sorter:"string",},
  {title:"Payment Date", field:"paymentDate", hozAlign:"center", sorter:"string"},
  {title:"Amount", field:"amount", hozAlign:"center", sorter:"number"},        
  {title:"Last Call", field:"lastCallBySales", hozAlign:"center", sorter:"string",},
  {title:"Payment Method", field:"paymentMethod", hozAlign:"left", sorter:"string"},
  {title:"Auto Pay", field:"autopayStatus", hozAlign:"left", sorter:"string"},
  {title:"Tot Fee", field:"totalFee", hozAlign:"center", sorter:"number", topCalc: "sum"},
  {title:"Tot Owed", field:"totalAmountOwed", hozAlign:"center", sorter:"number"},
  {title:"Owed Now", field:"amountOwedNow", hozAlign:"center", sorter:"number"},
  {title:"Warning", field:"warning", hozAlign:"center", sorter:"string", visible: false},
];
*/
/*
export function createSalesColumns(end) {
  const salesColumns = [
    {title:"Agent", field:"agent", hozAlign:"center", sorter:"string", headerSort:false},
    {
      title: "2500",
      field: "monthP1",
      hozAlign: "center",
      sorter: "number",
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams){
      var ventas = cell.getValue();
      var diasTrabajados = end.split('-')[2];
      var ventasPromedio = ventas / diasTrabajados;					
      var color = "white";					
      if (ventasPromedio <= 1 && ventas < 45) {
        color = red;
        } else if (ventasPromedio < 2 && ventasPromedio > 1 && ventas < 45) {
        color = yellow;
        } else {
        color = "#00b300";
        }						
        return "<div style='background-color: " + color + "; color: white; font-weight: bold; height: 20px; width: 100%'>" + ventas + "</div>";
      }
    },
    {
      title: "Today", 
      titleFormatter: function(cell, formatterParams) {
        return end;
      },
      field: "todayP1", 
      hozAlign: "center", 
      sorter: "number", 
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams) {
        var sold = cell.getRow().getData().todayP1;
        if(sold == 0) {
          return "<div style='background-color: #e41749; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else if(sold == 1) {
          return "<div style='background-color: #f2a600; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else {
          return "<div style='background-color: #00b300; color: white; font-weight: bold;'>" + sold + "</div>";
        }
      }
    },
    {
      title: "P1 Do Today",
      field: "todaySvDoneP1",
      hozAlign: "center",
      sorter: "number",
      headerPopup: "Amount of P1 Second Voice Marked by Agent Today",
      headerPopupIcon: function (component) {
        return "<i class='fas fa-bars'></i>";
      },
      formatter: function (cell, formatterParams) {
        let done = cell.getRow().getData().todaySvDoneP1;
        if (done < 2) {
          return (
            `<div style='background-color: ${red}; color: white; font-weight: bold;'>` +
            done +
            "</div>"
          );
        } else if (done == 2) {
          return (
            `<div style='background-color: ${yellow}; color: white; font-weight: bold;'>` +
            done +
            "</div>"
          );
        } else {
          return (
            `<div style='background-color: ${green}; color: white; font-weight: bold;'>` +
            done +
            "</div>"
          );
        }
      },
    },
    {
      title: "P1 Eng Today",
      field: "todaySvClosedP1",
      hozAlign: "center",
      sorter: "number",
      headerPopup: "Amount of P1 Closed with agent Second Voice Today",
      headerPopupIcon: function (component) {
        return "<i class='fas fa-bars'></i>";
      },
    },
  ];
  return salesColumns;
}
*/

/*
export function createSalesColumns(end) {
  const salesColumns = [
    {title:"Agent", field:"agent", hozAlign:"center", sorter:"string", headerSort:false},
    {
      title: "2500",
      field: "monthP1",
      hozAlign: "center",
      sorter: "number",
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams){
      var ventas = cell.getValue();
      var diasTrabajados = end.split('-')[2];
      var ventasPromedio = ventas / diasTrabajados;					
      var color = "white";					
      if (ventasPromedio <= 1 && ventas < 45) {
        color = red;
        } else if (ventasPromedio < 2 && ventasPromedio > 1 && ventas < 45) {
        color = yellow;
        } else {
        color = "#00b300";
        }						
        return "<div style='background-color: " + color + "; color: white; font-weight: bold; height: 20px; width: 100%'>" + ventas + "</div>";
      }
    },
    {
      title: "Today", 
      titleFormatter: function(cell, formatterParams) {
        return end;
      },
      field: "todayP1", 
      hozAlign: "center", 
      sorter: "number", 
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams) {
        var sold = cell.getRow().getData().todayP1;
        if(sold == 0) {
          return "<div style='background-color: #e41749; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else if(sold == 1) {
          return "<div style='background-color: #f2a600; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else {
          return "<div style='background-color: #00b300; color: white; font-weight: bold;'>" + sold + "</div>";
        }
      }
    },
  ];
  return salesColumns;
}
*/