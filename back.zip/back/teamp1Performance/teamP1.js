const strappi = "https://itback.consumerlaw.com/api";
const strappiToken = '9a51fbe5eca83f926a8f39e8070586bf767bd8ae321b1191d75b79bb7bec7a531f3152bc971bf5531085dac09897f42126cee07395d7bc55ab3966cfed3fc3661d1bc06dab93c2e5c7570da78fd8675f373f62d10b54c78f9ece436cd4b6769e6370794131ed2acab7ddfc4e37c0b378c2002227ad9a16e459db80bbac46c5bc';
const epowerProxyURL = "https://bots.consumerlaw.com/proxy";

async function getDepartmentsNames() {
  try {
    const response = await getDataStrappi(`${strappi}/departments?sort=name:asc&pagination[start]=0&pagination[limit]=200`);
    return response;
  } catch (error) {
    console.error("Error fetching departments names: ", error);
    return [];
  }
}

async function getDepartmentUsers(departmentsId) {
  try {
    const allUsers = new Map();

    // Iterar sobre los departamentos y obtener usuarios
    for (const department of departmentsId) {
      const response = await getDataStrappi( `${strappi}/accounts?filters[departments][id][$eq]=${department}`);
      // console.log(response);
      const users = response.data;
      // console.log('users', users);

      // Transformar y agregar usuarios al Map
      users.forEach((user) => {
        const userAttributes = user.attributes;
        const id = userAttributes.sugarUid;
        const fullname = userAttributes.firstName + ' ' + userAttributes.lastName;
        const phone_ext_c = userAttributes.tcxExtension;

        // Si ya existe un usuario con este ID, no lo sobrescribas
        if (!allUsers.has(id)) {
          allUsers.set(id, {
            id,
            fullname,
            phone_ext_c
          });
        }
      });
    }

    // Convertir el Map a un array
    return Array.from(allUsers.values());
  } catch (error) {
    console.error("Error fetching users from departments: ", error);
    return [];
  }
};

function getDataStrappi(url) {
  return new Promise((resolve, reject) => {
    $.ajax({
      url: url,
      method: "GET", // Cambiado a GET
      timeout: 0,
      crossDomain: true,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${strappiToken}`, // Token de autenticación
      },
      success: function (response) {
        resolve(response);
      },
      error: function (xhr, status, error) {
        reject(
          new Error(`Error fetching data from ${url}. Status: ${status}`)
        );
      },
    });
  });
}


// Envolver el código en una función async para poder usar await
(async function() {
  const team1 = await getDepartmentUsers(["157"]);
  const team2 = await getDepartmentUsers(["155"]);
  const team3 = await getDepartmentUsers(["156"]);
  const team4 = await getDepartmentUsers(["158"]);
  const team5 = await getDepartmentUsers(["159"]);
  const team6 = await getDepartmentUsers(["163"]);
  const team7 = await getDepartmentUsers(["164"]);
  const trainingSales = await getDepartmentUsers(["160"]);
  const teamP2 = await getDepartmentUsers(["83"]);

const teams = [team1, team2, team3, team4, team5, team6, team7, trainingSales, teamP2];
const teamDataCalls = {};
const totalTeamsDataCalls = {};
const teamDataSecond = {};
const totalTeamsDataSecond = {};
const totalTeamsDataEngaged = {};
const teamReferralData = {};
const totalTeamReferralData = {};
const teamP1FreeData = {};
const totalTeamP1FreeData = {};

const secondURL = "https://reports.consumerlaw.com/api/queries/532/results?api_key=vHRjdVi1FGduadWZJ63LJj7MkB6uGDBenG5oliwx";
const propertiesToTotal = [ "second_voice_po", "second_voice_total", "second_voice_engaged1"];
const teamPerformanceColumns = ["teamName", "engaged", "referralConverted", "p1SecondVoiceConversion", "totalMembers"];

const tableBody = document.querySelector("#mainBody");
const dateTitle = document.querySelector("#dateTitle");
const team1Table = document.querySelector("#team1Table");
const teamBody = document.querySelector("#teamBody");
const performanceTable = document.querySelector("#performanceTable");
const rollbackButton = document.querySelector("#rollbackButton");
const exportButton = document.querySelector("#exportButton");
const titleSelector = document.querySelector(".title-table-container");
const mainElement = document.querySelector('main');


const startInput = document.getElementById('start-date');
const endInput = document.getElementById('end-date');

let date = new Date();
date.setUTCHours(date.getUTCHours() - 5);

const end = date.toISOString().slice(0, 10);
endInput.value = end;
startInput.value = end;

let team1FullData, team2FullData, team3FullData, team4FullData, team5FullData, team6FullData, team7FullData, teamP1RemoteFullData, teamTrainingFullData, dataShow, teamP2FullData, missingTeamFullData = []

dateTitle.textContent = end;

document.addEventListener('DOMContentLoaded', updateData(end, end));
rollbackButton.addEventListener('click', () => {
  team1Table.style.display = "none";
  performanceTable.style.display = "block";
  titleSelector.style.display = "flex";
  if (mainElement) {
    mainElement.style.height = '100vh'; // Esto eliminará la propiedad 'height'
  }
  rollbackButton.style.display = "none";
});

exportButton.addEventListener('click', () => {
  tableToCSV();
});

$("#search-button").click(function() {
  updateData(startInput.value, endInput.value);
  dateTitle.textContent = startInput.value + ' to ' + endInput.value;
});

async function updateData(startDate, endDate) {
  setLoading();
  const sugarP1Data = await getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_data&fechaInicio=${startDate}&fechaFin=${endDate}`)
  const engagedP1Data = sugarP1Data.filter((data) => data.aset_id !== null);
  const referredData = await getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=referral_data&fechaInicio=${startDate}&fechaFin=${endDate}`);

  const secondVoiceEngagedP1 = await getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=sv_one_data&fechaInicio=${startDate}&fechaFin=${endDate}`)
  // const p_one_free_data = await getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_free_data&fechaInicio=${startDate}&fechaFin=${endDate}`);

  const secondVoiceEngaged = secondVoiceEngagedP1;

  /*const secondVoiceMonthData = await getDataGET(secondURL)
  const filteredSecondVoiceData = secondVoiceMonthData.query_result.data.rows.filter( item => {
    const itemDate = new Date(item.Date_second_set);
    return itemDate >= new Date(startDate) && itemDate <= new Date(endDate);
  });

  const groupedBySecondData = filteredSecondVoiceData.reduce((acc, curr) => {
    const userId = curr.user_id;
    if (!acc[userId]) {
      acc[userId] = {
        user_id: userId,
        second_voice_po: 0,
        second_voice_total: 0,
        second_voice_engaged1: 0
      }
    }

    if (curr.Total_Second_Voice_Engaged == 1) {
      acc[userId].second_voice_engaged1 += 1;
      acc[userId].second_voice_total += 1;
    } else if (curr.Total_Second_Voice_Engaged == 0) {
      acc[userId].second_voice_po += 1;
      acc[userId].second_voice_total += 1;
    }

    return acc;
  }, {});
  const groupBySecondDataArray = Object.values(groupedBySecondData);
  // const groupBySecondDataArray = secondVoiceEngaged;
  */
 const groupBySecondDataArray = secondVoiceEngaged;
  teams.forEach((team, index) => {
    const secondTeamData = addSplitSecond(team, groupBySecondDataArray, secondVoiceEngaged);
    teamDataSecond[`team${index + 1}`] = secondTeamData;
    totalTeamsDataSecond[`totalSecond${index + 1}`] = calculateTeamSecondData(secondTeamData, propertiesToTotal);

    const teamEngagedData = addSplitTeamEngaged(team, engagedP1Data);
    totalTeamsDataEngaged[`teamEngaged${index + 1}`] = teamEngagedData;

    const referredTeamData = addSplitTeamReferral(team, referredData);
    teamReferralData[`team${index + 1}`] = referredTeamData;
    totalTeamReferralData[`teamReferral${index + 1}`] = calculateTeamReferralData(referredTeamData);
  
  });

  let globalDataTeam1 = createGlobalData('Team 1', 1, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team1.length);
  let globalDataTeam2 = createGlobalData('Team 2', 2, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team2.length);
  let globalDataTeam3 = createGlobalData('Team 3', 3, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team3.length);
  let globalDataTeam4 = createGlobalData('Team 4', 4, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team4.length);
  let globalDataTeam5 = createGlobalData('Team 5', 5, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team5.length);
  let globalDataTeam6 = createGlobalData('Team 6', 6, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team6.length);
  let globalDataTeam7 = createGlobalData('Team 7', 7, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, team7.length);
  let globalDataTeamTraining = createGlobalData('TRAINING', 6, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, trainingSales.length);
  let globalDataTeamP2 = createGlobalData('TiBURONES P2', 7, totalTeamsDataEngaged, totalTeamsDataSecond, totalTeamReferralData, teamP2.length);

  const filteredDataShow = [
    globalDataTeam1,
    globalDataTeam2,
    globalDataTeam3,
    globalDataTeam4,
    globalDataTeam5,
    globalDataTeam6,
    globalDataTeam7,
    globalDataTeamTraining,
    globalDataTeamP2,
  ].filter(data => data.totalMembers > 0);

  tableBody.innerHTML = "";
  construirTabla(filteredDataShow, teamPerformanceColumns, tableBody);

  // datos para crear la vista por grupos
  let engagedData = engagedP1Data.map((item) => {
    return {
      aset_id: item.aset_id,
      p1_sold_total: item.p1_sold_total
    };
  }).filter((item) => item.p1_sold_total > 0);

  team1FullData = getExpandedTeamData(1, engagedData, teamDataSecond, teamReferralData)
  team2FullData = getExpandedTeamData(2, engagedData, teamDataSecond, teamReferralData)
  team3FullData = getExpandedTeamData(3, engagedData, teamDataSecond, teamReferralData)
  team4FullData = getExpandedTeamData(4, engagedData, teamDataSecond, teamReferralData)
  team5FullData = getExpandedTeamData(5, engagedData, teamDataSecond, teamReferralData)
  team6FullData = getExpandedTeamData(6, engagedData, teamDataSecond, teamReferralData)
  team7FullData = getExpandedTeamData(7, engagedData, teamDataSecond, teamReferralData)
  teamTrainingFullData = getExpandedTeamData(6, engagedData, teamDataSecond, teamReferralData)
  teamP2FullData = getExpandedTeamData(7, engagedData, teamDataSecond, teamReferralData)

}

function setLoading() {
  for (let i = 0; i < tableBody.rows.length; i++) {
    const cells = tableBody.rows[i].cells;
    for (let j = 0; j < cells.length; j++) {
      cells[j].textContent = "Loading...";
    }
  }
}

function addSplitSecond(team, secondVoiceData, secondVoiceEngaged) {
  return team.map((item) => {
    const match = secondVoiceData.find((data) => data.user_id === item.id);
    const matchEngaged = secondVoiceEngaged.find((data) => data.sv_id === item.id);
    return {
      ...item,
      second_voice_po: match ? match.second_voice_po : 0,
      second_voice_total: match ? match.second_voice_total : 0,
      second_voice_engaged1: matchEngaged ? parseInt(matchEngaged.sv_engaged_total) : 0
    };
  });
}

function calculateTeamSecondData(teamData, properties) {
  return properties.reduce((result, property) => {
    result[property] = teamData.reduce((total, item) => total + (item[property] || 0), 0);
    return result;
  }, {});
}

function addSplitTeamEngaged(team, engagedData) {
  let teamData=  team.map((item) => {
    const match = engagedData.find((data) => data.aset_id === item.id);
    return {
      id: match ? match.aset_id : item.id,
      engaged: match ? parseInt(match.p1_sold_total) : 0
    };
  }).filter((item) => item.engaged > 0);

  return teamData.reduce((total, item) => total + item.engaged, 0);
}

function addSplitTeamReferral(team, referralData) {

  const engagedCount = referralData.reduce((acc, referral) => {
      if (acc[referral.user_id]) {
        acc[referral.user_id]++;
      } else {
        acc[referral.user_id] = 1;
      }
    return acc;
  }, {});

  return team.map((item) => ({
    ...item,
    engaged_referred: engagedCount[item.fullname] || 0
  }));
}

function calculateTeamReferralData(teamData) {
  return teamData.reduce((acc, item) => {
    acc.engaged_referred = (acc.engaged_referred || 0) + (item.engaged_referred || 0);
    return acc;
  }, {});
}

function construirTabla(data, columnas, contenedor) {
  data.sort((a, b) => b.engaged - a.engaged); 
  if (data.length > 9) {
    data.sort((a, b) => b.engaged - a.engaged); 
  }
  data.forEach((item) => {
    const row = document.createElement("tr");
    if (data.length < 9) {
      row.addEventListener("click", () => {
        rowClickFunction(item);
      });
    }

    columnas.forEach((columna) => {
      const cell = document.createElement("td");
      cell.textContent = item[columna];
      row.appendChild(cell);
    });

    contenedor.appendChild(row);
  });
}

function getExpandedTeamData(teamId, engagedData, secondVoiceData, referralData) {
  const team = teams[teamId - 1];
  const teamSecondVoiceKey = `team${teamId}`;
  const teamUsersSecondVoice = secondVoiceData[teamSecondVoiceKey];
  const teamReferralKey = `team${teamId}`;
  const teamUsersReferral = referralData[teamReferralKey];

  if (teamId === 9) {
    console.log('calls', teamUsersSecondVoice, teamUsersReferral);
  }

  let dataOut = team.map((item) => {
    const names = item.fullname.split(' ');
    const formattedName = names[0] + " " + names[1] + " " + names[2];
    const matchP1 = engagedData.find((data) => data.aset_id === item.id);
    const matchSecondVoice = teamUsersSecondVoice.find((data) => data.id === item.id);
    const matchReferral = teamUsersReferral.find((data) => data.id === item.id);
    return {
      id: item.id,
      agent: formattedName,
      engaged: matchP1 ? parseInt(matchP1.p1_sold_total) : 0,
      engaged_referred: matchReferral ? parseInt(matchReferral.engaged_referred) : 0,
      total_referred: matchReferral ? parseInt(matchReferral.total_referred) : 0,
      second_voice_engaged1: matchSecondVoice ? parseInt(matchSecondVoice.second_voice_engaged1) : 0,
      second_voice_total: matchSecondVoice ? parseInt(matchSecondVoice.second_voice_total) : 0,
    };
  })

  if (teamId === 8) {
    dataOut = dataOut.filter((item) => item.engaged > 0)
  }

  return dataOut;
}

function rowClickFunction(team){
  teamBody.innerHTML = "";
  if (team.teamName === 'Team 1') {
    construirTabla(team1FullData, ["agent", "engaged", "engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'Team 2') {
    construirTabla(team2FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'Team 3') {
    construirTabla(team3FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'Team 4') {
    construirTabla(team4FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'Team 5') {
    construirTabla(team5FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'Team 6') {
    construirTabla(team6FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'Team 7') {
    construirTabla(team7FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'TRAINING') {
    construirTabla(teamTrainingFullData, ["agent", "engaged", "engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'TiBURONES P2') {
    construirTabla(teamP2FullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);
  } else if (team.teamName === 'P1 REMOTE') {
    construirTabla(teamP1RemoteFullData, ["agent", "engaged","engaged_referred", "second_voice_engaged1", "second_voice_total"], teamBody);    
  }  else {
    construirTabla(missingTeamFullData, ["name", "engaged", "totalTalkingTime"], teamBody);
  }

  if (mainElement) {
    mainElement.style.height = 'auto'; // Esto eliminará la propiedad 'height'
  }
  
  team1Table.style.display = "block";
  performanceTable.style.display = "none";
  titleSelector.style.display = "none";
  rollbackButton.style.display = "flex";
}

function tableToCSV() {
  
  // Variable to store the final csv data
  let csv_data = [];

  // Get each row data
  let rows = document.getElementsByTagName('tr');
  for (let i = 0; i < rows.length; i++) {

      // Get each column data
      let cols = rows[i].querySelectorAll('td,th');

      // Stores each csv row data
      let csvrow = [];
      for (let j = 0; j < cols.length; j++) {

          // Get the text data of each cell
          // of a row and push it to csvrow
          csvrow.push(cols[j].innerHTML);
      }

      // Combine each column value with comma
      csv_data.push(csvrow.join(","));
  }

  // Combine each row data with new line character
  csv_data = csv_data.join('\n');

  // Call this function to download csv file  
  downloadCSVFile(csv_data);

}

function downloadCSVFile(csv_data) {

  // Create CSV file object and feed
  // our csv_data into it
  let CSVFile = new Blob([csv_data], {
      type: "text/csv"
  });

  // Create to temporary link to initiate
  // download process
  let temp_link = document.createElement('a');

  // Download csv file
  temp_link.download = "teams_performance.csv";
  let url = window.URL.createObjectURL(CSVFile);
  temp_link.href = url;

  // This link should not be displayed
  temp_link.style.display = "none";
  document.body.appendChild(temp_link);

  // Automatically click the link to
  // trigger download
  temp_link.click();
  document.body.removeChild(temp_link);
}

function sortTable(n, isNumber = false) {
  let table = document.querySelector(".data-table");
  let rows = Array.from(table.rows).slice(1); // Convertir HTMLCollection a array y excluir el encabezado

  rows.sort((rowA, rowB) => {
    let cellA = rowA.cells[n].innerText;
    let cellB = rowB.cells[n].innerText;

    if (isNumber) { // Convertir a número y restar para obtener un valor de comparación
      return Number(cellA) - Number(cellB);
    } else {  // Comparar alfabéticamente
      return cellA.localeCompare(cellB);
    }
  });

  rows.forEach(row => { // Reinsertar las filas en la tabla
    table.tBodies[0].appendChild(row);
  });
}

const tableHeaders = document.getElementById('table-headers');

// leer la tabla y por cada columna agregar un evento de click y el mouse pointer se convierta en un cursor
for (let i = 0; i < tableHeaders.rows[0].cells.length; i++) {
  tableHeaders.rows[0].cells[i].addEventListener("click", () => {
    sortTable(i);
  });
}

function createGlobalData(teamName, teamIndex, teamDataEngaged, teamDataSecond, teamDataReferral, totalMembers) {
  const teamEngagedKey = `teamEngaged${teamIndex}`;
  const teamTotalEngaged = teamDataEngaged[teamEngagedKey];
  const teamSecondVoiceKey = `totalSecond${teamIndex}`;
  const teamTotalSecondVoice = teamDataSecond[teamSecondVoiceKey];
  const totalReferralKey = `teamReferral${teamIndex}`;
  const teamTotalReferral = teamDataReferral[totalReferralKey];

  return {
    teamName,
    engaged: teamTotalEngaged,
    referralConverted: teamTotalReferral.engaged_referred ? parseInt(teamTotalReferral.engaged_referred) : 0,
    p1SecondVoiceConversion: ((teamTotalSecondVoice.second_voice_engaged1 / (teamTotalSecondVoice.second_voice_total )) * 100).toFixed(2) + '%',
    totalMembers,
  };
}

function getDataGET(url) {
	return new Promise((resolve, reject) => {
		$.ajax({
			url: epowerProxyURL,
			method: "POST",
			timeout: 0,
			crossDomain: true,
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			data: JSON.stringify({
				parameters: {},
				url: `${url}`,
			}),
			success: function (response) {
				resolve(response);
			},
			error: function (xhr, status, error) {
				reject(
					new Error(`Error fetching data from ${url}. Status: ${status}`)
				);
			},
		});
	});
}

async function getDataFromSugarTeam(teamId) {
  try {
    const usersBySugarTeamURLAPI = `https://home.justicialaboral.com/bot_db/api/get_users_by_team.php?teamId=${teamId}`;
    const datosConExtension = await getDataGET(usersBySugarTeamURLAPI);

    return datosConExtension;
  } catch (error) {
    console.error(error);
    return [];
  }
}


})();

