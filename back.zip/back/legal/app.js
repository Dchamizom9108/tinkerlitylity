class ProxyService {
    async getDataGET(url) {
        const epowerProxyURL = "https://bots.consumerlaw.com/proxy";
        try {
            const response = await fetch(epowerProxyURL, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    parameters: {},
                    url: url
                })
            });
            const data = await response.json();
            return data;
        } catch (error) {
            throw new Error(`Error fetching data from ${url}. Status: ${error.message}`);
        }
    }
}

const proxyService = new ProxyService();

// Variables de estado
let userData = [];
let waittingCalls = 0;
let servicedCalls = 0;
let abandonedCalls = 0;

// Función para obtener datos
async function fetchData() {
    try {
        const result = await proxyService.getDataGET("https://home.justicialaboral.com/bot_db/api/legal.php");
        userData = result;

        // Sumar los valores de llamadas en espera, atendidas y abandonadas
        waittingCalls = result[0].calls_waiting;
        servicedCalls = result[0].calls_serviced;
        abandonedCalls = result[0].calls_abandoned;

        renderData();
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}

// Función para renderizar la interfaz
function renderData() {
    const availableUsers = userData.filter(user => user.agent_status === "available");

    document.getElementById('app').innerHTML = `
        <div class="container">
            <div class="userList">
                <ul class="userColumns">
                    <div class="userColumn">
                        ${availableUsers.slice(0, Math.ceil(availableUsers.length / 2))
                            .map(user => `<li>${user.fullname.split(" ")[0]} ${user.fullname.split(" ")[1]}</li>`).join('')}
                    </div>
                    <div class="userColumn">
                        ${availableUsers.slice(Math.ceil(availableUsers.length / 2))
                            .map(user => `<li>${user.fullname.split(" ")[0]} ${user.fullname.split(" ")[1]}</li>`).join('')}
                    </div>
                </ul>
            </div>

            <div class="callStats">
                <h1 class="countdown ${waittingCalls > 0 ? 'overTime' : 'onTime'}">${waittingCalls}</h1>
                <p class="waitingLabel">Waiting Calls</p>
                <div class="callsInfoRow">
                    <div class="callsInfo">
                        <h1 class="serviced">${servicedCalls}</h1>
                        <p>Serviced Calls:</p>
                    </div>
                    <div class="callsInfo">
                        <h1 class="unanswered">${abandonedCalls}</h1>
                        <p>Abandoned Calls:</p>
                        
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Configuración del intervalo para actualizar cada 6 segundos
fetchData();
setInterval(fetchData, 6000);
