/*
const dateInput = document.getElementById("date-input");
const epowerProxyURL = "https://bots.consumerlaw.com/proxy";
const epowerProxyGetSugarDataURL =
  "https://bots.consumerlaw.com/proxy_sugar_data";

const stringMonth = [
  "january",
  "february",
  "march",
  "april",
  "may",
  "june",
  "july",
  "august",
  "september",
  "october",
  "november",
  "december",
];

let adjustedDate = new Date();
adjustedDate.setUTCHours(adjustedDate.getUTCHours() - 5);

const numberMonth = adjustedDate.getMonth() + 1;
console.log(numberMonth);
const actualMonth = stringMonth[numberMonth - 1];

let end = adjustedDate.toISOString().slice(0, 10);
dateInput.value = end;
let dataTable = [];

window.onload = function () {
  updateData(end);
};

dateInput.addEventListener("change", (event) => {
  let end = event.target.value;
  updateData(end);
});

function updateData(end) {
  const apiAllFromURLMonth = `https://home.justicialaboral.com/bot_db/api/national.php?month=${actualMonth}`;

  getDataGET(apiAllFromURLMonth)
    .then((monthDataP1) => {
      const onlyThisMonthP1 = monthDataP1.filter(
        (item) =>
          item.p1_sold_date_c !== null &&
          parseFloat(item.p1_amount) > 45 
      )

      const groupedP1 = onlyThisMonthP1.reduce((acc, item) => {
        const agent = item.as_name || "Desconocido";

        // Ajustar el horario de p1_sold_date_c y comparar con el end
        const originalDate = new Date(item.p1_sold_date_c); // Crear un objeto Date a partir del valor original
        originalDate.setHours(originalDate.getHours() - 10); // Restar 6 horas
        const adjustedDateWithTime = originalDate.toISOString(); // Extraer solo la fecha ajustada
        const adjustedDate = originalDate.toISOString().split("T")[0]; // Extraer solo la fecha ajustada
        const isToday = adjustedDate === end; // Comparar con la fecha final

        if (!acc[agent]) {
          acc[agent] = {
            agent,
            p1_sold_month: 0,
            p1_sold_today: 0,
            _children: [], // Inicializar la lista de detalles de ventas
          };
        }

        // Incrementar las cantidades
        acc[agent].p1_sold_month += 1;
        if (isToday) {
          acc[agent].p1_sold_today += 1;
        }

        // Agregar los detalles de la venta al _children
        acc[agent]._children.push({
          agent: item.id,
          p1_sold_month: `https://sugar.consumerlaw.com/#Leads/${item.lead_id}`,
          p1_sold_today: adjustedDateWithTime.split(".")[0],
        });

        return acc;
      }, {});

      const childrenSorted = Object.values(groupedP1).reduce((acc, item) => {
        acc[item.agent] = item._children.sort((a, b) => {
          const dateA = new Date(a.p1_sold_today);
          const dateB = new Date(b.p1_sold_today);
          return dateB - dateA;
        });
        return acc;
      }, {});

      groupedP1._children = childrenSorted;

      // Convertir el objeto a un array y ordenar los datos por ventas mensuales
      const finalP1Data = Object.values(groupedP1).sort((a, b) => b.p1_sold_month - a.p1_sold_month);

      console.log(finalP1Data);

      const salesTable = new Tabulator("#sales-container", {
        data: finalP1Data,
        layout: "fitDataTable",
        columns: [
          { title: "Agent", field: "agent", hozAlign: "center", sorter: "string" },
          {
            title: "3000",
            field: "p1_sold_month",
            hozAlign: "center",
            sorter: "number",
            topCalc: "sum",
            headerSort: true,
            formatter: function (cell, formatterParams) {
              if (!cell.getRow().getTreeParent()) {
                // Aplicar formato solo a nodos primarios
                var ventas = cell.getValue();
                var diasTrabajados = end.split("-")[2];
                var ventasPromedio = ventas / diasTrabajados;
                var color = "white";
                if (ventasPromedio <= 1 && ventas < 45) {
                  color = "#e41749";
                } else if (ventasPromedio < 2 && ventasPromedio > 1 && ventas < 45) {
                  color = "#ff4b07";
                } else {
                  color = "#00b300";
                }
                return (
                  "<div style='background-color: " +
                  color +
                  "; color: white; font-weight: bold; height: 20px; width: 100%'>" +
                  ventas +
                  "</div>"
                );
              }
              return cell.getValue(); // Sin formato para los hijos
            },
          },
          {
            title: "Today",
            titleFormatter: function (cell, formatterParams) {
              return end;
            },
            field: "p1_sold_today",
            hozAlign: "center",
            sorter: "number",
            topCalc: "sum",
            headerSort: true,
            formatter: function (cell, formatterParams) {
              if (!cell.getRow().getTreeParent()) {
                // Aplicar formato solo a nodos primarios
                var sold = cell.getRow().getData().p1_sold_today;
                if (sold == 0) {
                  return (
                    "<div style='background-color: #e41749; color: white; font-weight: bold;'>" +
                    sold +
                    "</div>"
                  );
                } else if (sold == 1) {
                  return (
                    "<div style='background-color: #f2a600; color: white; font-weight: bold;'>" +
                    sold +
                    "</div>"
                  );
                } else {
                  return (
                    "<div style='background-color: #00b300; color: white; font-weight: bold;'>" +
                    sold +
                    "</div>"
                  );
                }
              }
              return cell.getValue(); // Sin formato para los hijos
            },
          },
        ],
        dataTree: true, // Habilitar DataTree
        dataTreeChildField: "_children", // Indicar dónde están los datos hijos
        dataTreeStartExpanded: false, // Opcional: Expandir inicialmente o no
        dataTreeChildIndent: 15, // Ajustar la indentación de los hijos
      });

      // Agregar funcionalidad de descarga
      document
        .getElementById("download-xlsx")
        .addEventListener("click", function () {
          salesTable.download("csv", "data.csv");
        });
    })
    .catch((error) => {
      console.log("repeat", error);
    });
}


function getStartDate(date) {
  const year = date.split("-")[0];
  const month = date.split("-")[1];
  const start = `${year}-${month}-01`;
  return start;
}

function getDataGET(url) {
  return new Promise((resolve, reject) => {
    $.ajax({
      url: epowerProxyURL,
      method: "POST",
      timeout: 0,
      crossDomain: true,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: JSON.stringify({
        parameters: {},
        url: `${url}`,
      }),
      success: function (response) {
        resolve(response);
      },
      error: function (xhr, status, error) {
        reject(new Error(`Error fetching data from ${url}. Status: ${status}`));
      },
    });
  });
}
*/
const dateInput = document.getElementById('date-input');
const epowerProxyURL = "https://bots.consumerlaw.com/proxy"
const epowerProxyGetSugarDataURL = "https://bots.consumerlaw.com/proxy_sugar_data"

let adjustedDate = new Date();
adjustedDate.setUTCHours(adjustedDate.getUTCHours() - 5);
let end = adjustedDate.toISOString().slice(0, 10);
dateInput.value = end;
let dataTable = [];

window.onload = function() {
	updateData(end);
}

dateInput.addEventListener('change', (event) => {
	let end = event.target.value;
	updateData(end);
});

const salesTable = new Tabulator("#sales-container", {
	data:dataTable,
	layout:"fitDataTable",
	columns: [
    {title:"Agent", field:"agent", hozAlign:"center", sorter:"string"},
    {
      title: "3000",
      field: "monthP1",
      hozAlign: "center",
      sorter: "number",
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams){
      var ventas = cell.getValue();
      var diasTrabajados = end.split('-')[2];
      var ventasPromedio = ventas / diasTrabajados;					
      var color = "white";					
      if (ventasPromedio <= 1 && ventas < 45) {
        color = "#e41749";
        } else if (ventasPromedio < 2 && ventasPromedio > 1 && ventas < 45) {
        color = "#ff4b07";
        } else {
        color = "#00b300";
        }						
        return "<div style='background-color: " + color + "; color: white; font-weight: bold; height: 20px; width: 100%'>" + ventas + "</div>";
      }
    },
    {
      title: "Today", 
      titleFormatter: function(cell, formatterParams) {
        return end;
      },
      field: "todayP1", 
      hozAlign: "center", 
      sorter: "number", 
      topCalc: "sum",
      headerSort: true,
      formatter: function(cell, formatterParams) {
        var sold = cell.getRow().getData().todayP1;
        if(sold == 0) {
          return "<div style='background-color: #e41749; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else if(sold == 1) {
          return "<div style='background-color: #f2a600; color: white; font-weight: bold;'>" + sold + "</div>";
        }
        else {
          return "<div style='background-color: #00b300; color: white; font-weight: bold;'>" + sold + "</div>";
        }
      }
    },
  ],
});

function updateData(end) {
	let start = getStartDate(end);

  const apiAllFromURLMonth = `https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_data&fechaInicio=${start}&fechaFin=${end}`;
  const apiAllFromURLToday = `https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_data&fechaInicio=${end}&fechaFin=${end}`;

  getDataGET(apiAllFromURLMonth).then( (monthDataP1) => {
    getDataGET(apiAllFromURLToday).then( (todayDataP1) => {
      // map and filter data
      monthDataP1 = mapAndFilterDataP1( monthDataP1, "as_name", ["p1_sold_total", "p1_amount"], ["monthP1", "p1_amount_total"] );

      todayDataP1 = mapAndFilterDataP1( todayDataP1, "as_name", ["p1_sold_total"], ["todayP1"] );

      let result = monthDataP1.map(item1 => {
        const item2 = todayDataP1.find(item => item.agent === item1.agent);
        return {
          ...item1,
          ...(item2 ? item2 : { todayP1: "0" })
        };
      });				  

      let finalData = result;
      // ordenar result por cantidad de p1
      finalData.sort((a, b) => {return b.monthP1 - a.monthP1;});
      /////////////////////////////////////////START OF CODE/////////////////////////////////////////
      salesTable.setData(finalData);
      document.getElementById("download-xlsx").addEventListener("click", function(){
        salesTable.download("csv", "data.csv");
      });
    }).catch(error => {
		console.log('repeat', error);
    })
    .catch(error => {
      console.log('repeat', error);
    });
  });
}

function getStartDate (date) {
  const year = date.split("-")[0];
  const month = date.split("-")[1];
  const start = `${year}-${month}-01`;
  return start;
}

function getDataGET(url) {
	return new Promise((resolve, reject) => {
		$.ajax({
			url: epowerProxyURL,
			method: "POST",
			timeout: 0,
			crossDomain: true,
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			data: JSON.stringify({
				parameters: {},
				url: `${url}`,
			}),
			success: function (response) {
				resolve(response);
			},
			error: function (xhr, status, error) {
				reject(
					new Error(`Error fetching data from ${url}. Status: ${status}`)
				);
			},
		});
	});
}

function mapAndFilterDataP1(data, keyName, otherKeys, newKeyNames) {  // Map and filter the data for P1
  return data
    .map((lead) => {
      const names = lead[keyName].trim().split(" ");
      // const agentName = names[0] + " " + names[1] + " " + names[2];
      const agentName = names[0] + " " + names[1] ;
      const newData = { agent: agentName };

      otherKeys.forEach((key, index) => {
        const newKeyName = newKeyNames[index];
        newData[newKeyName] = parseInt(lead[key]) || 0;
      });

      return newData;
    })
    .filter((item) => item.agent !== "" && otherKeys.every((key) => item[key] !== 0)
  );
}