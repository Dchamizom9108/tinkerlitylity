<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sitio en Construcción</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .container {
      text-align: center;
      padding: 20px;
      background-color: #ffffff;
      border-radius: 8px;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    }

    h1 {
      color: #333;
      font-size: 36px;
      margin-bottom: 10px;
    }

    p {
      color: #666;
      font-size: 18px;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Sitio en Reparacion</h1>
    <p>Favor esperar</p>
  </div>
</body>

</html>