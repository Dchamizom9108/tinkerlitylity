const strappi = "https://itback.consumerlaw.com/api";
const strappiToken =
  "9a51fbe5eca83f926a8f39e8070586bf767bd8ae321b1191d75b79bb7bec7a531f3152bc971bf5531085dac09897f42126cee07395d7bc55ab3966cfed3fc3661d1bc06dab93c2e5c7570da78fd8675f373f62d10b54c78f9ece436cd4b6769e6370794131ed2acab7ddfc4e37c0b378c2002227ad9a16e459db80bbac46c5bc";
const epowerProxyURL = "https://bots.consumerlaw.com/proxy";

async function getDepartmentsNames() {
  try {
    const response = await getDataStrappi(
      `${strappi}/departments?sort=name:asc&pagination[start]=0&pagination[limit]=200`
    );
    return response;
  } catch (error) {
    console.error("Error fetching departments names: ", error);
    return [];
  }
}

async function getDataFromPerformance(date) {
  try {
    const response = await getDataStrappi(
      `${strappi}/performances?filters[date]=${date}`
    );
    return response;
  } catch (error) {
    console.error("Error fetching performance data: ", error);
    return [];
  }
}

async function getDepartmentUsers(departmentsId) {
  try {
    const allUsers = new Map();

    // Iterar sobre los departamentos y obtener usuarios
    for (const department of departmentsId) {
      const response = await getDataStrappi(
        `${strappi}/accounts?filters[departments][id][$eq]=${department}`
      );
      // console.log(response);
      const users = response.data;
      // console.log('users', users);

      // Transformar y agregar usuarios al Map
      users.forEach((user) => {
        const userAttributes = user.attributes;
        const id = userAttributes.sugarUid;
        const fullname =
          userAttributes.firstName + " " + userAttributes.lastName;
        const phone_ext_c = userAttributes.tcxExtension;

        // Si ya existe un usuario con este ID, no lo sobrescribas
        if (!allUsers.has(id)) {
          allUsers.set(id, {
            id,
            fullname,
            phone_ext_c,
          });
        }
      });
    }

    // Convertir el Map a un array
    return Array.from(allUsers.values());
  } catch (error) {
    console.error("Error fetching users from departments: ", error);
    return [];
  }
}

function getDataStrappi(url) {
  return new Promise((resolve, reject) => {
    $.ajax({
      url: url,
      method: "GET", // Cambiado a GET
      timeout: 0,
      crossDomain: true,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${strappiToken}`, // Token de autenticación
      },
      success: function (response) {
        resolve(response);
      },
      error: function (xhr, status, error) {
        reject(new Error(`Error fetching data from ${url}. Status: ${status}`));
      },
    });
  });
}

// Envolver el código en una función async para poder usar await
(async function () {
  const team1 = await getDepartmentUsers(["157"]);
  const team2 = await getDepartmentUsers(["155"]);
  const team3 = await getDepartmentUsers(["156"]);
  const team4 = await getDepartmentUsers(["158"]);
  const team5 = await getDepartmentUsers(["159"]);
  const team6 = await getDepartmentUsers(["163"]);
  const team7 = await getDepartmentUsers(["164"]);
  const trainingSales = await getDepartmentUsers(["160"]);
  const teamP2 = await getDepartmentUsers(["83"]);

  const teams = [
    team1,
    team2,
    team3,
    team4,
    team5,
    team6,
    team7,
    trainingSales,
    teamP2,
  ];
  const teamDataCalls = {};
  const totalTeamsDataCalls = {};
  const teamDataSecond = {};
  const totalTeamsDataSecond = {};
  const totalTeamsDataEngaged = {};
  const teamReferralData = {};
  const totalTeamReferralData = {};

  const secondURL =
    "https://reports.consumerlaw.com/api/queries/532/results?api_key=vHRjdVi1FGduadWZJ63LJj7MkB6uGDBenG5oliwx";

  const teamPerformanceColumns = [
    "teamName",
    "engaged",
    "referralConverted",
    "p1SecondVoiceConversion",
    "totalMembers",
  ];

  const tableBody = document.querySelector("#mainBody");
  const dateTitle = document.querySelector("#dateTitle");
  const team1Table = document.querySelector("#team1Table");
  const teamBody = document.querySelector("#teamBody");
  const performanceTable = document.querySelector("#performanceTable");
  const rollbackButton = document.querySelector("#rollbackButton");
  const exportButton = document.querySelector("#exportButton");
  const titleSelector = document.querySelector(".title-table-container");
  const mainElement = document.querySelector("main");

  const startInput = document.getElementById("start-date");
  const endInput = document.getElementById("end-date");

  let date = new Date();
  date.setUTCHours(date.getUTCHours() - 5);

  const end = date.toISOString().slice(0, 10);
  endInput.value = end;
  startInput.value = end;

  let team1FullData,
    team2FullData,
    team3FullData,
    team4FullData,
    team5FullData,
    team6FullData,
    team7FullData,
    teamP1RemoteFullData,
    teamTrainingFullData,
    dataShow,
    teamP2FullData,
    missingTeamFullData = [];

  dateTitle.textContent = end;

  document.addEventListener("DOMContentLoaded", updateData(end, end));
  rollbackButton.addEventListener("click", () => {
    team1Table.style.display = "none";
    performanceTable.style.display = "block";
    titleSelector.style.display = "flex";
    if (mainElement) {
      mainElement.style.height = "100vh"; // Esto eliminará la propiedad 'height'
    }
    rollbackButton.style.display = "none";
  });

  exportButton.addEventListener("click", () => {
    tableToCSV();
  });

  $("#search-button").click(function () {
    updateData(startInput.value, endInput.value);
    dateTitle.textContent = startInput.value + " to " + endInput.value;
  });
  async function updateData(startDate, endDate) {
    setLoading();

    let dataFromStrappi = await getDataFromPerformance(endDate);
    dataFromStrappi = dataFromStrappi?.data[0].attributes?.data;
    console.log(dataFromStrappi);

    let groupedEngagedData = dataFromStrappi
      .filter((item) => item.p1_sold_date_c !== null && item.as_name !== null)
      .reduce((acc, item) => {
        if (!acc[item.as_name]) {
          acc[item.as_name] = [];
        }
        acc[item.as_name].push(item);
        return acc;
      }, {});

    console.log(
      "Grouped Engaged Data (antes de filtrar por fecha):",
      groupedEngagedData
    );

    // Filtrar por fecha en cada grupo de usuario
    for (const asName in groupedEngagedData) {
      groupedEngagedData[asName] = groupedEngagedData[asName].filter(
        (engagement) => {
          const soldDate = new Date(engagement.p1_sold_date_c)
            .toISOString()
            .slice(6, 7);
          return soldDate === new Date(endDate).toISOString().slice(6, 7);
        }
      );

      // Eliminar el grupo si quedó vacío después del filtrado
      if (groupedEngagedData[asName].length === 0) {
        delete groupedEngagedData[asName];
      }
    }

    teams.forEach((team, index) => {
      const secondTeamData = addSplitSecond(
        team,
        groupedEngagedData
      );
      teamDataSecond[`team${index + 1}`] = secondTeamData;
      totalTeamsDataSecond[`totalSecond${index + 1}`] = calculateTeamSecondData(
        secondTeamData
      );

      const teamEngagedData = addSplitTeamEngaged(team, groupedEngagedData);
      totalTeamsDataEngaged[`teamEngaged${index + 1}`] = teamEngagedData;

      const referredTeamData = addSplitTeamReferral(team, groupedEngagedData);
      teamReferralData[`team${index + 1}`] = referredTeamData;
      totalTeamReferralData[`teamReferral${index + 1}`] =
        calculateTeamReferralData(referredTeamData);
    });

    let globalDataTeam1 = createGlobalData(
      "Team 1",
      1,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team1.length
    );
    let globalDataTeam2 = createGlobalData(
      "Team 2",
      2,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team2.length
    );
    let globalDataTeam3 = createGlobalData(
      "Team 3",
      3,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team3.length
    );
    let globalDataTeam4 = createGlobalData(
      "Team 4",
      4,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team4.length
    );
    let globalDataTeam5 = createGlobalData(
      "Team 5",
      5,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team5.length
    );
    let globalDataTeam6 = createGlobalData(
      "Team 6",
      6,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team6.length
    );
    let globalDataTeam7 = createGlobalData(
      "Team 7",
      7,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      team7.length
    );
    let globalDataTeamTraining = createGlobalData(
      "TRAINING",
      6,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      trainingSales.length
    );
    let globalDataTeamP2 = createGlobalData(
      "TiBURONES P2",
      7,
      totalTeamsDataEngaged,
      totalTeamsDataSecond,
      totalTeamReferralData,
      teamP2.length
    );

    const filteredDataShow = [
      globalDataTeam1,
      globalDataTeam2,
      globalDataTeam3,
      globalDataTeam4,
      globalDataTeam5,
      globalDataTeam6,
      globalDataTeam7,
      globalDataTeamTraining,
      globalDataTeamP2,
    ].filter((data) => data.totalMembers > 0);

    tableBody.innerHTML = "";
    construirTabla(filteredDataShow, teamPerformanceColumns, tableBody);

    team1FullData = getExpandedTeamData(
      1,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    team2FullData = getExpandedTeamData(
      2,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    team3FullData = getExpandedTeamData(
      3,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    team4FullData = getExpandedTeamData(
      4,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    team5FullData = getExpandedTeamData(
      5,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    team6FullData = getExpandedTeamData(
      6,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    team7FullData = getExpandedTeamData(
      7,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    teamTrainingFullData = getExpandedTeamData(
      6,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
    teamP2FullData = getExpandedTeamData(
      7,
      groupedEngagedData,
      teamDataSecond,
      teamReferralData
    );
  }

  function setLoading() {
    for (let i = 0; i < tableBody.rows.length; i++) {
      const cells = tableBody.rows[i].cells;
      for (let j = 0; j < cells.length; j++) {
        cells[j].textContent = "Loading...";
      }
    }
  }

  function addSplitSecond(team, groupedEngagedData) {
    // Primero creamos un mapa de todos los second voice cases por sv1_id
    const secondVoiceMap = Object.values(groupedEngagedData)
      .flat()
      .reduce((acc, engagement) => {
        if (engagement.sv1_id) {
          if (!acc[engagement.sv1_id]) {
            acc[engagement.sv1_id] = [];
          }
          acc[engagement.sv1_id].push(engagement);
        }
        return acc;
      }, {});
    // console.log(secondVoiceMap, console.log('team', team));
  
    return team.map((member) => {
      const cases = secondVoiceMap[member.id] || [];
  
      return {
        ...member,
        second_voice_total: cases.length,
      };
    });
  }

  function calculateTeamSecondData(teamData) {
    return teamData.reduce((acc, item) => {
      acc.second_voice_total =
        (acc.second_voice_total || 0) + (item.second_voice_total || 0);
      return acc;
    }, {});
  }

  function addSplitTeamEngaged(team, engagedData) {
    // 1. Mapear el equipo y buscar coincidencias
    const teamData = team
      .map((item) => {
        const matches = engagedData[item.fullname]; // Accedemos directamente al grupo

        // Si hay matches, sumamos todos los p1_amount de ese asesor
        const engagedTotal = matches ? matches.length : 0;

        return {
          id: item.id,
          fullname: item.fullname,
          engaged: engagedTotal,
        };
      })
      .filter((item) => item.engaged > 0);
    // console.log(teamData);

    // 3. Sumar todos los engaged del equipo
    return teamData.reduce((total, item) => total + item.engaged, 0);
  }

  function addSplitTeamReferral(team, groupedEngagedData) {
    const referralCounts = Object.entries(groupedEngagedData).reduce(
      (acc, [asName, engagements]) => {
        acc[asName] = engagements.filter(
          (e) => e.utm_source_name === "03 - REFERRAL"
        ).length;
        return acc;
      },
      {}
    );

    return team.map((item) => ({
      ...item,
      engaged_referred: referralCounts[item.fullname] || 0,
    }));
  }

  function calculateTeamReferralData(teamData) {
    return teamData.reduce((acc, item) => {
      acc.engaged_referred =
        (acc.engaged_referred || 0) + (item.engaged_referred || 0);
      return acc;
    }, {});
  }

  function construirTabla(data, columnas, contenedor) {
    data.sort((a, b) => b.engaged - a.engaged);
    if (data.length > 9) {
      data.sort((a, b) => b.engaged - a.engaged);
    }
    data.forEach((item) => {
      const row = document.createElement("tr");
      if (data.length < 9) {
        row.addEventListener("click", () => {
          rowClickFunction(item);
        });
      }

      columnas.forEach((columna) => {
        const cell = document.createElement("td");
        cell.textContent = item[columna];
        row.appendChild(cell);
      });

      contenedor.appendChild(row);
    });
  }

  function getExpandedTeamData(
    teamId,
    groupedEngagedData,
    secondVoiceData,
    referralData
  ) {
    const team = teams[teamId - 1];
    const teamSecondVoiceKey = `team${teamId}`;
    const teamUsersSecondVoice = secondVoiceData[teamSecondVoiceKey] || [];
    const teamReferralKey = `team${teamId}`;
    const teamUsersReferral = referralData[teamReferralKey] || [];

    let dataOut = team.map((item) => {
      const names = item.fullname.split(" ");
      const formattedName =
        names[0] + " " + (names[1] || "") + " " + (names[2] || "");

      // Procesar engagedData (ahora agrupado)
      const engagedMatches = groupedEngagedData[item.fullname] || [];
      const engagedTotal = engagedMatches.reduce(
        (sum, match) => sum + parseFloat(match.p1_amount || 0),
        0
      );
      const engagedCount = engagedMatches.length;

      // Procesar second voice data
      const matchSecondVoice = teamUsersSecondVoice.find(
        (data) => data.id === item.id
      );

      // Procesar referral data
      const matchReferral = teamUsersReferral.find(
        (data) => data.id === item.id
      );

      return {
        id: item.id,
        agent: formattedName,
        engaged: engagedCount, // Cantidad de engaged
        engaged_amount: engagedTotal, // Monto total de engaged
        engaged_referred: matchReferral
          ? parseInt(matchReferral.engaged_referred || 0)
          : 0,
        total_referred: matchReferral
          ? parseInt(matchReferral.total_referred || 0)
          : 0,
        second_voice_engaged1: matchSecondVoice
          ? parseInt(matchSecondVoice.second_voice_engaged1 || 0)
          : 0,
        second_voice_total: matchSecondVoice
          ? parseInt(matchSecondVoice.second_voice_total || 0)
          : 0,
      };
    });

    // Filtro especial para el equipo 8 (si es necesario)
    if (teamId === 8) {
      dataOut = dataOut.filter((item) => item.engaged > 0);
    }

    return dataOut;
  }

  function rowClickFunction(team) {
    teamBody.innerHTML = "";
    if (team.teamName === "Team 1") {
      construirTabla(
        team1FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "Team 2") {
      construirTabla(
        team2FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "Team 3") {
      construirTabla(
        team3FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "Team 4") {
      construirTabla(
        team4FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "Team 5") {
      construirTabla(
        team5FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "Team 6") {
      construirTabla(
        team6FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "Team 7") {
      construirTabla(
        team7FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "TRAINING") {
      construirTabla(
        teamTrainingFullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "TiBURONES P2") {
      construirTabla(
        teamP2FullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else if (team.teamName === "P1 REMOTE") {
      construirTabla(
        teamP1RemoteFullData,
        [
          "agent",
          "engaged",
          "engaged_referred",
          "second_voice_total",
        ],
        teamBody
      );
    } else {
      construirTabla(
        missingTeamFullData,
        ["name", "engaged", "totalTalkingTime"],
        teamBody
      );
    }

    if (mainElement) {
      mainElement.style.height = "auto"; // Esto eliminará la propiedad 'height'
    }

    team1Table.style.display = "block";
    performanceTable.style.display = "none";
    titleSelector.style.display = "none";
    rollbackButton.style.display = "flex";
  }

  function tableToCSV() {
    // Variable to store the final csv data
    let csv_data = [];

    // Get each row data
    let rows = document.getElementsByTagName("tr");
    for (let i = 0; i < rows.length; i++) {
      // Get each column data
      let cols = rows[i].querySelectorAll("td,th");

      // Stores each csv row data
      let csvrow = [];
      for (let j = 0; j < cols.length; j++) {
        // Get the text data of each cell
        // of a row and push it to csvrow
        csvrow.push(cols[j].innerHTML);
      }

      // Combine each column value with comma
      csv_data.push(csvrow.join(","));
    }

    // Combine each row data with new line character
    csv_data = csv_data.join("\n");

    // Call this function to download csv file
    downloadCSVFile(csv_data);
  }

  function downloadCSVFile(csv_data) {
    // Create CSV file object and feed
    // our csv_data into it
    let CSVFile = new Blob([csv_data], {
      type: "text/csv",
    });

    // Create to temporary link to initiate
    // download process
    let temp_link = document.createElement("a");

    // Download csv file
    temp_link.download = "teams_performance.csv";
    let url = window.URL.createObjectURL(CSVFile);
    temp_link.href = url;

    // This link should not be displayed
    temp_link.style.display = "none";
    document.body.appendChild(temp_link);

    // Automatically click the link to
    // trigger download
    temp_link.click();
    document.body.removeChild(temp_link);
  }

  function sortTable(n, isNumber = false) {
    let table = document.querySelector(".data-table");
    let rows = Array.from(table.rows).slice(1); // Convertir HTMLCollection a array y excluir el encabezado

    rows.sort((rowA, rowB) => {
      let cellA = rowA.cells[n].innerText;
      let cellB = rowB.cells[n].innerText;

      if (isNumber) {
        // Convertir a número y restar para obtener un valor de comparación
        return Number(cellA) - Number(cellB);
      } else {
        // Comparar alfabéticamente
        return cellA.localeCompare(cellB);
      }
    });

    rows.forEach((row) => {
      // Reinsertar las filas en la tabla
      table.tBodies[0].appendChild(row);
    });
  }

  const tableHeaders = document.getElementById("table-headers");

  // leer la tabla y por cada columna agregar un evento de click y el mouse pointer se convierta en un cursor
  for (let i = 0; i < tableHeaders.rows[0].cells.length; i++) {
    tableHeaders.rows[0].cells[i].addEventListener("click", () => {
      sortTable(i);
    });
  }

  function createGlobalData(
    teamName,
    teamIndex,
    teamDataEngaged,
    teamDataSecond,
    teamDataReferral,
    totalMembers
  ) {
    const teamEngagedKey = `teamEngaged${teamIndex}`;
    const teamTotalEngaged = teamDataEngaged[teamEngagedKey];
    const teamSecondVoiceKey = `totalSecond${teamIndex}`;
    const teamTotalSecondVoice = teamDataSecond[teamSecondVoiceKey];
    console.log(teamTotalSecondVoice, teamName);
    const totalReferralKey = `teamReferral${teamIndex}`;
    const teamTotalReferral = teamDataReferral[totalReferralKey];

    return {
      teamName,
      engaged: teamTotalEngaged,
      referralConverted: teamTotalReferral.engaged_referred
        ? parseInt(teamTotalReferral.engaged_referred)
        : 0,
      p1SecondVoiceConversion: teamTotalSecondVoice.second_voice_total || 0,
      totalMembers,
    };
  }

})();
