<?php
  $servername = "137.184.226.50";
  $username = "admin";
  $password = "_1kK756!r(2NORK7";
  $dbname = "logVar";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
      die("Error de conexión: " . $conn->connect_error);
  }