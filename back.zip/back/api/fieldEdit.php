<?php
require_once('credConfig.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['table'])) {
    $table = $conn->real_escape_string($_GET['table']);
    $value = $conn->real_escape_string($_GET['value']);
    $id = $conn->real_escape_string($_GET['id']);
    $fullname = $conn->real_escape_string($_GET['fullname']);
    $last_checked = $conn->real_escape_string($_GET['last_checked']);
    
    if ($table === 'sales_q_status') {
        // look up if user exist
        $findUserQuery = "SELECT * FROM $table WHERE ext='$id'";
        $findUserResult = $conn->query($findUserQuery);
        
        if ($findUserResult === FALSE) {
            echo "Error en la consulta de búsqueda: " . $conn->error;
            exit();
        }
        
        if ($findUserResult->num_rows > 0) {
            // Update query
            $query = "UPDATE $table SET top_bucket_status='$value', bottom_bucket_status='$value' WHERE ext='$id'";
        } else {
            // Insert query
            $query = "INSERT INTO $table (ext, fullname, top_bucket_status, bottom_bucket_status, last_checked) VALUES ('$id', '$fullname', '$value', '$value', '$last_checked')";
        }
        
        $result = $conn->query($query);
        
        if ($result === TRUE) {
            echo "Usuario actualizado con éxito";
        } else {
            echo "Error al actualizar el usuario: " . $conn->error;
        }
    } else {
        echo json_encode(array('error' => 'Tabla no reconocida.'));
    }
} else {
    echo json_encode(array('error' => 'Debes especificar table en la solicitud.'));
}
?>
