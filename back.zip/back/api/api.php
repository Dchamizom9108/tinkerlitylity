<?php
require_once('config.php');

// Manejar solicitud GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  $users = array();
  $sql = "SELECT * FROM users";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $users[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($users);
  } else {
    echo json_encode(array('message' => 'No se encontraron usuarios'));
  }
}

// Manejar solicitud POST (crear un nuevo usuario)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $data = json_decode(file_get_contents('php://input'));
  $nombre = $data->nombre;
  $email = $data->email;

  $sql = "INSERT INTO users (nombre, email) VALUES ('$nombre', '$email')";

  if ($conn->query($sql) === TRUE) {
    echo "Usuario creado con éxito";
  } else {
    echo "Error al crear el usuario: " . $conn->error;
  }
}

// Manejar solicitud PUT (actualizar un usuario)
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
  parse_str(file_get_contents('php://input'), $data);
  $id = $data['id'];
  $nombre = $data['nombre'];
  $email = $data['email'];

  $sql = "UPDATE users SET nombre='$nombre', email='$email' WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    echo "Usuario actualizado con éxito";
  } else {
    echo "Error al actualizar el usuario: " . $conn->error;
  }
}

// Manejar solicitud DELETE (eliminar un usuario)
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
  parse_str(file_get_contents('php://input'), $data);
  $id = $data['id'];

  $sql = "DELETE FROM users WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    echo "Usuario eliminado con éxito";
  } else {
    echo "Error al eliminar el usuario: " . $conn->error;
  }
}

$conn->close();
