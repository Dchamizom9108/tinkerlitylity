<?php
// Configura la URL de redirección
$redirectURL = "https://users.consumerlaw.com/";

// Realiza la redirección utilizando el encabezado de ubicación
header("Location: " . $redirectURL);
exit;
?>
