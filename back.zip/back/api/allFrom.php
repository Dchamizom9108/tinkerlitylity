<?php

require_once('credConfig.php');
if (isset($_GET['table'])) {
  $table = $conn->real_escape_string($_GET['table']);
  $queryGiveUsersData = "SELECT * FROM $table";

  $resultado = $conn->query($queryGiveUsersData);
  if ($resultado) {
    $datos = array();
    while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
    }
    echo json_encode($datos);
  } else {
    echo json_encode(array('error' => 'Error en la consulta: '. $conn->error));
  }
} else {
  echo json_encode(array('error' => 'Debes especificar table en la solicitud.'));
}