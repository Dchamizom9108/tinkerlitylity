<?php
require_once('config.php');

// Verificar si se especifican las fechas en la solicitud
if (isset($_GET['fechaInicio']) && isset($_GET['fechaFin'])) {
    $fechaInicio = $conn->real_escape_string($_GET['fechaInicio']);
    $fechaFin = $conn->real_escape_string($_GET['fechaFin']);

    // Consulta para obtener el registro con el ID más alto de cada día
    $query = "
        SELECT t1.*
        FROM tcxFull t1
        INNER JOIN (
            SELECT DATE(data_date) AS data_date, MAX(id) AS max_id
            FROM tcxFull
            WHERE data_date BETWEEN '$fechaInicio' AND '$fechaFin'
            GROUP BY DATE(data_date), agent
        ) t2
        ON t1.id = t2.max_id
    ";

    $resultado = $conn->query($query);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
        echo json_encode($datos);
    } else {
        echo json_encode(array('error' => 'Error en la consulta: ' . $conn->error));
    }
} else {
    echo json_encode(array('error' => 'Debes especificar date en la solicitud.'));
}

$conn->close();
?>
