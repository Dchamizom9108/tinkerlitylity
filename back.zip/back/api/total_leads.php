<?php
require_once('config.php');

// Verificar si se especifican las fechas en la solicitud
if (isset($_GET['date'])) {
    $date = $conn->real_escape_string($_GET['date']);

    $query = "SELECT * FROM total_leads WHERE data_date = '$date'";

    $resultado = $conn->query($query);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
        echo json_encode($datos);
    } else {
        echo json_encode(array('error' => 'Error en la consulta: ' . $conn->error));
    }
} else {
    echo json_encode(array('error' => 'Debes especificar date en la solicitud.'));
}

$conn->close();
?>
