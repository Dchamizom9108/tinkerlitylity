<?php
require_once('config.php');

// Verificar si se especifican las fechas en la solicitud
if (isset($_GET['fechaInicio']) && isset($_GET['fechaFin'])) {
    $fechaInicio = $conn->real_escape_string($_GET['fechaInicio']);
    $fechaFin = $conn->real_escape_string($_GET['fechaFin']);

    if ($fechaInicio === $fechaFin) {
        $query = "SELECT user_id, fullName, p1_sold_total as total_p1_sold, p2_sold_total as total_p2_sold, todayGross as total_todayGross, second_voice_total as total_second_voice_total, second_voice_engaged as total_second_voice_engaged FROM data_wallboard WHERE data_date = '$fechaInicio'";
    } else {
        $query = "SELECT user_id, fullName, SUM(p1_sold_total) as total_p1_sold, SUM(p1_amount) as total_p1_amount, SUM(p2_sold_total) as total_p2_sold, SUM(todayGross) as total_todayGross, SUM(second_voice_total) as total_second_voice_total, SUM(second_voice_engaged) as total_second_voice_engaged
        FROM data_wallboard
        WHERE data_date BETWEEN '$fechaInicio' AND '$fechaFin'
        GROUP BY user_id, fullName";
    }

    $resultado = $conn->query($query);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
        echo json_encode($datos);
    } else {
        echo json_encode(array('error' => 'Error en la consulta: ' . $conn->error));
    }
} else {
    echo json_encode(array('error' => 'Debes especificar fechaInicio y fechaFin en la solicitud.'));
}

$conn->close();
?>
