<?php
require_once('credConfig.php');

$secretKey = "PanchaPlanchaConCuatroPlanchas";
$timeOfPetition = obtenerFechaHora();

if (isset($_GET['tokenFor']) && isset($_GET['typeOfPetition'])) {
  $user = $conn->real_escape_string($_GET['tokenFor']);
  $typeOfPetition = $conn->real_escape_string($_GET['typeOfPetition']);
  $dateAsk = $timeOfPetition;
  $queryGiveUser = "SELECT username, password FROM credentials WHERE active = 1";
  $queryGiveToken = "SELECT token FROM token WHERE active = 1";

  if ($typeOfPetition == 'get_token') {
    $resultado = $conn->query($queryGiveToken);
    if ($resultado) {
      $datos = array();
      while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
      }
      echo json_encode($datos);
    } else {
      echo json_encode(array('error' => 'Error en la consulta: ' . $conn->error));
    }
  } elseif ($typeOfPetition == 'get_credentials') {
    $resultado = $conn->query($queryGiveUser);
    if ($resultado) {
      $datos = array();
      while ($fila = $resultado->fetch_assoc()) {
        // Cifrar los datos antes de enviarlos
        $fila['username'] = encrypt($fila['username'], $secretKey);
        $fila['password'] = encrypt($fila['password'], $secretKey);
        $datos[] = $fila;
      }
      echo json_encode($datos);
    } else {
      echo json_encode(array('error' => 'Error en la consulta: '. $conn->error));
    }
  }

  // Registra quién pidió los datos y la fecha y hora
  $queryWhoAsk = "INSERT INTO logServer (user, date_ask, what_ask) VALUES ('$user', '$dateAsk', '$typeOfPetition')";

  if ($conn->query($queryWhoAsk) !== TRUE) {
    echo json_encode(array('error' => 'Error al registrar la solicitud: ' . $conn->error));
  }
  $conn->close();
} else {
  echo json_encode(array('error' => 'Debes especificar tokenFor y dateAsk en la solicitud.'));
}

// Función para encriptar utilizando XOR
function encrypt($data, $key)
{
  $encrypted = '';
  for ($i = 0; $i < strlen($data); $i++) {
    $encrypted .= chr(ord($data[$i]) ^ ord($key[$i % strlen($key)]));
  }
  return base64_encode($encrypted);
}

function obtenerFechaHora() {
  // Obtiene la fecha y hora actual en formato de timestamp
  $timestamp = time();
  
  // Formatea la fecha y hora en el formato deseado
  $fecha_hora = date("Y-m-d H:i:s", $timestamp);
  
  // Retorna la fecha y hora formateada
  return $fecha_hora;
}

