<?php

require_once('credConfig.php');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['table']) && isset($_GET['fechaInicio']) && isset($_GET['fechaFin'])) {
  $table = $conn->real_escape_string($_GET['table']);
  $fechaInicio = $conn->real_escape_string($_GET['fechaInicio']);
  $fechaFin = $conn->real_escape_string($_GET['fechaFin']);

  if ($table === 'p_one_data') {
    $query = "SELECT aset_id,
      MAX(as_name) AS as_name,
      SUM(p1_amount) AS p1_amount,
      SUM(p1_sold_total) AS p1_sold_total
    FROM $table 
    WHERE date_data BETWEEN '$fechaInicio' AND '$fechaFin' 
    GROUP BY aset_id";
  } elseif ($table === 'p_two_data') {
    $query = "SELECT dc_id,
      MAX(dc_name) AS dc_name,
      SUM(engaged_total) AS engaged_total,
      SUM(p2_amount) AS p2_amount,
      SUM(p2_sold_total) AS p2_sold_total,
      SUM(local_amount) AS local_amount,
      SUM(total_amount) AS total_amount
    FROM $table 
    WHERE date_data BETWEEN '$fechaInicio' AND '$fechaFin' 
    GROUP BY dc_id";

  } elseif ($table === 'referral_data') {
    $query = "SELECT rd.lead_id, rd.user_id, rd.date_data, rd.closer_id
      FROM referral_data rd
      INNER JOIN (
          SELECT lead_id, MAX(date_data) AS max_date
          FROM referral_data
          WHERE date_data BETWEEN '$fechaInicio' AND '$fechaFin'
          GROUP BY lead_id
      ) grouped_referrals
      ON rd.lead_id = grouped_referrals.lead_id AND rd.date_data = grouped_referrals.max_date";

  } elseif ($table === 'sv_two_data') {
    $query = "SELECT sv_id,
      MAX(sv_name) AS sv_name,
      SUM(sv_engaged_total) AS sv_engaged_total,
      SUM(sv_engaged_gross) AS sv_engaged_gross
    FROM $table
    WHERE date_data BETWEEN '$fechaInicio' AND '$fechaFin'
    GROUP BY sv_id";

  } elseif ($table === 'sv_one_data') {
    $query = "SELECT sv1_id AS sv_id,
      MAX(sv1_name) AS sv_name,
      SUM(sv1_engaged_total) AS sv_engaged_total
    FROM $table
    WHERE date_data BETWEEN '$fechaInicio' AND '$fechaFin'
    GROUP BY sv_id";
  } elseif ($table === 'p_one_free_data') {
    $query = "SELECT lead_id, date_created, user_id, status
    FROM $table
    WHERE date_created BETWEEN '$fechaInicio' AND '$fechaFin'";    
  }
  else {
    echo json_encode(array('error' => 'Tabla no válida especificada.'));
    exit();
  }

  $resultado = $conn->query($query);

  if ($resultado) {
      $datos = array();
      while ($fila = $resultado->fetch_assoc()) {
          $datos[] = $fila;
      }
      echo json_encode($datos);
  } else {
      echo json_encode(array('error' => 'Error en la consulta: '. $conn->error));
  }
} else {
  echo json_encode(array('error' => 'Debes especificar table, fechaInicio y fechaFin en la solicitud.'));
}
?>
