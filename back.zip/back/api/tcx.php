<?php
require_once('config.php');

// Verificar si se especifican las fechas en la solicitud
if (isset($_GET['fechaInicio']) && isset($_GET['fechaFin'])) {
    $fechaInicio = $conn->real_escape_string($_GET['fechaInicio']);
    $fechaFin = $conn->real_escape_string($_GET['fechaFin']);

    $querySingleDay = "SELECT * FROM tcxFull WHERE data_date BETWEEN '$fechaInicio' AND '$fechaFin'";


    // Consulta para obtener solo las filas con el ID más alto por agente y fecha
    $queryMultipleDays = "
        SELECT t1.*
        FROM tcxFull t1
        INNER JOIN (
            SELECT agent, data_date, MAX(id) AS max_id
            FROM tcxFull
            WHERE data_date BETWEEN '$fechaInicio' AND '$fechaFin'
            GROUP BY agent, data_date
        ) t2 ON t1.agent = t2.agent AND t1.data_date = t2.data_date AND t1.id = t2.max_id
        ORDER BY t1.data_date;
    ";

    if ( $fechaInicio === $fechaFin ) {
        $query = $querySingleDay;
    } else {
        $query = $queryMultipleDays;
    }

    $resultado = $conn->query($query);

    if ($resultado) {
        $datos = array();
        while ($fila = $resultado->fetch_assoc()) {
            $datos[] = $fila;
        }
        echo json_encode($datos);
    } else {
        echo json_encode(array('error' => 'Error en la consulta: ' . $conn->error));
    }
} else {
    echo json_encode(array('error' => 'Debes especificar fechaInicio y fechaFin en la solicitud.'));
}

$conn->close();

