<?php

require_once('credConfig.php');

if (isset($_GET['teamId'])) {
  $teamId = $conn->real_escape_string($_GET['teamId']);

  $queryGiveUsersData = "SELECT users.id, users.fullname, users.phone_ext_c
    FROM users
    INNER JOIN team_memberships ON team_memberships.user_id = users.id
    WHERE team_memberships.team_id = '$teamId'";

  $resultado = $conn->query($queryGiveUsersData);
  if ($resultado) {
    $datos = array();
    while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
    }
    echo json_encode($datos);
  } else {
    echo json_encode(array('error' => 'Error en la consulta: '. $conn->error));
  }
} else {
  echo json_encode(array('error' => 'Debes especificar teamId en la solicitud.'));
}