<?php
header("Access-Control-Allow-Origin: http://127.0.0.1:5500");
require_once('credConfig.php');

// Consulta SQL para seleccionar una cita aleatoria
$sql = "SELECT * FROM frases ORDER BY RAND() LIMIT 1";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Convertir el resultado en un array asociativo
    $row = $result->fetch_assoc();
    
    // Crear un array con la cita seleccionada
    $quote = array(
        "frase" => $row["frase"],
        "autor" => $row["autor"],
        "profesion" => $row["profesion"]
    );

    // Devolver la cita como JSON
    header('Content-Type: application/json');
    echo json_encode($quote);
} else {
    echo "No se encontraron citas.";
}

// Cerrar la conexión a la base de datos
$conn->close();