<?php

require_once('credConfig.php');
  $table = 'legal_q_mx';
  $queryGiveUsersData = "SELECT * FROM $table WHERE last_log = '1'";

  $resultado = $conn->query($queryGiveUsersData);
  if ($resultado) {
    $datos = array();
    while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
    }
    echo json_encode($datos);
  } else {
    echo json_encode(array('error' => 'Error en la consulta: '. $conn->error));
  }