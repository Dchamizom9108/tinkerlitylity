const puppeteer = require("puppeteer");

(async () => {
  //const browser= await puppeteer.launch({headless: false, args: ['--no-sandbox', '--start-maximized', '--download.default_directory=./tmp/'] , defaultViewport: null});
  const browser = await puppeteer.launch({ headless: "true", args: ["--no-sandbox"], });
  
  const page = await browser.newPage();
  await page.goto("https://on.spiceworks.com/tickets/open/1?sort=updated_at-desc");
  await page.waitForSelector('input[name="email"]');

  await page.type('input[name="email"]', 'dchamizo@consumerlaw.com');
  await page.type('input[name="password"]', 'GT0STOh01CIE3p2b');
  await page.click('button[type="submit"]');
  await new Promise((r) => setTimeout(r, 10000));

  // Aquí puedes seleccionar la tabla que contiene los spans con la clase .tw-underline
  const table = await page.$('table'); // Reemplaza 'selector_de_la_tabla' por el selector correcto de tu tabla
  
  // Luego, busca y selecciona todos los spans con la clase .tw-underline dentro de la tabla
  const spans = await table.$$('span.tw-underline');

  if(spans.length > 0) {
    
    for (const span of spans) {  // Haz clic en cada uno de los spans encontrados
      await span.click();
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  console.log("Terminado");
  browser.close();

})();

