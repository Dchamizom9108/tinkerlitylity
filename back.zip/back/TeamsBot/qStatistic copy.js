const puppeteer = require('puppeteer')
const nodemailer = require('nodemailer');
const fs = require('fs');

const queueName = ['903 SALES', '700 General Inbound - Mexico', '904 NATIONWIDE', '850 AR INBOUND', '800 General Inbound - Chicago'];

(async () => {
    // Create the transporter with the required configuration for Outlook
    const transporter = nodemailer.createTransport({
        host: 'smtp.office365.com',
        port: 587,
        secure: false,
        auth: {
        user: 'support@consumerlaw.com',
        pass: '9OIgzAU0fplr'
        }
    });
    const browser = await puppeteer.launch({headless: true, args: ['--no-sandbox']});
    const page = await browser.newPage();
    await page.goto('https://consumerlaw.my3cx.us/webclient/#/people');
    await page.type('input[id="loginInput"]', '666');
    await page.type('input[id="passwordInput"]', '@dm1nB0t23');
    await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: 'networkidle0' }),
    ]);

    const [button] = await page.$x("/html/body/modal-container/div[2]/div/ng-component/div[1]/button");
    if (button) {
        await button.click();
    }
    await page.click('a[id="menuSwitchboard"]');
    await page.click('button[id="button-alignment"]');
    // Encontrar el enlace con el texto "Queue"
    var [localSales] = await page.$x(`//a[contains(., '${queueName[0]}')]`);
    if (localSales) {
        await localSales.click();
    }
    var listDiv = await page.$('.queue-agent-list'); 
    var statisticDiv = await page.$('.queue-stat'); 

    var listScreenshot = await listDiv.screenshot(); 
    var statisticScreenshot = await statisticDiv.screenshot(); 
    fs.writeFileSync(`./images/${queueName[0]}list.png`, listScreenshot);
    fs.writeFileSync(`./images/${queueName[0]}statistic.png`, statisticScreenshot); 

    await new Promise(r => setTimeout(r, 500));
    await page.click('button[id="button-alignment"]');
    var [legalMx] = await page.$x(`//a[contains(., '${queueName[1]}')]`);
    if (legalMx) {
        await legalMx.click();
    }
    var listDiv2 = await page.$('.queue-agent-list');
    var statisticDiv2 = await page.$('.queue-stat');
    var listScreenshot2 = await listDiv2.screenshot();
    var statisticScreenshot2 = await statisticDiv2.screenshot();
    fs.writeFileSync(`./images/${queueName[1]}list.png`, listScreenshot2);
    fs.writeFileSync(`./images/${queueName[1]}statistic.png`, statisticScreenshot2);

    await new Promise(r => setTimeout(r, 500));

    await page.click('button[id="button-alignment"]');
    var [nationwide] = await page.$x(`//a[contains(., '${queueName[2]}')]`);
    if (nationwide) {
        await nationwide.click();
    }
    var listDiv3 = await page.$('.queue-agent-list'); 
    var statisticDiv3 = await page.$('.queue-stat');
    var listScreenshot3 = await listDiv3.screenshot();
    var statisticScreenshot3 = await statisticDiv3.screenshot();
    fs.writeFileSync(`./images/${queueName[2]}list.png`, listScreenshot3);
    fs.writeFileSync(`./images/${queueName[2]}statistic.png`, statisticScreenshot3);

    await new Promise(r => setTimeout(r, 500));

    await page.click('button[id="button-alignment"]');
    var [arInbound] = await page.$x(`//a[contains(., '${queueName[3]}')]`);
    if (arInbound) {
        await arInbound.click();
    }
    var listDiv4 = await page.$('.queue-agent-list'); 
    var statisticDiv4 = await page.$('.queue-stat');
    var listScreenshot4 = await listDiv4.screenshot();
    var statisticScreenshot4 = await statisticDiv4.screenshot();
    fs.writeFileSync(`./images/${queueName[3]}list.png`, listScreenshot4);
    fs.writeFileSync(`./images/${queueName[3]}statistic.png`, statisticScreenshot4);

    await new Promise(r => setTimeout(r, 500));

    await page.click('button[id="button-alignment"]');
    var [generalInbound] = await page.$x(`//a[contains(., '${queueName[4]}')]`);
    if (generalInbound) {
        await generalInbound.click();
    }
    var listDiv5 = await page.$('.queue-agent-list');
    var statisticDiv5 = await page.$('.queue-stat');
    var listScreenshot5 = await listDiv5.screenshot();
    var statisticScreenshot5 = await statisticDiv5.screenshot();
    fs.writeFileSync(`./images/${queueName[4]}list.png`, listScreenshot5);
    fs.writeFileSync(`./images/${queueName[4]}statistic.png`, statisticScreenshot5);
     // Define the email options
     const mailOptions = {
        from: 'support@consumerlaw.com',
        to: 'dchamizo@consumerlaw.com',
        subject: 'Agent_Queue_API_Report',
        html: 
            `<h1>CLG Queue Performance</h1>
            <div class="queue-performance">
                <div class="local-sales">
                    <h2>${queueName[0]}</h2>
                    <img src="cid:list1">
                    <h3>${queueName[0]} Statistics</h3>
                    <img src="cid:statistic1">
                </div>
                <div class="national">
                    <h2>${queueName[1]}</h2>
                    <img src="cid:list2">
                    <h3>${queueName[1]} Statistics</h3>
                    <img src="cid:statistic2">
                </div>
                <div class="ar">
                    <h2>${queueName[2]}</h2>
                    <img src="cid:list3">
                    <h3>${queueName[2]} Statistics</h3>
                    <img src="cid:statistic3">
                </div> 
                <div class="backoffice-mx">
                    <h2>${queueName[3]}</h2>
                    <img src="cid:list4">
                    <h3>${queueName[3]} Statistics</h3>
                    <img src="cid:statistic4">
                </div> 
                <div class="backoffice-us">
                    <h2>${queueName[4]}</h2>
                    <img src="cid:list5">
                    <h3>${queueName[4]} Statistics</h3>
                    <img src="cid:statistic5">
            </div>`,
        attachments: [
            {
                filename: `${queueName[0]}list.png`,
                path: `./images/${queueName[0]}list.png`,
                cid: 'list1'
            },
            {
                filename: `${queueName[0]}statistic.png`,
                path: `./images/${queueName[0]}statistic.png`,
                cid: 'statistic1'
            },
            {
                filename: `${queueName[1]}list.png`,
                path: `./images/${queueName[1]}list.png`,
                cid: 'list2'
            },
            {
                filename: `${queueName[1]}statistic.png`,
                path: `./images/${queueName[1]}statistic.png`,
                cid: 'statistic2'
            },
            {
                filename: `${queueName[2]}list.png`,
                path: `./images/${queueName[2]}list.png`,
                cid: 'list3'
            },
            {
                filename: `${queueName[2]}statistic.png`,
                path: `./images/${queueName[2]}statistic.png`,
                cid: 'statistic3'
            },
            {
                filename: `${queueName[3]}list.png`,
                path: `./images/${queueName[3]}list.png`,
                cid: 'list4'
            },
            {
                filename: `${queueName[3]}statistic.png`,
                path: `./images/${queueName[3]}statistic.png`,
                cid: 'statistic4'
            },
            {
                filename: `${queueName[4]}list.png`,
                path: `./images/${queueName[4]}list.png`,
                cid: 'list5'
            },
            {
                filename: `${queueName[4]}statistic.png`,
                path: `./images/${queueName[4]}statistic.png`,
                cid: 'statistic5'
            }
        ]
    };
    // Send the email
    console.log('Sending email');
    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
        console.error(error);
        } else {
        console.log('Email sent: ' + info.response);
        }
    });
    await new Promise(r => setTimeout(r, 2000));
    await browser.close();
})();
   