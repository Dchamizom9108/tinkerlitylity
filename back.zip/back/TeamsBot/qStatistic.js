const puppeteer = require("puppeteer");
const nodemailer = require("nodemailer");
const fs = require("fs");

const queueName = [
  "903 SALES",
  "700 General Inbound - Mexico",
  "904 NATIONWIDE",
  "850 AR INBOUND",
  "800 General Inbound - Chicago",
  "CHI Backoffice Tier 2",
];

(async () => {
  var date = new Date();
  date.setUTCHours(date.getUTCHours() - 5);
  const isoDate = date.toISOString().substring(0, 10);
  // Create the transporter with the required configuration for Outlook
  const transporter = nodemailer.createTransport({
    host: "smtp.office365.com",
    port: 587,
    secure: false,
    auth: {
      user: "support@consumerlaw.com",
      pass: "9OIgzAU0fplr",
    },
  });
  const browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage();
  await page.goto("https://consumerlaw.my3cx.us/webclient/#/people");
  await page.type('input[id="loginInput"]', "666");
  await page.type('input[id="passwordInput"]', "@dm1nB0t23");
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  const [button] = await page.$x(
    "/html/body/modal-container/div[2]/div/ng-component/div[1]/button"
  );
  if (button) {
    await button.click();
  }
  await page.click('a[id="menuSwitchboard"]');
  await page.click('button[id="button-alignment"]');
  // Encontrar el enlace con el texto "Queue"
  var [localSales] = await page.$x(`//a[contains(., '${queueName[5]}')]`);
  if (localSales) {
    await localSales.click();
  }
  var listDiv = await page.$(".queue-agent-list");
  var statisticDiv = await page.$(".queue-stat");

  var listScreenshot = await listDiv.screenshot();
  var statisticScreenshot = await statisticDiv.screenshot();
  fs.writeFileSync(`./images/${queueName[0]}list.png`, listScreenshot);
  fs.writeFileSync(
    `./images/${queueName[0]}statistic.png`,
    statisticScreenshot
  );

  // Define the email options
  const mailOptions = {
    from: "support@consumerlaw.com",
    to: "kellsworth@consumerlaw.com", // , kellsworth@consumerlaw.com
    subject: "Agent_Queue_API_Report",
    html: `<h1>CLG Queue Performance</h1>
            <div class="queue-performance">
                <div class="local-sales">
                    <h2>${queueName[5]}</h2>
                    <img src="cid:list1">
                    <h3>${queueName[5]} Statistics</h3>
                    <img src="cid:statistic1">
                </div>
            `,
    attachments: [
      {
        filename: `${queueName[0]}list.png`,
        path: `./images/${queueName[0]}list.png`,
        cid: "list1",
      },
      {
        filename: `${queueName[0]}statistic.png`,
        path: `./images/${queueName[0]}statistic.png`,
        cid: "statistic1",
      },
    ],
  };
  // Send the email
  console.log("Sending email");
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
  await new Promise((r) => setTimeout(r, 2000));

  const newPage = await browser.newPage();

  await newPage.goto(
    "https://consumerlaw.my3cx.us/#/app/call_reports/call_reports"
  );
  await newPage.type('input[ng-model="$ctrl.user.username"]', "666");
  await newPage.type('input[type="password"]', "@dm1nB0t23");
  await Promise.all([
    newPage.click('button[type="submit"]'),
    newPage.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  await newPage.click("button#btnAdd");
  await newPage.select(
    'select[name="MainParams.ReportType"]',
    "AgentInQueueStatistics"
  );
  await newPage.type('input[name="ReportName"]', "QueueBotAutomation");
  await newPage.type('input[name="SendToEmail"]', "kellsworth@consumerlaw.com");
  await newPage.select('select[name="RangeType"]', "Custom");
  await newPage.evaluate(
    () => (document.querySelector('input[name="CustomDateFrom"]').value = "")
  );
  await newPage.type('input[name="CustomDateFrom"]', isoDate);
  await newPage.click('button[translate="REPORTS.add_queues"]');
  await new Promise((r) => setTimeout(r, 800));
  await newPage.type('input[id="inputSearch"]', "901");
  await new Promise((r) => setTimeout(r, 1000));
  await newPage.click('label[role="button"]');
  await new Promise((r) => setTimeout(r, 800));
  await newPage.click('button[ng-click="addClick()"]');
  await new Promise((r) => setTimeout(r, 800));
  await newPage.click(
    'button[translate="CALL_REPORTS.STATISTICS.SCHEDULE_REPORT_BTN"]'
  );

  await browser.close();
})();
