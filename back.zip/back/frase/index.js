const fraseURL = "https://home.justicialaboral.com/bot_db/api/frase.php";
const fraseElement = document.getElementById("textElement");
const authorElement = document.getElementById("authorElement");

const epowerProxyURL = "https://bots.consumerlaw.com/proxy"

let quote, author;

function getDataGET(url) {
  return new Promise((resolve, reject) => {
    $.ajax({
      url: epowerProxyURL,
      method: "POST",
      timeout: 0,
      crossDomain: true,
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      data: JSON.stringify({
        parameters: {},
        url: `${url}`,
      }),
      success: function (response) {
        resolve(response);
      },
      error: function (xhr, status, error) {
        reject(new Error(`Error fetching data from ${url}. Status: ${status}`));
      },
    });
  });
}

getDataGET(fraseURL).then((response) => {
  quote = response.frase;
  author = response.autor;
  fraseElement.innerHTML = quote;
  authorElement.innerHTML = author;
});

const paletteGroups = [
  // Group 1
  {
    bg: "#242424",
    quoteBgColor: "#00000f",
    quoteTextColor: "#ffffff",
    buttonBgColor: "#4E4FEB",
    buttonTextHoverColor: "#ffffff",
    buttonBgHoverColor: "#068FFF",
  },
  /*
      // Group 2
      {
        bg: "#071952",
        quoteBgColor: "#0B666A",
        quoteTextColor: "#35A29F",
        buttonBgColor: "#97FEED",
        buttonTextHoverColor: "#ffffff",
        buttonBgHoverColor: "#555555"
      },
      // Group 3
      {
        bg: "#AA77FF",
        quoteBgColor: "#C9EEFF",
        quoteTextColor: "#97DEFF",
        buttonBgColor: "#62CDFF",
        buttonTextHoverColor: "#ffffff",
        buttonBgHoverColor: "#555555"
      },
      // Group 4
      {
        bg: "#331D2C",
        quoteBgColor: "#3F2E3E",
        quoteTextColor: "#A78295",
        buttonBgColor: "#EFE1D1",
        buttonTextHoverColor: "#ffffff",
        buttonBgHoverColor: "#555555"
      }*/
];

const randomGroup =
  paletteGroups[Math.floor(Math.random() * paletteGroups.length)];
// const randomGroup = paletteGroups[0];
const palette = {
  ...randomGroup,
  textColor: getContrastingColor(randomGroup.bg),
};

document.documentElement.style.setProperty("--bg-color", palette.bg);
document.documentElement.style.setProperty("--text-color", palette.textColor);
document.documentElement.style.setProperty(
  "--quote-bg-color",
  palette.quoteBgColor
);
document.documentElement.style.setProperty(
  "--quote-text-color",
  palette.quoteTextColor
);
document.documentElement.style.setProperty(
  "--button-bg-color",
  palette.buttonBgColor
);
document.documentElement.style.setProperty(
  "--button-text-color",
  palette.textColor
);
document.documentElement.style.setProperty(
  "--button-text-hover-color",
  palette.buttonTextHoverColor
);
document.documentElement.style.setProperty(
  "--button-bg-hover-color",
  palette.buttonBgHoverColor
);

function getContrastingColor(hexColor) {
  const hex = hexColor.replace("#", "");
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;

  return yiq >= 128 ? "#000" : "#fff";
}
