import { getStartDate } from "../components/js/functions.js?v5";

const epowerProxyURL = "https://bots.consumerlaw.com/proxy"
const teamP2Id = "00857dc2-c74c-11ed-9c75-dadc21ba0c54";
const teamP2 = await getDataFromSugarTeam(teamP2Id)

const team1Id = "c0c79ed8-5d67-11ee-acec-dadc21ba0c54";
const team2Id = "5c95114e-5e10-11ee-b25d-dadc21ba0c54";
const team3Id = "3a493bfa-5e11-11ee-a009-dadc21ba0c54";
const team4Id = "f5711a2c-5e13-11ee-8b98-dadc21ba0c54";
const team5Id = "c3f3599c-ac10-11ee-8c8c-dadc21ba0c54";
const trainingSalesId = "5e0229f2-b57e-11ee-b4d4-dadc21ba0c54";
const team1 = await getDataFromSugarTeam(team1Id)
const team2 = await getDataFromSugarTeam(team2Id)
const team3 = await getDataFromSugarTeam(team3Id)
const team4 = await getDataFromSugarTeam(team4Id)
const team5 = await getDataFromSugarTeam(team5Id)
const trainingSales = await getDataFromSugarTeam(trainingSalesId)
const teamP1 = [team1, team2, team3, team4, team5, trainingSales].flat();

const managers =[
  "c9c8b0e2-b4de-11ea-bd91-dadc21ba0c54", // Yamil
  "860427cc-6349-11ec-ab9f-dadc21ba0c54", // Karla
  "7bc0a966-d597-11ea-bc04-dadc21ba0c54", // Claudia
  "5e4eddc0-e0bb-11ee-a3e6-dadc21ba0c54", // Rafael
  "3963b832-e517-11ed-ad77-dadc21ba0c54", // Mario
  "aa93da7e-416b-11e7-b909-005056951e6f", // Ivan
  "2988cd18-3e55-11ec-b511-dadc21ba0c54", // Ana
  "5e2d7f90-3a38-11eb-95e6-dadc21ba0c54", // Hector
  "ce1964f0-c5e3-11ea-a705-dadc21ba0c54", // Jaime
]

const localNames = [
  "Lucy Basabe",
  "Juan Carlos",
  "Jhony Quintero",
  "Angelica Velazquez",
]
let adjustedDate = new Date();
adjustedDate.setUTCHours(adjustedDate.getUTCHours() - 5);
let end = adjustedDate.toISOString().substring(0, 10);

const dayValue = 150;
const monthValue = 3500;
const dayGoodValueP1 = 3;
const monthGoodValueP1 = end.substring(8, 10);

updateData(end);

setInterval(() => {
  updateData(end);
}, 60000);

///////////////////////////////////////////// VARIABLES ///////////////////////////////////////////////////
let loading = true;
let firstDataLoad = true;
let previousTop10TodayP1 = [];
let previousTop10TodayP2 = [];

let todayGauge = Gauge(document.getElementById("today_test"), {
  max: dayValue,
  value: 0,
  label: function (value) {
    return value + " / " + dayValue;
  },
  color: function (value) {
    let percentage = (value / dayValue) * 100; // Calcular el porcentaje
    let hue = (percentage / 100) * 120; // Rango de colores de rojo a verde (120 grados)
    let color = "hsl(" + hue + ", 100%, 50%)"; // Crear el color HSL
    return color;
  },
});

let monthGauge = Gauge(document.getElementById("month_test"), {
  max: monthValue,
  value: 0,
  label: function (value) {
    return value + " / 3.5K";
  },
  color: function (value) {
    let percentage = (value / monthValue) * 100; // Calcular el porcentaje
    let hue = (percentage / 100) * 120; // Rango de colores de rojo a verde (120 grados)
    let color = "hsl(" + hue + ", 100%, 50%)"; // Crear el color HSL
    return color;
  },
});

const tBuildTodayP1 = $("<table>").addClass("p1-table");
const p1AppendToday = $(".p1Data");
const tBuildTodayP2 = $("<table>").addClass("p2-table");
const p2AppendToday = $(".p2Data");
const tBuildReferralsP1 = $("<table>").addClass("p1-ref-table");
const p1RefSec = $(".p1RefSec");
const tBuildReferralsP2 = $("<table>").addClass("p2-ref-table");
const p2RefSec = $(".p2RefSec");

///////////////////////////////////////////// TABLES /////////////////////////////////////////////////

async function updateData(end) {

  const p2Team = teamP2.map(item => item.id);

	Promise.all([
		getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromMonth.php?table=p_two_data_month`),
		getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_two_data&fechaInicio=${end}&fechaFin=${end}`),
		getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromMonth.php?table=p_one_data_month`),
		getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromWithDate.php?table=p_one_data&fechaInicio=${end}&fechaFin=${end}`),
    // getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromMonth.php?table=referral_data_month`),	
    getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromMonth.php?table=sv_one_data_month`),
    getDataGET(`https://home.justicialaboral.com/bot_db/api/allFromMonth.php?table=sv_two_data_month`),
  ]).then(([ monthDataP2, dataP2, monthDataP1, dataP1, p1Sv, p2Sv]) => {

    /////////////////////////////////////////// SV DATA ///////////////////////////////////////////
    const p1SvData = processP1SvData(p1Sv, managers, 'sv_id', 'sv_engaged_total');
    const top5P1Sv = p1SvData.slice(0, 12);

    const p2SvData = processSvData(p2Sv, managers, 'sv_id', 'sv_engaged_total', 'sv_engaged_gross');
    const top12P2Sv = p2SvData.splice(0, 12);

    /////////////////////////////////////////// SV DATA ///////////////////////////////////////////
    let filteredP2Data = monthDataP2.filter((item) => p2Team.includes(item.dc_id));

    monthDataP1 = monthDataP1.reduce((acc, item) => {
      const existing = acc.find( (element) => element.aset_id === item.aset_id );
      if (existing) {
        existing.p1_sold_total = String(Number(existing.p1_sold_total) + Number(item.p1_sold_total));
      } else {
        acc.push(item);
      }
      return acc;
    }, [])

		////////////////////////////////////// P1 /////////////////////////////////////////
		monthDataP1 = mapAndFilterDataP1(monthDataP1, 'as_name', ['p1_sold_total', 'p1_amount'], ['Info', 'p1_amount']);
		dataP1 = mapAndFilterDataP1(dataP1, 'as_name', ['p1_sold_total', 'p1_amount'], ['Info', 'p1_amount']);
		////////////////////////////////////// P1 /////////////////////////////////////////

    ////////////////////////////////////// P2 /////////////////////////////////////////
    monthDataP2 = filteredP2Data.map((lead) => {
      const names = lead.dc_name.split(" ");
      const agent = names[0] + " " + names[1];
      const info = parseInt(lead.p2_amount) + parseInt(lead.local_amount);
      return{ agent, Info: info };
    }).sort((a, b) => b.Info - a.Info);

    dataP2 = dataP2.map((lead) => {
      const info = lead.engaged_total;
      const gross = info.gross;
      return{ agent: shortName(lead.dc_name), Info: info, Gross: gross };
    });
    ////////////////////////////////////// P2 /////////////////////////////////////////

		if (!firstDataLoad) {
      let newSalesTodayP1 = [];
      let newSalesTodayP2 = [];
			newSalesTodayP1 = dataP1.filter( (item) => !previousTop10TodayP1.some(
				(prevItem) => prevItem.agent === item.agent ) );
			newSalesTodayP2 = dataP2.filter( (item) => !previousTop10TodayP2.some(
				(prevItem) => prevItem.agent === item.agent ) );
      if (newSalesTodayP1.length > 0) { //por cada elemento correr la función de la marquesina
        newSalesTodayP1.forEach((element) => {
          setMarqueeText(`${element.agent} P1 SOLD Let's Do This!!!`);
        });
      } else if (newSalesTodayP2.length > 0) {
        newSalesTodayP2.forEach((element) => {
          setMarqueeText(
            `${element.agent} Engaged ${element.Gross}K Let's Do This!!!`
          );
        });
      }
		}

		previousTop10TodayP1 = dataP1;
		previousTop10TodayP2 = dataP2;
    
		dataP1.forEach((element) => {
			const monthDataElement = monthDataP1.find( (item) => item.agent === element.agent );
			element.monthInfo = monthDataElement ? monthDataElement.Info : 0;
		})

    monthDataP2.forEach((element) => {
      const todayElement = dataP2.find( (item) => item.agent === element.agent );
      element.monthInfo = formatNumber(element.Info);
      element.Info = todayElement ? todayElement.Info : 0;
    })

    monthDataP2 = monthDataP2.filter((item) => {
      return !localNames.includes(item.agent);
    })

    dataP2.forEach((element) => {
      const monthDataElement = monthDataP2.find( (item) => item.agent === element.agent );
      element.monthInfo = monthDataElement ? formatNumber(monthDataElement.Info) : 0;
    });
    console.log('dataP2', dataP2);

		let top10TodayP1 = dataP1.sort(salesCustomSort).slice(0, 12).filter((item) => item.agent !== "Francisco Gracia");
		let top10TodayP2 = monthDataP2.sort((a, b) => b.Gross - a.Gross).slice(0, 12);

    $(".p1-ref-table").empty();
    // const theadsP1Ref = [ 'P1 Referrals', sumByKey(sortedReferralsP1, "Info").toString()];
    // buildTable( top6ReferralsP1, tBuildReferralsP1, theadsP1Ref , p1RefSec, "ref" );

    const theadsP1Sv = [ 'P1 SV Data', sumByKey(p1SvData, "Info").toString() ];
    buildTable( top5P1Sv, tBuildReferralsP1, theadsP1Sv , p1RefSec, "ref" );

		$(".p1-table").empty();
		const theadsP1 = [ 'P1 Data', sumByKey(dataP1, "Info").toString(), sumByKey(monthDataP1, "Info").toString() ];
		buildTable( top10TodayP1, tBuildTodayP1, theadsP1 , p1AppendToday, "p1" );

		todayGauge.setValue(sumByKey(dataP1, "Info"));
    monthGauge.setValue(sumByKey(monthDataP1, "Info"));

		$(".p2-table").empty();
		const theadsP2 = [ 'P2 Data', sumByKey(dataP2, "Info").toString(), formatNumber(sumByKey(monthDataP2, "Info")) ];
		buildTable(	top10TodayP2, tBuildTodayP2, theadsP2 , p2AppendToday, "p2" );

    $(".p2-ref-table").empty();
    // const theadsP2Ref = [ 'P2 Referrals', sumByKey(sortedReferralsP2, "Info").toString()];
    // buildTable( top6ReferralsP2, tBuildReferralsP2, theadsP2Ref , p2RefSec, "ref" );

    const theadsP2Sv = [ 'P2 SV Data' ];
    buildTable( top12P2Sv, tBuildReferralsP2, theadsP2Sv , p2RefSec, "ref" );

      if (loading) {
        loading = !loading;
        $(".loading").hide(); // Ocultar el loading
      }
      firstDataLoad = false;
	})
	.catch((error) => console.error(error));
}

function buildTable(tData, table, theads, appendVar, tipeOfTable) {
  const theadConstruct = $("<thead>").appendTo(table);
	const headerRow = $("<tr>").appendTo(theadConstruct);

	theads.forEach((thead) => {
  headerRow.append($("<th>").text(thead));
	});
  const tbody = $("<tbody>").appendTo(table);

  $.each(tData, function (i, item) {
    const row = $("<tr>").appendTo(tbody);

    const agentCell = $("<td>").text(item.agent).appendTo(row);
    const infoCell = $("<td>").text(item.Info).appendTo(row);
		const monthCell = $("<td>").text(item.monthInfo).appendTo(row);

    if (tipeOfTable !== "ref") {
      row.addClass(i === 0 ? "first-row" : "");
    }
    if (tipeOfTable === "p1") {
      agentCell.addClass(
        appendVar === p1AppendToday && item.Info >= dayGoodValueP1 ? "highlight" : ""
      );
      infoCell.addClass(
        appendVar === p1AppendToday && item.Info >= dayGoodValueP1 ? "highlight" : ""
      );
			monthCell.addClass(
				appendVar === p1AppendToday && item.monthInfo > (monthGoodValueP1 * 1.5) ? "highlight" : ""
			);
    } else if (tipeOfTable === "p2") {
      agentCell.addClass(
        appendVar === p2AppendToday && item.Info >= 3 ? "highlight" : ""
      );
      infoCell.addClass(
        appendVar === p2AppendToday && item.Info >= 3 ? "highlight" : ""
      );
    }
  });

  // si la tabla es de referidos, agregar dos fila vacia al final
  if (tipeOfTable === "ref") {
    const row = $("<tr>").appendTo(tbody);
    $("<td>").text("").appendTo(row);
    $("<td>").text("").appendTo(row); 
    $("<td>").text("").appendTo(row);
    const row2 = $("<tr>").appendTo(tbody);
    $("<td>").text("").appendTo(row2);
    $("<td>").text("").appendTo(row2);
    $("<td>").text("").appendTo(row2);
  }

  appendVar.append(table);
}

function setMarqueeText(text) {
  const audio = new Audio("./win.mp3");
  audio.play();
  // Mostrar el contenedor de la marquesina
  const marqueeContainer = document.getElementById("marqueeContainer");
  marqueeContainer.style.display = "block";

  const marqueeText = document.getElementById("marqueeText");
  marqueeText.textContent = text;

  // Mostrar la marquesina
  marqueeText.style.display = "inline-block";

  // Reiniciar la animación
  marqueeText.style.animation = "none";
  void marqueeText.offsetWidth;
  marqueeText.style.animation = null;

  // Ocultar la marquesina después de 5 segundos
  setTimeout(function () {
    marqueeText.style.display = "none";
    marqueeContainer.style.display = "none";
  }, 10000);
}

function salesCustomSort(a, b) {
	if (a.Info > b.Info) {
			return -1; // Orden descendente por Info (ventas del día)
	} else if (a.Info < b.Info) {
			return 1;
	} else {
			// Si las ventas del día son iguales, ordenar por monthInfo (ventas del mes)
			if (a.monthInfo > b.monthInfo) {
					return -1; // Orden descendente por monthInfo
			} else if (a.monthInfo < b.monthInfo) {
					return 1;
			} else {
					return 0; // Si ambos valores son iguales, no se cambia el orden
			}
	}
}

function getDataGET(url) {
	return new Promise((resolve, reject) => {
		$.ajax({
			url: epowerProxyURL,
			method: "POST",
			timeout: 0,
			crossDomain: true,
			headers: {
				Accept: "application/json",
				"Content-Type": "application/json",
			},
			data: JSON.stringify({
				parameters: {},
				url: `${url}`,
			}),
			success: function (response) {
				resolve(response);
			},
			error: function (xhr, status, error) {
				reject(
					new Error(`Error fetching data from ${url}. Status: ${status}`)
				);
			},
		});
	});
}

async function getDataFromSugarTeam(teamId) {
  try {
    const usersBySugarTeamURLAPI = `https://home.justicialaboral.com/bot_db/api/get_users_by_team.php?teamId=${teamId}`;
    const datosConExtension = await getDataGET(usersBySugarTeamURLAPI);

    return datosConExtension;
  } catch (error) {
    console.error(error);
    return [];
  }
}

function mapAndFilterDataP1(data, keyName, otherKeys, newKeyNames) {  // Map and filter the data for P1
  return data
    .map((lead) => {
      const newData = { agent: shortName(lead[keyName]) };

      otherKeys.forEach((key, index) => {
        const newKeyName = newKeyNames[index];
        newData[newKeyName] = parseInt(lead[key]) || 0;
      });

      return newData;
    })
    .filter((item) => item.agent !== "" && otherKeys.every((key) => item[key] !== 0)
  );
}

function processReferrals(referrals, team) {
  const teamMembers = team.map(member => member.fullname);
  // Filter the referrals by the team.fullname and referrals.user_id
  const filteredReferrals = referrals.filter(referral => teamMembers.includes(referral.user_id));

  const reducedReferrals = filteredReferrals.reduce((acc, item) => {
    const existing = acc.find(element => element.user_id === item.user_id);
    if (existing) {
      existing.referral_count = parseInt(existing.referral_count) + 1;
    } else {
      acc.push({ user_id: item.user_id, referral_count: 1 });
    }
    return acc;
  }, []);
  
  const sortedReferrals = reducedReferrals.sort((a, b) => b.referral_count - a.referral_count);

  const formattedReferrals = sortedReferrals.map((item) => {
    return {
      agent: shortName(item.user_id),
      Info: item.referral_count,
    };
  });

  return formattedReferrals;
}

function shortName(name) {
    const names = name.split(" ");
    return names[0] + " " + names[1];
  }

function formatNumber(number) {
  if (number >= 1000000) {
    return (number / 1000000).toFixed(1) + 'M';
  } else if (number >= 1000) {
    return (number / 1000).toFixed(0) + 'K';
  } else {
    return number.toString();
  }
}

function sumByKey(array, key) {
  // console.log('array', array, 'key', key);
  return array.reduce((acc, item) => acc + parseInt(item[key] || 0), 0);
}

function processSvData(svData, managers, keyName, keyEngagedTotal, keyEngagedGross) {
  const data = svData
    .filter((item) => {
      if(item[keyName] === null) {
        console.log('item', item);
        return false;
      }
      
      return !managers.includes(item[keyName]) || item[keyName] === null;
    }).sort((a, b) => b[keyEngagedGross] - a[keyEngagedGross])
    .map((item) => {
      return {
        agent: shortName(item.sv_name),
        Info: parseInt(item[keyEngagedTotal]),
        ...(keyEngagedGross ? { monthInfo: formatNumber(item[keyEngagedGross]) } : {})
      };
    })
  return data;
}

function processP1SvData(svData, managers) {
  const data = svData
    .filter((item) => {      
      return !managers.includes(item.sv_name) && item.sv_id !== null ;
    }).sort((a, b) => b.sv_engaged_total - a.sv_engaged_total)
    .map((item) => {
      return {
        agent: shortName(item.sv_name),
        Info: parseInt(item.sv_engaged_total),
      };
    })
  return data;
}