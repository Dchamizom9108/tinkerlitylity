import * as React from 'react';
import { Gauge } from '@app/components';

interface P1GaugeChartProps {
  value: number;
}

export class P1GaugeChart extends React.Component<P1GaugeChartProps, {}> {
  private gauge: any;
  private intervalId: NodeJS.Timeout | null = null;

  constructor(props: P1GaugeChartProps) {
    super(props);
    this.state = {
      size: 300,
      clipWidth: 300,
      clipHeight: 300,
      ringWidth: 60,
      maxValue: 130,
      transitionMs: 4000,
    };
  }

  componentDidMount() {
    // Gauge chart
    this.gauge = new Gauge('#power-gauge', this.state);
    // Render
    this.gauge.render();
    // First gauge value
    this.gauge.update(this.props.value);
    // Update every 10 seconds if value changes
    this.intervalId = setInterval(() => {
      if (this.gauge && this.props.value !== this.gauge.value) {
        this.gauge.update(this.props.value);
      }
    }, 10 * 1000); // 10 seconds
  }

  componentDidUpdate(prevProps: P1GaugeChartProps) {
    // Update gauge if value prop changes
    if (this.props.value !== prevProps.value) {
      this.gauge.update(this.props.value);
    }
  }

  componentWillUnmount() {
    // Clear the interval when the component unmounts
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }

  render() {
    return (
      <div className="row text-center">
        <div id="power-gauge"></div>
      </div>
    );
  }
}
