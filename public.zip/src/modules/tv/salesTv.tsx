import { useEffect, useState, useRef } from "react";
import moment from "moment";
// import { P1GaugeChart } from "./p1Gauge";
import { getDataGET } from "@app/services/proxy";

import "./tvStyles.css";

const SalesTv = () => {
  const [loaded, setLoaded] = useState(false);
  const [showMar, setShowMar] = useState(false);
  const [data, setData] = useState<nationalData[]>([]);

  const [p1, setP1] = useState<P1Data[]>([]);
  const [p1Sv, setP1Sv] = useState<P1SecondVoice[]>([]);

  const [p2, setP2] = useState<P2Data[]>([]);
  const [p2Sv, setP2Sv] = useState<P2SecondVoice[]>([]);

  const excludeList = [
    "Karla Hernandez Elizarraraz",
    "Kenneth Eduardo Perez Perez",
  ];

  useEffect(() => {
    async function getData() {
      const actualMonthName = moment().format("MMMM");
      const response = await getDataGET(
        `https://home.justicialaboral.com/bot_db/api/national.php?month=${actualMonthName}`
      );

      if (response.length > 0) {
        response.forEach((item: any) => {
          item.p1_sold_date_c = adjustDateTime(item.p1_sold_date_c);
          item.engaged_date_c = adjustDateTime(item.engaged_date_c);
        });
      }

      setData(response);
      setLoaded(true);
    }
    if (!loaded) getData();
  }, [loaded]);

  useEffect(() => {
    if (data.length > 0) {
      const today = moment().format("YYYY-MM-DD");

      const soldByNull = data.filter(
        (item) => item.p1_sold_date_c !== null && item.as_name === null
      );
      console.log(soldByNull);

      const soldAndNull = data.filter(
        (item) => item.p1_sold_date_c === null && parseInt(item.p1_amount) > 20
      );
      console.log("sold and null", soldAndNull);
      // Procesamiento de p1Sales
      const p1 = data.filter(
        (item) => item.p1_sold_date_c !== null && item.as_name !== null
      );

      //filter by this month
      const p1Filtered = p1.filter(
        (item) =>
          item.p1_sold_date_c.split(" ")[0].split("-")[1] ===
          moment().format("MM")
      );

      const p1Sales: P1Data[] = Object.values(
        p1Filtered
          .filter((item) => item.p1_amount !== null)
          .reduce<Record<string, P1Data>>((acc, item) => {
            const { as_name, p1_sold_date_c, utm_source_name } = item;

            if (!acc[as_name]) {
              acc[as_name] = {
                as_name: `${as_name.split(" ")[0]} ${as_name.split(" ")[2]}`,
                count: 0,
                todayCount: 0,
                referrals: 0,
                p1_amount: 0,
              };
            }

            if (parseInt(item.p1_amount) > 20) acc[as_name].count += 1;
            acc[as_name].p1_amount += parseFloat(item.p1_amount);
            if (p1_sold_date_c.split(" ")[0] === today) {
              acc[as_name].todayCount += 1;
            }
            if (utm_source_name === "03 - REFERRAL")
              acc[as_name].referrals += 1;

            return acc;
          }, {})
      ).sort(salesP1CustomSort);

      // Procesamiento de p1SecondVoices
      const p1SecondVoices: P1SecondVoice[] = Object.values(
        p1
          .filter((item) => item.sv1_name !== null)
          .reduce<Record<string, P1SecondVoice>>((acc, item) => {
            const { sv1_name } = item;

            if (!acc[sv1_name]) acc[sv1_name] = { sv1_name, count: 0 };

            acc[sv1_name].count += 1;

            return acc;
          }, {})
      );

      // Procesamiento de p2Sales
      const p2Filtered = data.filter((item) => item.engaged_date_c !== null);

      const p2Sales: P2Data[] = Object.values(
        p2Filtered.reduce<Record<string, P2Data>>((acc, item) => {
          const { dc_name, collected_amount, p2_amount } = item;

          if (!acc[dc_name]) {
            acc[dc_name] = {
              dc_name,
              count: 0,
              totalGrossCollected: 0,
              totalGrossEngaged: 0,
              totalAddService: 0,
              todayGross: 0,
            };
          }

          acc[dc_name].count += 1;
          acc[dc_name].totalGrossCollected += parseInt(collected_amount) || 0;
          acc[dc_name].totalGrossEngaged += parseInt(p2_amount) || 0;

          if (item.utm_source_name === "03 - ADD SERVICE")
            acc[dc_name].totalAddService += 1;

          if (item.engaged_date_c.split(" ")[0] === today)
            acc[dc_name].todayGross += parseInt(p2_amount) || 0;

          return acc;
        }, {})
      ).sort(salesP2CustomSort);

      const p2SecondVoices: P2SecondVoice[] = Object.values(
        data
          .filter((item) => item.sv_name_p2 !== null)
          .reduce<Record<string, P2SecondVoice>>((acc, item) => {
            const { sv_name_p2 } = item;

            if (!acc[sv_name_p2])
              acc[sv_name_p2] = { sv_name_p2, count: 0, secondGross: 0 };

            acc[sv_name_p2].count += 1;
            acc[sv_name_p2].secondGross += parseInt(item.p2_amount) || 0;

            return acc;
          }, {})
      );

      setP1(p1Sales);
      setP1Sv(p1SecondVoices);

      setP2(p2Sales);
      setP2Sv(p2SecondVoices);

      console.log("p1Sales", p1Sales);
      console.log("p1SecondVoices", p1SecondVoices);
      console.log("p2Sales", p2Sales);
      console.log("p2SecondVoices", p2SecondVoices);
    }
  }, [data]);

  function salesP1CustomSort(a: P1Data, b: P1Data) {
    if (a.todayCount > b.todayCount) {
      return -1; // Orden descendente por todayCount (ventas del día)
    } else if (a.todayCount < b.todayCount) {
      return 1;
    } else {
      // Si las ventas del día son iguales, ordenar por monthInfo (ventas del mes)
      if (a.count > b.count) {
        return -1; // Orden descendente por count
      } else if (a.count < b.count) {
        return 1;
      } else {
        return 0; // Si ambos valores son iguales, no se cambia el orden
      }
    }
  }

  function salesP2CustomSort(a: P2Data, b: P2Data) {
    if (a.todayGross > b.todayGross) {
      return -1; // Orden descendente por todayGross (ventas del dia)
    } else if (a.todayGross < b.todayGross) {
      return 1;
    } else {
      // Si las ventas del dia son iguales, ordenar por monthInfo (ventas del mes)
      if (a.count > b.count) {
        return -1; // Orden descendente por count
      } else if (a.count < b.count) {
        return 1;
      } else {
        return 0; // Si ambos valores son iguales, no se cambia el orden
      }
    }
  }

  // Función para ajustar la fecha restando 5 horas
  function adjustDateTime(dateTime: string | null): string | null {
    if (!dateTime) return null;
    return moment(dateTime).subtract(5, "hours").format("YYYY-MM-DD HH:mm:ss");
  }

  function formatNumber(number: number) {
    if (number >= 1000000) {
      return (number / 1000000).toFixed(1) + "M";
    } else if (number >= 1000) {
      return (number / 1000).toFixed(0) + "K";
    } else {
      return number.toString();
    }
  }

  
let todayGauge = Gauge(document.getElementById("today_test"), {
  max: dayValue,
  value: 0,
  label: function (value) {
    return value + " / " + dayValue;
  },
  color: function (value) {
    let percentage = (value / dayValue) * 100; // Calcular el porcentaje
    let hue = (percentage / 100) * 120; // Rango de colores de rojo a verde (120 grados)
    let color = "hsl(" + hue + ", 100%, 50%)"; // Crear el color HSL
    return color;
  },
});

let monthGauge = Gauge(document.getElementById("month_test"), {
  max: monthValue,
  value: 0,
  label: function (value) {
    return value + " / 3K";
  },
  color: function (value) {
    let percentage = (value / monthValue) * 100; // Calcular el porcentaje
    let hue = (percentage / 100) * 120; // Rango de colores de rojo a verde (120 grados)
    let color = "hsl(" + hue + ", 100%, 50%)"; // Crear el color HSL
    return color;
  },
});


  return (
    <section className="tv-page">
      <div className={"loading" + (loaded ? " hide" : "")}>
        <div className="center">
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
          <div className="wave"></div>
        </div>
      </div>
      {showMar && (
        <div>
          <div
            id="marqueeContainer"
            className={"marquee-container" + (loaded ? "" : " hide")}
          >
            <span id="marqueeText" className="marquee-text"></span>
          </div>
        </div>
      )}

      <div className={"main-container" + (loaded ? "" : " hide")}>
        <div className="left_container">
          <div className="tv-card">
            <div className="front">
              <div className="table-container-left">
                {
                  <table className={`table-p1`}>
                    <thead>
                      <tr>
                        <th>Agent</th>
                        <th>
                          {p1.reduce(
                            (total, item) => total + item.todayCount,
                            0
                          )}
                        </th>
                        <th>
                          {p1.reduce((total, item) => total + item.count, 0)}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {p1.slice(0, 12).map((item, index) => {
                        const isFirstRow = index === 0;
                        let highlightClass = "";

                        if ((item as P1Data).count >= 3) {
                          highlightClass = "highlight";
                        }

                        return (
                          <tr
                            key={index}
                            className={isFirstRow ? "first-row" : ""}
                          >
                            <td className={highlightClass}>{item.as_name}</td>
                            <td className={highlightClass}>
                              {item.todayCount}
                            </td>
                            <td className={highlightClass}>
                              {(item as P1Data).count}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                }
              </div>
            </div>
            <div className="back">
              <div className="p1RefSec table-container-left"></div>
            </div>
          </div>
        </div>

        <div className="center_container">
  <div className="tv_top_box">
    <div id="cpuSpeed" className="gauge-container">

    </div>
  </div>
  <div className="tv_center_box"></div>
  <div className="tv_bottom_box"></div>
</div>


        <div className="right_container">
          <div className="tv-card">
            <div className="front">
              <div className="table-container-right">
                {
                  <table className={`table-p2`}>
                    <thead>
                      <tr>
                        <th>Agent</th>
                        <th>
                          {formatNumber(
                            p2.reduce(
                              (total, item) => total + item.todayGross,
                              0
                            )
                          )}
                        </th>
                        <th>
                          {formatNumber(
                            p2.reduce(
                              (total, item) => total + item.totalGrossEngaged,
                              0
                            )
                          )}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {p2.slice(0, 12).map((item, index) => {
                        const isFirstRow = index === 0;
                        let highlightClass = "";

                        if ((item as P2Data).count >= 3) {
                          highlightClass = "highlight";
                        }

                        return (
                          <tr
                            key={index}
                            className={isFirstRow ? "first-row" : ""}
                          >
                            <td
                              className={highlightClass}
                            >{`${item.dc_name.split(" ")[0]} ${item.dc_name.split(" ")[1]}`}</td>
                            <td className={highlightClass}>
                              {formatNumber(item.todayGross)}
                            </td>
                            <td className={highlightClass}>
                              {formatNumber(item.totalGrossEngaged)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                }
              </div>
            </div>
            <div className="back">
              <div className="p2RefSec table-container-right"></div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <header>
          <div id="marqueediv" className="marquee-container hide">
            <span id="marqueeText" className="marquee-text"></span>
          </div>
        </header>
      </div>
    </section>
  );
};

export default SalesTv;

interface nationalData {
  amount: string;
  as_name: string;
  branch: string;
  case_id_c: string;
  collected_amount: string;
  dc_name: string;
  engaged_date_c: string;
  id: string;
  lead_id: string;
  lead_type_c: string;
  local_amount: string;
  month: string;
  p1_amount: string;
  p1_sold_date_c: string;
  p2_amount: string;
  service_subtype_c: string;
  service_type_c: string;
  sv1_id: string;
  sv1_name: string;
  sv2_id: string;
  sv2_name: string;
  sv_id_p2: string;
  sv_name_p2: string;
  total_amount: string;
  utm_source_name: string;
}

// Interfaces
interface P1Data {
  as_name: string;
  count: number;
  todayCount: number;
  referrals: number;
  p1_amount: number;
}

interface P1SecondVoice {
  sv1_name: string;
  count: number;
}

interface P2Data {
  dc_name: string;
  count: number;
  totalGrossCollected: number;
  totalGrossEngaged: number;
  totalAddService: number;
  todayGross: number;
}

interface P2SecondVoice {
  sv_name_p2: string;
  count: number;
  secondGross: number;
}
