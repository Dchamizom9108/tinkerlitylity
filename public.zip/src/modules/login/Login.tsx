import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { setCurrentUser } from "@store/reducers/auth";
import { setWindowClass } from "@app/utils/helpers";
import { useAppDispatch } from "@app/store/store";
import { saveAuthToken } from "@app/services/auth";
import { getUser, getUserDetail, getAccountId } from "@app/services/user";

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  useEffect(() => {
    const fetchData = async () => {
      const urlSearchParams = new URLSearchParams(window.location.search);
      const params = Object.fromEntries(urlSearchParams.entries()) as {
        [key: string]: string;
      };
      // https://users.consumerlaw.com/login
      // http://localhost:5173/login
      if (params.access_token) {
        const res = await saveAuthToken(params.access_token);
        if (res?.status === 200) {
          const role = await getUser();
          const data = res.data;
          data.user.role = role.data.role.name;
          const account = await getAccountId(data.user.email);
          if (account) {
            let user : any = await getUserDetail(account);
            //remove day_logs from user
            user = user.data.data.attributes;
            user.id = account;
            delete user.day_log;
            delete user.o365Data.assignedPlans;
            delete user.tcxData;
            delete user.sugarData;

            data.user.account = user;
          }
          dispatch(setCurrentUser(data));
          navigate("/");
        }
      } else {
        navigate("/login");
      }
    };
    fetchData();
  }, [dispatch, navigate]);

  setWindowClass("hold-transition login-page");

  return (
    <div className="login-box">
      <div className="login-logo">
        <b>Admin</b>CLG
      </div>
      <div className="card">
        <div className="card-body login-card-body">
          <p className="login-box-msg">Sign in to start your session</p>
          <a
            href="https://itback.consumerlaw.com/api/connect/microsoft"
            className="btn btn-block btn-primary"
          >
            <i className="fab fa-windows"></i> Sign in using Office 365
          </a>
        </div>
      </div>
    </div>
  );
};

export default Login;
