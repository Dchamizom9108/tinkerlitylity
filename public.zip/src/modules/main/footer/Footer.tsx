import packageJSON from '../../../../package.json';

const Footer = ({
  style = {},
  containered,
}: {
  style?: any;
  containered?: boolean;
}) => {

  return (
    <footer className="main-footer" style={{ ...style }}>
      <div
        style={{
          width: '100%',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
        className={containered ? 'container' : ''}
      >
        <strong>
          <span>Copyright © {new Date().getFullYear()} </span>
          <a
            href="https://users.consumerlaw.com"
            target="_blank"
            rel="noopener noreferrer"
          >
            consumerlaw.com
          </a>
          <span>.</span>
        </strong>
        <div className="float-right d-none d-sm-inline-block">
          <b>{'Version'}</b>
          <span>&nbsp;{packageJSON.version}</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
