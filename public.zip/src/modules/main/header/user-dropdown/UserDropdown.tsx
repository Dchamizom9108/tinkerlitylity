import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { StyledSmallUserImage } from '@app/styles/common';
import {
  UserFooter,
  UserMenuDropdown,
} from '@app/styles/dropdown-menus';
import {} from '@app/index';
import { useAppSelector } from '@app/store/store';
import { logout } from '@app/services/auth';

import { getUserPic } from '@app/services/user';

const UserDropdown = () => {
  const navigate = useNavigate();
  const currentUser = useAppSelector((state) => state.auth.currentUser);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [pic, setPic] = useState('/img/default-profile.png')

  useEffect(() => {
    const oid = currentUser?.user?.account?.o365Data?.id;
    const getPic = async (oid : any) => {
      getUserPic(oid).then(res => {
        if(res !== 'error') {
          const imageSrc = res;
          setPic(imageSrc);
          localStorage.setItem(`userPic-${oid}`, imageSrc);
        }
      });
    }
    if(oid) {
      const cachedPic = localStorage.getItem(`userPic-${oid}`);
      
      if (cachedPic) {
        setPic(cachedPic);
      } else {
        getPic(oid);
      }
    }
  }, [currentUser]);
  
  const logOut = async (event: any) => {
    logout();
    event.preventDefault();
    setDropdownOpen(false);
  };

  const navigateToProfile = (event: any) => {
    event.preventDefault();
    setDropdownOpen(false);
    navigate(`/users/${currentUser?.user?.account.id}`);
  };

  return (
    <UserMenuDropdown isOpen={dropdownOpen} hideArrow>
      <StyledSmallUserImage
        slot="head"
        src={pic}
        fallbackSrc="/img/default-profile.png"
        alt="User"
        width={25}
        height={25}
        rounded
      />
      <div slot="body">

        <UserFooter>
          <button
            type="button"
            className="btn btn-default btn-flat"
            onClick={navigateToProfile}
          >
            {'Profile'}
          </button>
          <button
            type="button"
            className="btn btn-default btn-flat float-right"
            onClick={logOut}
          >
            {'Sign out'}
          </button>
        </UserFooter>
      </div>
    </UserMenuDropdown>
  );
};

export default UserDropdown;
