import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { GETMyselfUserData, GETUserDayLogs } from "@app/services/rh";
import Swal from "sweetalert2";
import { getMonthName } from "@app/services/time";

const AsistStatus = () => {
  const [isRegistered, setIsRegistered] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const checkRegistrationStatus = async () => {
      try {
        const todayDate = new Date().toISOString().split("T")[0];
        const log = await GETMyselfUserData();
        // console.log("log", log);

        const asistlogs = await GETUserDayLogs(log.id);
        // console.log("asistlogs", asistlogs);

        if (asistlogs.length > 0) {
          // console.log("asistlogs", asistlogs);
          const asistlog = asistlogs[0];
          const dayLogs = asistlog?.attributes || {};
          const month = getMonthName(new Date().toISOString().split("T")[0]);
          const monthLogs = dayLogs[month] || {}; // Logs del mes actual
          const todayLogs = monthLogs[todayDate] || null; // Logs del dia actual
          // console.log("todayLogs", todayLogs);
          if (todayLogs === null) {
            if (log.asignedCalendar[todayDate]) {
              if (log.asignedCalendar[todayDate].work === true) {
                // console.log("log", log.asignedCalendar[todayDate]);
                Swal.fire({
                  icon: "warning",
                  title: "You are not registered today!",
                  showConfirmButton: true,
                  confirmButtonText: "Register",
                  showCancelButton: true,
                  cancelButtonText: "Cancel",
                  cancelButtonColor: "#d33",
                }).then((result) => {
                  if (result.isConfirmed) {
                    navigate(`/set-assistance`);
                  }
                });
              }
            }
          } else {
            setIsRegistered(true);
          }
        }
      } catch (error) {
        console.error("Error checking registration status:", error);
      }
    };

    // Initial check and interval setup
    checkRegistrationStatus();
  }, []);

  const handleButtonClick = (event: any) => {
    event.preventDefault();
    navigate(`/set-assistance`);
  };

  return (
    <a
      type="button"
      className={`status-circle ${isRegistered ? "status-circle--green" : "status-circle--red"}`}
      aria-label="toggle theme"
      onClick={handleButtonClick}
    >
      <span className="status-circle__icon">
        <i className="fas fa-user-check"></i>
      </span>
    </a>
  );
};

export default AsistStatus;
