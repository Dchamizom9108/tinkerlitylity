
import { useAppSelector } from '@app/store/store';
import React from 'react';

interface IMenuItem {
  id: string;
  text: string;
  icon: string;
  href: string;
  roles?: string[];
  emails?: string[];
  subItems?: IMenuItem[];
}

interface MenuHeaderProps {
  icon: string;
  text: string;
  id: string;
  handleClick: (id: string) => void;
  isOpen?: boolean;
}

interface MenuItemProps {
  href: string;
  icon: string;
  text: string;
}

function MenuSidebar() {
  const sidebarSkin = useAppSelector((state) => state.ui.sidebarSkin);
  const user = useAppSelector((state) => state.auth.currentUser);

  const role = user?.user.role;
  const email = user?.user?.email;
  let uiDarkMode = useAppSelector((state) => state.ui.darkMode);

  const MenuList = [
    {
      id: "sharepoint",
      icon: "cloud",
      text: "CLG Sharepoint",
      subItems: [
        { href: "https://clawgroup.sharepoint.com/sites/CLGBackoffice", icon: "hdd", text: "CLG Backoffice" },
        { href: "https://clawgroup.sharepoint.com/sites/Share/Office/Forms/AllItems.aspx", icon: "hdd", text: "O Drive" },
        { href: "https://clawgroup.sharepoint.com/sites/Share/Files/Forms/AllItems.aspx", icon: "hdd", text: "S Drive" },
      ],
    },
    {
      id: "reports",
      icon: "chart-pie",
      text: "Reports",
      subItems: [
        {
          id: "p1Reports",
          icon: "database",
          text: "P1 Reports",
          subItems: [
            { href: "https://home.justicialaboral.com/bot_db/teamp1Performance/", icon: "table", text: "Team Performance" },
            // { href: "https://home.justicialaboral.com/bot_db/p1SalesTable/", icon: "calendar-alt", text: "P1 Sales" },
            { href: "https://home.justicialaboral.com/bot_db/salesTv/", icon: "tv", text: "Sales Tv Report", roles: ["Admin"] },
          ],
        },
        // { href: "https://home.justicialaboral.com/bot_db/screenerFreeTable/", icon: "database", text: "Screener Report" },
        // { href: "/sales-q/status", icon: "blender-phone", text: "Sales Queue" },
        { href: "/reports/tcx-report", icon: "users", text: "Wallboard" },
        { href: "/reports/wallboard", icon: "users", text: "Wallboard IT", email: "dchamizo@consumerlaw.com" },
      ],
    },
    {
      id: "university",
      icon: "graduation-cap",
      text: "CLG University",
      subItems: [
        { href: "/university-sales", icon: "chalkboard-teacher", text: "Sales" },
        { href: "/university-legal", icon: "balance-scale", text: "Legal" },
        { href: "/university/create", icon: "plus", text: "Create Course", roles: ["Admin"] },
      ],
    },
    {
      id: "users",
      icon: "users",
      text: "Users",
      subItems: [
        { href: "/users", icon: "list", text: "User List" },
        { href: "/users/create", icon: "user-plus", text: "Create User" },
      ],
      roles: ["Admin"],
    },
    /*
    {
      id: "notifications",
      icon: "bell",
      text: "Notifications",
      subItems: [
        { href: "/notifications", icon: "list", text: "Notification List" },
        { href: "/notifications/create", icon: "plus", text: "Create Notification" },
      ],
      roles: ["Admin"],
    },
    */
    {
      id: "itTools",
      icon: "tools",
      text: "IT Tools",
      subItems: [
        { href: "/users/map", icon: "sitemap", text: "Sales Map" },
      ],
      emails: ["mcruz@consumerlaw.com", "dchamizo@consumerlaw.com"],
    },
    {
      id: "assistance",
      icon: "user-clock",
      text: "RH Tools",
      subItems: [
        { href: `/set-assistance`, icon: "fingerprint", text: "Assistance" },
        { href: "/rh/shifts", icon: "clock", text: "Shifts", roles: ["Admin"] },
        { href: "/rh/calendar/department", icon: "calendar-alt", text: "Department Calendar", roles: ["Admin"] },
        {
          id: "rhReports",
          icon: "database",
          text: "RH Reports",
          subItems: [
            { href: "/rh/dashboard", icon: "chart-line", text: "Dashboard", roles: ["Admin"] },
            { href: "/rh/assistance/list", icon: "list", text: "Assistances", roles: ["Admin"] },
          ],
        },
      ],
    },
    {
      id: "organizations", 
      icon: "tasks", 
      text: "Organizations",
      subItems: [
        { href: "/org", icon: "chart-pie", text: "Org Chart" },
        { href: "/org/edit", icon: "list", text: "Edit Org" },
      ],
      emails: ["dchamizo@consumerlaw.com"],
    }
  ];

  const [selectedMenu, setSelectedMenu] = React.useState<{ [key: string]: boolean }>({});

  function handleClick(part: string) {
    setSelectedMenu((prevMenu) => ({
      ...prevMenu,
      [part]: !prevMenu[part],
    }));
  }

  const MenuItem: React.FC<MenuItemProps> = ({ href, icon, text }) => (
    <li className="nav-item" role="list">
      <a href={href} className="nav-link">
        <i className={`nav-icon fas fa-${icon}`} />
        <p>{text}</p>
      </a>
    </li>
  );

  const MenuHeader: React.FC<MenuHeaderProps> = ({ icon, text, id, handleClick }) => (
    <div className="nav-link" onClick={() => handleClick(id)}>
      <i className={`nav-icon fas fa-${icon}`} />
      <p>
        {text}
        <i className="fas fa-angle-left right" />
      </p>
    </div>
  );

  const renderMenuItems = (items: IMenuItem[]) => {
    return items.map((item) => {
      if (item.roles && !item.roles.includes(role)) return null;
      if (item.emails && !item.emails.includes(email)) return null;

      if (item.subItems) {
        const subMenuItems = renderMenuItems(item.subItems);
        if (subMenuItems.every(subItem => subItem === null)) return null; // Oculta el menú padre si todos los submenús están ocultos

        return (
          <li key={item.id} className={selectedMenu[item.id] ? "nav-item menu-is-opening menu-open" : "nav-item"} role="list">
            <MenuHeader
              icon={item.icon}
              text={item.text}
              id={item.id}
              handleClick={handleClick}
              isOpen={selectedMenu[item.id]}
            />
            <ul className="nav-treeview" style={{ display: selectedMenu[item.id] ? "block" : "none" }}>
              {subMenuItems}
            </ul>
          </li>
        );
      }

      return <MenuItem key={item.href} href={item.href} icon={item.icon} text={item.text} />;
    });
  };

  return (
    <aside className={`main-sidebar elevation-4 ${sidebarSkin}`}>
      {/* Brand Logo */}
      <a href="/" className="brand-link">
        <img
          src={uiDarkMode ? '/img/logoshield.png' : '/img/logoshield_l.png'}
          alt="Consumer Law Group Logo"
          className="brand-image"
          style={{ opacity: ".8" }}
        />
        <span className="brand-text font-weight-light">
          <small>Consumer Law Group</small>
        </span>
      </a>
      {/* Sidebar */}
      <div className="sidebar">
        {/* Sidebar Menu */}
        <nav className="mt-2">
          <ul
            className="nav nav-pills nav-sidebar flex-column nav-child-indent"
            data-widget="treeview"
            role="menu"
            data-accordion="true"
          >
            {renderMenuItems(MenuList as IMenuItem[])}
          </ul>
        </nav>
        {/* /.sidebar-menu */}
      </div>
      {/* /.sidebar */}
    </aside>
  );
}

export default MenuSidebar;
