// types/index.ts
export interface OptionType {
  label: string;
  value: any;
}

export interface DepartmentsType {
  id: number;
  name: any;
  accounts: UserAttributes[];
}

export interface UserAttributes {
  // Define aquí los atributos del usuario que esperas recibir
  firstName: string;
  lastName: string;
  email: string;
  department: string;
  departments: any;
  ignoreErrors: boolean;
  userTemplate: any;
  link: object;
  id: number;
  o365: any;
  sugar: any;
  tcx: any;
  o365Enable: boolean;
  sugarEnable: boolean;
  tcxEnable: boolean;
  name: string;
  asignedCalendar: any;
  restDay: string;

  // Otros atributos según sea necesario
}

export interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  actionToExecute: string;
  effectiveDate: Date;
  jobTitle: string | null;
  departments: any;
  notes: string;
  suspensionPeriod: string;
  deactivationType: string;
  processing: boolean;
  startDate: Date | null;
  departmentsOptions?: OptionType[]; // Añadido para manejar las opciones de departamentos
}

export interface UserRh {
  userId: number;
  logs: any;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
}

export interface UserRhGrouped {
  [key: string]: UserRh[];
}

// Tipos para TypeScript
export interface Shift{
  id: number;
  accounts: number[];
  active: boolean;
  name: string;
  rotative: boolean;
  timesheet: {
    workDays: string[];
    restDays: string[];
    startTime: string;
    endTime: string;
  };
}

export interface TimeSheet{
  startTime: string;
  endTime: string;
  workDays: string[];
  restDays: string[];
}

export interface LogEntries {
  [key: string]: {
    typeOfLog: string;
    setAt: string;
    status: string;
    ip: string;
  };
}

export interface TcxData {
  id: string;
  data_date: string;
  agent: string;
  inboundAnswered: number;
  inboundUnanswered: number;
  outboundAnswered: number;
  outboundUnanswered: number;
  totalAnswered: number;
  totalUnanswered: number;
  totalTalkingTime: string;
  timeSet: string;
}