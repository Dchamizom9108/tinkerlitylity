import axios from "axios";

const epowerProxyGetSugarDataURL =
  "https://bots.consumerlaw.com/proxy_sugar_data";
const epowerProxyURL = "https://bots.consumerlaw.com/proxy";
const epowerProxyURLPOST = "https://bots.consumerlaw.com/proxy_post";
const secureProxyAPI = "https://bots.consumerlaw.com/api";

export const getDataGET = async (url: string) => {
  try {
    const response = await axios.post(epowerProxyURL, {
      parameters: {},
      url: url,
    });
    return response.data;
  } catch (error : any) {
    throw new Error(
      `Error fetching data from ${url}. Status: ${error.response.status}`
    );
  }
}

  export const getDataPOST = async (url: string, data: any) => {

    try {
      const response = await axios.post(epowerProxyURLPOST, {
        parameters: data,
        url: url,
      });
      return response.data;
    } catch (error : any) {
      throw new Error( `Error fetching data from ${url}. Status: ${error.response.status}`
    )}
  }

  export const getSugarDataNode = async (url: string, tokenSugar: string) => {
    try {
      const response = await axios.post(epowerProxyGetSugarDataURL, {
        parameters: {},
        url: url,
        token: tokenSugar,
      });
      return response.data;
    } catch (error : any) {
      throw new Error(
        `Error fetching data from ${url}. Status: ${error.response.status}`
      );
    }
  }

  export const getUsersFromSugarTeam = async (teamId: string) => {
    const usersBySugarTeamURLAPI = `https://home.justicialaboral.com/bot_db/api/get_users_by_team.php?teamId=${teamId}`;
    try {
      const response = await axios.post(epowerProxyURL, {
        parameters: {},
        url: usersBySugarTeamURLAPI,
      });
      return response.data;
    } catch (error : any) {
      throw new Error(
        `Error fetching data from ${usersBySugarTeamURLAPI}. Status: ${error.response.status}`
      );
    }
  }

  export const sendEmailFromSupport = async (email : any) => {
    try {
      const data = {
        "recipients": email.recipients,
        "subject": email.subject,
        "emailBody": email.emailBody
      }

      let config = {
        method: 'post',
        maxBodyLength: Infinity,
        url: `${secureProxyAPI}/emailService`,
        headers: { 
          'Content-Type': 'application/json', 
        },
        data : data
      };

      const response = await axios.request(config)
      return response;
    } catch (error : any) {
      throw new Error(error.message)
    }
  }

  export const sendEmailFromRh = async (data : any) => {
    try {
    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: `${secureProxyAPI}/rhEmailService`,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };
    return axios.request(config);
  } catch (error : any) {
    throw new Error(error.message)
  }
  }
