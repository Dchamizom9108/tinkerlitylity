import moment from "moment";
// Configurar moment para que la semana comience el lunes
moment.updateLocale("en", {
  week: {
    dow: 1, // Lunes como el primer día de la semana (0 es domingo, 1 es lunes)
  },
});

import { sendEmailFromRh } from "./proxy";
import axios from "axios";
import { authHeader } from "@app/services/auth"; // Ajusta la ruta de importación según sea necesario

import { Shift, TimeSheet, UserAttributes, LogEntries } from "@app/types";

const API_URL = "https://itback.consumerlaw.com/api";

export const parseTime = (timeStr: string | undefined) => {
  if (!timeStr) return null;
  const [hours, minutes, seconds] = timeStr.split(":").map(Number);
  const date = new Date();
  date.setHours(hours, minutes, seconds, 0);
  return date;
};

export const getTimeDifferenceInMinutes = (time1: string, time2: string) => {
  const parsedTime1: any = parseTime(time1);
  const parsedTime2: any = parseTime(time2);
  return (parsedTime1 - parsedTime2) / 60000; // Convertir diferencia de tiempo a minutos
};

export const getToday = (type: string) => {
  let dateSubmitted = new Date();
  dateSubmitted.setUTCHours(dateSubmitted.getUTCHours() - 5);
  let dateSubmittedString = dateSubmitted.toISOString();
  const date = dateSubmittedString.split("T")[0];
  const time = dateSubmittedString.split("T")[1].split(".")[0];
  if (type === "date") {
    return date;
  } else if (type === "time") {
    return time;
  }
};

export const getMonthName = (date: string) => {
  const monthNumber = date.split("-")[1];
  const months = [
    "jan",
    "feb",
    "mar",
    "apr",
    "may",
    "jun",
    "jul",
    "aug",
    "sep",
    "oct",
    "nov",
    "dec",
  ];
  return months[parseInt(monthNumber) - 1] || "";
};

/* //////////////////////////////////////////////////////////////////////////////////////*/
/* ///////////////////////////////Checador con Turnos//////////////////////////////////*/
/* //////////////////////////////////////////////////////////////////////////////////////*/

export const userTimeCheck = async (
  logType: string,
  logs: LogEntries,
  userData: UserAttributes
): Promise<string> => {
  const time =
    getToday("time") ||
    new Date().toLocaleTimeString("en-US", { hour12: false });
  const date = getToday("date") || new Date().toISOString().split("T")[0];

  let status = "OnTime";

  // Lógica para otros tipos de logs (descanso, almuerzo)
  const logValues = Object.values(logs);
  const lastLog = logValues[logValues.length - 1];
  const lastLogTime = lastLog ? lastLog.setAt : "";

  if (logType === "startBreak" || logType === "startLunch") {
    return "OnTime"; // Siempre OnTime para el inicio del descanso/almuerzo
  } else if (logType === "endBreak") {
    const timeDiff = getTimeDifferenceInMinutes(time, lastLogTime);
    status = timeDiff <= 11 ? "OnTime" : "Late"; // OnTime si el tiempo es <= 11 minutos
  } else if (logType === "endLunch") {
    const timeDiff = getTimeDifferenceInMinutes(time, lastLogTime);
    status = timeDiff <= 62 ? "OnTime" : "Late"; // OnTime si el tiempo es <= 62 minutos
  } else if (logType === "startShift") {
    if (!userData.asignedCalendar) {
      const [hour, minute] = time.split(":").map(Number);

      if (hour < 9 || (hour === 9 && minute <= 2)) {
        return "OnTime"; // OnTime si es antes de las 09:02:00
      } else if (hour < 10 || (hour === 10 && minute <= 30)) {
        status = "Late"; // Late si es entre las 09:02:01 y las 10:30:00
      } else if (hour < 12 || (hour === 12 && minute <= 2)) {
        return "OnTime"; // OnTime si es entre las 10:30:01 y las 12:02:00
      } else {
        status = "Late"; // Late si es después de las 12:02:01
      }
    } else {
      // Caso: Usuario con calendario asignado

      const calendarEntry = userData.asignedCalendar[date];
      if (!calendarEntry || !calendarEntry.work) {
        return "OnTime"; // OnTime si es un día de descanso
      }

      const { startwork } = calendarEntry;
      const [startHour, startMinute] = convertTo24HourFormat(startwork);
      const [currentHour, currentMinute] = time.split(":").map(Number);

      if (
        // Calcular retraso con tolerancia de 2 minutos
        currentHour > startHour ||
        (currentHour === startHour && currentMinute > startMinute + 2)
      ) {
        status = "Late"; // Late si se pasa del tiempo asignado más 2 minutos
      }
    }
  } else {
    return "OnTime"; // Si no es un tipo de log reconocido, se considera OnTime
  }

  if (logType === "startShift") {
    const emails = [];
    emails.push(userData.email);

    const simpleManual = `${userData.firstName} ${userData.lastName} sets ${logType} at ${time} on ${date}`;

    const emailSend = await sendEmailFromRh({
      emailTo: emails.join(", "),
      subject: `${userData.firstName} is registering ${logType}`,
      body: {
        action: "personalized",
        manual: simpleManual,
      },
    });
    console.log(emailSend);
  }

  if (status === "Late") {
    await warningManagers(logType, userData, time, date);
  }

  return status;
};

export const formatTime = (seconds: number) => {
  const absSeconds = Math.abs(seconds);
  const minutes = Math.floor(absSeconds / 60);
  const remainingSeconds = absSeconds % 60;
  return `${seconds < 0 ? "-" : ""}${String(minutes).padStart(2, "0")}:${String(remainingSeconds).padStart(2, "0")}`;
};

export const populateDepManagers = async (uid: number) => {
  const filtersID = [76, 78];
  // console.log("populateDepManagers", uid);
  const departments = await axios.get(
    `${API_URL}/accounts/${uid}?populate[departments]=*`,
    { headers: authHeader() }
  );
  console.log("departments", departments.data.data);

  const departmentsIds = departments.data.data.attributes.departments.data.map(
    (department: any) => department.id
  );
  console.log("departmentsIds", departmentsIds);

  // exclude departments with id 76 and 78
  const filteredDepartmentsIds = departmentsIds.filter(
    (departmentId: any) => !filtersID.includes(departmentId)
  );
  console.log("filteredDepartmentsIds", filteredDepartmentsIds);

  const departmentManagers = await Promise.all(
    filteredDepartmentsIds.map(async (departmentId: any) => {
      const managers = await axios.get(
        `${API_URL}/departments/${departmentId}?populate[managers]=*`,
        { headers: authHeader() }
      );
      console.log("managers", managers.data.data);

      const managersIds = managers.data.data.attributes.managers.data.map(
        (managers: any) => {
          const id = managers.id;
          const email = managers.attributes.email;

          return { id, email };
        }
      );

      return managersIds;
    })
  );

  // transform the array of arrays into a single array
  const departmentManagersFlat = departmentManagers.flat();
  // console.log("departmentManagersFlat", departmentManagersFlat);
  return departmentManagersFlat;
};

const convertTo24HourFormat = (time12h: string): [number, number] => {
  const [time, modifier] = time12h.split(" ");
  let [hours, minutes] = time.split(":").map(Number);

  if (modifier === "PM" && hours !== 12) {
    hours += 12;
  }
  if (modifier === "AM" && hours === 12) {
    hours = 0;
  }

  return [hours, minutes];
};
/* //////////////////////////////////////////////////////////////////////////////////////*/
/* ///////////////////////////////Checador con Turnos//////////////////////////////////*/
/* //////////////////////////////////////////////////////////////////////////////////////*/

/* //////////////////////////////////////////////////////////////////////////////////////*/
/* ///////////////////////////////Calendario de Turnos//////////////////////////////////*/
/* //////////////////////////////////////////////////////////////////////////////////////*/

export const generateCalendar = async (shift: Shift, timesheet: TimeSheet) => {
  const restDays = timesheet.restDays; // Días de descanso
  const isRotative = shift.rotative; // Determina si el turno es rotativo

  // Convertir los horarios al formato "HH:mm:ss A"
  const primaryStartTime = moment(timesheet.startTime, "HH:mm").format(
    "hh:mm:ss A"
  );
  const primaryEndTime = moment(timesheet.endTime, "HH:mm").format(
    "hh:mm:ss A"
  );

  // Horarios
  const timeA = ["09:00:00 AM", "06:00:00 PM"];
  const timeB = ["12:00:00 PM", "09:00:00 PM"];
  const timeWeekend = ["09:00:00 AM", "06:00:00 PM"];

  let altStartTime, altEndTime;

  if (primaryStartTime === timeA[0] && primaryEndTime === timeA[1]) {
    altStartTime = timeB[0];
    altEndTime = timeB[1];
  } else {
    altStartTime = timeA[0];
    altEndTime = timeA[1];
  }

  const startDate = moment(); // Fecha de inicio
  const endDate = moment().add(6, "months").endOf("month"); // Fecha fin

  const calendar: Record<
    string,
    { work: boolean; startwork?: string; endwork?: string }
  > = {};

  let currentWeekUsesAlt = false;
  let currentRestDay = restDays[0];

  for (
    let date = moment(startDate);
    date.isSameOrBefore(endDate);
    date.add(1, "day")
  ) {
    const dayName = date.format("dddd");
    const isWeekend = dayName === "Saturday" || dayName === "Sunday";
    const isRestDay = dayName === currentRestDay;

    if (isRestDay) {
      calendar[date.format("YYYY-MM-DD")] = {
        work: false,
      };
    } else {
      // Día laboral
      let startwork = currentWeekUsesAlt ? altStartTime : primaryStartTime;
      let endwork = currentWeekUsesAlt ? altEndTime : primaryEndTime;

      // Si es fin de semana, aplicar horario fijo
      if (isWeekend) {
        startwork = timeWeekend[0];
        endwork = timeWeekend[1];
      }

      calendar[date.format("YYYY-MM-DD")] = {
        work: true,
        startwork,
        endwork,
      };
    }

    // Alternar semana y día de descanso al final del domingo
    if (dayName === "Sunday" && isRotative) {
      currentWeekUsesAlt = !currentWeekUsesAlt; // Alternar horario
      if (currentRestDay === "Saturday" || currentRestDay === "Sunday") {
        currentRestDay = currentRestDay === "Saturday" ? "Sunday" : "Saturday";
      } else {
        currentRestDay = restDays[0];
      }
    }
  }

  return calendar;
};

export const genCstmCalGenaro = async () => {
  const startDate = moment(); // Fecha de inicio
  const endDate = moment().add(9, "months").endOf("month"); // Fecha fin

  const calendar: Record<
    string,
    { work: boolean; startwork?: string; endwork?: string }
  > = {};

  for (
    let date = moment(startDate);
    date.isSameOrBefore(endDate);
    date.add(1, "day")
  ) {
    const dayName = date.format("dddd");

    switch (dayName) {
      case "Monday":
      case "Friday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: true,
          startwork: "09:00:00 AM",
          endwork: "06:00:00 PM",
        };
        break;
      case "Tuesday":
      case "Wednesday":
      case "Thursday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: true,
          startwork: "12:00:00 PM",
          endwork: "09:00:00 PM",
        };
        break;
      case "Saturday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: false,
        };
        break;
      case "Sunday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: true, // Puedes cambiar esto a false si no trabaja los domingos
          startwork: "09:00:00 AM", // Puedes ajustar el horario de los domingos
          endwork: "06:00:00 PM", // Puedes ajustar el horario de los domingos
        };
        break;
    }
  }

  return calendar;
};

export const genCstmCalFixedMorningRotateWeek = async () => {
  const startDate = moment();
  const endDate = moment().add(9, "months").endOf("month");

  const calendar: Record<
    string,
    { work: boolean; startwork?: string; endwork?: string }
  > = {};

  let restsOnSaturday = true; // Variable para controlar qué día se descansa

  for (
    let date = moment(startDate);
    date.isSameOrBefore(endDate);
    date.add(1, "day")
  ) {
    const dayName = date.format("dddd");

    switch (dayName) {
      case "Monday":
      case "Tuesday":
      case "Wednesday":
      case "Thursday":
      case "Friday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: true,
          startwork: "09:00:00 AM",
          endwork: "06:00:00 PM",
        };
        break;
      case "Saturday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: restsOnSaturday, // Descansa o trabaja según la variable
        };
        if (restsOnSaturday) {
          calendar[date.format("YYYY-MM-DD")].startwork = undefined;
          calendar[date.format("YYYY-MM-DD")].endwork = undefined;
        } else {
          calendar[date.format("YYYY-MM-DD")].startwork = "09:00:00 AM";
          calendar[date.format("YYYY-MM-DD")].endwork = "06:00:00 PM";
        }
        break;
      case "Sunday":
        calendar[date.format("YYYY-MM-DD")] = {
          work: !restsOnSaturday, // Lo contrario del sábado
        };
        if (!restsOnSaturday) {
          calendar[date.format("YYYY-MM-DD")].startwork = undefined;
          calendar[date.format("YYYY-MM-DD")].endwork = undefined;
        } else {
          calendar[date.format("YYYY-MM-DD")].startwork = "09:00:00 AM";
          calendar[date.format("YYYY-MM-DD")].endwork = "06:00:00 PM";
        }
        break;
    }

    // Alternar el día de descanso al final de cada semana (después del domingo)
    if (dayName === "Sunday") {
      restsOnSaturday = !restsOnSaturday;
    }
  }

  return calendar;
};

export const PUTAccountAsignedCalendarRestDays = async (
  id: number,
  restDays: string
) => {
  console.log("PUTAccountAsignedCalendarRestDays", id, restDays);
  try {
    const user = await axios.get(`${API_URL}/accounts/${id}`, {
      headers: authHeader(),
    });
    const userActualCalendar = user.data.data.attributes.asignedCalendar;
    const updatedCalendar = await updateCalendarRestDays(
      userActualCalendar, restDays
    );

    const updateCalAxios = await axios.put(
      `${API_URL}/accounts/${id}`,
      { data: { asignedCalendar: updatedCalendar } },
      {
        headers: authHeader(),
      }
    );
    return updateCalAxios;
  } catch (err) {
    console.error("Error removing user from shift:", err);
  }
};

export const updateCalendarRestDays = async (
  calendar: Record<string, { work: boolean; startwork?: string; endwork?: string }>,
  newRestDay: string
) => {
  const today = moment(); // Fecha actual
  const newCalendar = { ...calendar }; // Clonamos el calendario existente

  Object.keys(newCalendar).forEach((date) => {
    const dayMoment = moment(date, "YYYY-MM-DD");
    if (dayMoment.isAfter(today)) {
      const dayName = dayMoment.format("dddd"); // Nombre del día
      const isRestDay = dayName === newRestDay;

      if (isRestDay) {
        // Convertir el día a descanso
        newCalendar[date] = { work: false };
      } else if (!newCalendar[date].work) {
        // Convertir días de descanso anteriores a días laborales
        newCalendar[date] = {
          work: true,
          startwork: "09:00:00 AM", // Horario predeterminado
          endwork: "06:00:00 PM",
        };
      }
    }
  });

  return newCalendar;
};

/* //////////////////////////////////////////////////////////////////////////////////////*/
/* ///////////////////////////////Calendario de Turnos//////////////////////////////////*/
/* //////////////////////////////////////////////////////////////////////////////////////*/

const warningManagers = async (
  logType: string,
  userData: UserAttributes,
  time: string,
  date: string
) => {
  // console.log("warningManagers", logType, userData, time, date);
  // Enviar correo si el usuario llega tarde

  const sendEmailReciever = await populateDepManagers(userData.id);
  const emails = sendEmailReciever.map((reciever) => reciever.email) || [];
  emails.push(userData.email);
  const plainEmails = emails.join(", ");

  const hasCalendar = userData.asignedCalendar;

  const simpleManual = `${userData.firstName} ${userData.lastName} is late for ${logType} at ${time} on ${date}`;
  const largeManual = `
    <p>Estimado(a) ${userData.firstName} ${userData.lastName},</p>
    <p>Lamentamos informarle que su registro <strong>${logType}</strong> no coincide con el horario asignado en nuestro sistema.</p>
    <p>Por favor contacte con su supervisor para la correspondiente aclaracion.</p>
    <p>Atentamente,</p>
    <p>El Equipo de Consumer Law</p>
  `;

  sendEmailFromRh({
    emailTo: plainEmails,
    subject: `${userData.firstName} is late`,
    body: {
      action: "personalized",
      manual: !hasCalendar ? simpleManual : largeManual,
    },
  });
};

/*
import { sendEmailFromRh } from "./proxy";
import axios from "axios";
import { authHeader } from '@app/services/auth'; // Ajusta la ruta de importación según sea necesario

const API_URL = "https://itback.consumerlaw.com/api";

class TimeService {

  async userTimeCheck(logType, logs, userData) {
    const time = this.getToday("time");
    let status = "OnTime";
    const logValues = Object.values(logs);
    const lastLog = logValues[logValues.length - 1];
    const lastLogTime = lastLog ? lastLog.setAt : null;

    if (logType === "startBreak" || logType === "startLunch") {
      status = "OnTime"; // Siempre OnTime para el comienzo del descanso
    } else if (logType === "endBreak") {
      const timeDiff = this.getTimeDifferenceInMinutes(time, lastLogTime);
      status = timeDiff <= 11 ? "OnTime" : "Late"; // OnTime si el tiempo es inferior a 11 minutos, Late de lo contrario
    } else if (logType === "endLunch") {
      const timeDiff = this.getTimeDifferenceInMinutes(time, lastLogTime);
      status = timeDiff <= 62 ? "OnTime" : "Late"; // OnTime si el tiempo es inferior a 62 minutos, Late de lo contrario
    } else if (logType === "startShift") {
      const shiftStartTime = this.parseTime(time);
      const shiftStartHour = shiftStartTime.getHours();
      const shiftStartMinutes = shiftStartTime.getMinutes();

      if (shiftStartHour < 9 || (shiftStartHour === 9 && shiftStartMinutes <= 2)) {
        status = "OnTime"; // OnTime si el tiempo es inferior a las 09:02:00
      } else if ((shiftStartHour === 9 && shiftStartMinutes > 2) || (shiftStartHour < 10) || (shiftStartHour === 10 && shiftStartMinutes <= 30)) {
        status = "Late"; // Late si el tiempo es entre las 09:02:01 y las 10:30:00
      } else if ((shiftStartHour === 10 && shiftStartMinutes > 30) || (shiftStartHour < 12) || (shiftStartHour === 12 && shiftStartMinutes <= 2)) {
        status = "OnTime"; // OnTime si el tiempo es entre las 10:30:01 y las 12:02:00
      } else if (shiftStartHour > 12 || (shiftStartHour === 12 && shiftStartMinutes > 2)) {
        status = "Late"; // Late si el tiempo es superior a las 12:02:00
      }
    }
    
    const sendEmailReciever = await this.populateDepManagers(userData.user.account.id);
    const emails = sendEmailReciever.map(reciever => reciever.email);

    // convert the array of emails into a single line string and add user email
    emails.push(userData.email);
    const plainEmails = emails.join(", ");

    // send email
    if (status === "Late" && userData.user.account.ignoreErrors !== true) {
      sendEmailFromRh({
        emailTo: plainEmails,
        subject: `${userData.user.account.firstName} is late`,
        body: {
          action: "late",
          logType: logType,
        }
      });
    }

    return status;
  }

  async populateDepManagers(uid){
    const filtersID = [76 , 78]
    // console.log("populateDepManagers", uid);
    const departments = await axios.get(`${API_URL}/accounts/${uid}?populate[departments]=*`, { headers: authHeader() });
    const departmentsIds = departments.data.data.attributes.departments.data.map(department => department.id);
    // console.log("departmentsIds", departmentsIds);

    // exclude departments with id 76 and 78
    const filteredDepartmentsIds = departmentsIds.filter(departmentId => !filtersID.includes(departmentId));
    // console.log("filteredDepartmentsIds", filteredDepartmentsIds);

    const departmentManagers = await Promise.all(
      filteredDepartmentsIds.map(async (departmentId) => {
        const managers = await axios.get(`${API_URL}/departments/${departmentId}?populate[managers]=*`, { headers: authHeader() });
        // console.log("managers", managers.data.data);

        const managersIds = managers.data.data.attributes.managers.data.map((managers) => {
          const id = managers.id;
          const email = managers.attributes.email;

          return { id, email };
        });

        return managersIds;
      })
    );

    // transform the array of arrays into a single array
    const departmentManagersFlat = departmentManagers.flat();
    // console.log("departmentManagersFlat", departmentManagersFlat);
    return departmentManagersFlat;
  }
}

export default new TimeService();
*/
