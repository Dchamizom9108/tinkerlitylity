import axios from "axios";

const API_URL = "https://itback.consumerlaw.com/api";

export const authHeader = () => {
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  if (user && user.jwt) {
    return { Authorization: 'Bearer ' + user.jwt };
  } else {
    return {};
  }
}

export const login = async (identifier: string, password: string) => {
  if (!identifier || !password) {
    throw new Error("Identifier and password are required");
  }

  try { 
    const response = await axios.post(`${API_URL}/auth/local`, {
      identifier,
      password
    });

    if (response.data.jwt) {
      localStorage.setItem("user", JSON.stringify(response.data));
    }
    
    return response
  } catch (error: any) {
    console.log('An error occurred:', error.response);
    return error.response
  }
}

export const saveAuthToken = (token: any) => {
  if (token) {
    return axios.get(`${API_URL}/auth/microsoft/callback?access_token=${token}`).then(res => {
      if (res.data.jwt) {
        localStorage.setItem("user", JSON.stringify(res.data));
      }
      return res
      // localStorage.setItem("user", JSON.stringify({jwt: token}))
    }).catch(err => {
      console.log(err)
      return err
    })
  }
}

export const logout = () => {
  localStorage.setItem("user", 'null')
  window.location.replace('/login');
}

