import axios from "axios";
import { authHeader } from "@app/services/auth"; // Ajusta la ruta de importación según sea necesario
import {
  generateCalendar,
  getMonthName,
  genCstmCalFixedMorningRotateWeek,
  getToday,
} from "@app/services/time"; // Ajusta la ruta de importación según sea necesario
import { months } from "moment";

const API_URL = "https://itback.consumerlaw.com/api";
const ipProxy = "https://api.ipify.org?format=json";

const filterManagers =
  "filters[$or][0][ignoreErrors][$ne]=true&filters[$or][1][ignoreErrors][$null]=true";

/* ////////////////////////////////////////////////////////// */
/* /////////////////////// Assistance /////////////////////// */
/* ////////////////////////////////////////////////////////// */

export const GETAssistance = (filter: string) => {
  return axios.get(
    `${API_URL}/assistances?${filter}populate[accounts][fields][0]=id`,
    { headers: authHeader() }
  );
};

export const GETassistances = async () => {
  const response = await axios.get(`${API_URL}/assistances`, {
    headers: authHeader(),
  });
  // console.log("response", response.data.data);
  const formattedData = response.data.data.map((assist: any) => {
    const date = assist.attributes.date;
    const id = assist.id;
    return { id, date };
  });
  return formattedData;
};

export const GETAssistanceUsersById = async (id: any) => {
  const response = await axios.get(
    `${API_URL}/assistances/${id}?populate[accounts][fields][0]=id&populate[accounts][fields][1]=firstName&populate[accounts][fields][2]=lastName&populate[accounts][fields][3]=email&populate[accounts][populate][0]=asistlogs`,
    { headers: authHeader() }
  );
  return response.data.data;
};

export const POSTAssistance = async (data: any) => {
  const config = {
    method: "post",
    url: `${API_URL}/assistances`,
    headers: {
      Authorization: `${authHeader().Authorization}`,
      "Content-Type": "application/json",
    },
    data: data,
  };

  return await axios(config);
};

export const PUTAssistanceAccounts = async (
  assistanceId: any,
  updatedAccounts: any
) => {
  return axios.put(
    `${API_URL}/assistances/${assistanceId}`,
    { data: { accounts: updatedAccounts } },
    { headers: authHeader() }
  );
};

export const getTotalDaysRegistered = async () => {
  const response = await axios.get(`${API_URL}/assistances`, {
    headers: authHeader(),
  });
  return response.data.meta.pagination.total;
};

/* ////////////////////////////////////////////////////////// */
/* /////////////////////// Assistance /////////////////////// */
/* ////////////////////////////////////////////////////////// */

/* //////////////////////////////////////////////////////////// */
/* /////////////////////// AsistLogs ///////////////////////// */
/* //////////////////////////////////////////////////////////// */

export const GETDayLog = async (id: any) => {
  return axios.get(`${API_URL}/asistlogs/${id}`, { headers: authHeader() });
};

export const POSTDayLog = async (data: any) => {
  const config = {
    method: "post",
    url: `${API_URL}/asistlogs`,
    headers: {
      Authorization: `${authHeader().Authorization}`,
      "Content-Type": "application/json",
    },
    data: data,
  };

  return await axios(config);
};

export const GETDayLogs = async (filter: number) => {
  return axios.get(`${API_URL}/asistlogs/${filter}`, { headers: authHeader() });
};

export const PUTDayLogs = async (id: any, data: any) => {
  try {
    const today = new Date().toISOString().split("T")[0];
    const month = getMonthName(today);
    const response = await axios.put(
      `${API_URL}/asistlogs/${id}`,
      { data },
      { headers: authHeader() }
    );
    if (response.status === 200) {
      if (data[month] && data[month][today]) {
        const logs = data[month][today];
        console.log("log", logs);
        // Filtrar logs relevantes
        const relevantLogs = Object.values(logs).filter((log: any) => {
          return log.status === "Late" || log.typeOfLog === "startShift" || log.typeOfLog === "endShift";
        });

            // Verificar si hay logs relevantes
        if (relevantLogs.length === 0) {
          console.log("No hay logs relevantes para agregar al calendario.");
          return;
        } else {
            // Obtener los datos del usuario
          const user = await GETMyselfUserData();
          console.log("user", user);

            // Validar si el usuario tiene un calendario asignado
          if (!user.asignedCalendar) {
            console.error("El usuario no tiene un calendario asignado.");
            return;
          } else {
            // Obtener el calendario actual
            const calendar = user.asignedCalendar;
            console.log("calendar", calendar);

            if (!calendar[today]) {
              calendar[today] = {};
            }

            // Agregar logs relevantes al calendario
            calendar[today].logs = relevantLogs;

            // Actualizar el calendario del usuario
    const addCalendar = await axios.put(
      `${API_URL}/accounts/${user.id}`,
      { data: { asignedCalendar: calendar } },
      {
        headers: authHeader(),
      }
    );

    if (addCalendar.status === 200) {
      console.log("Calendario actualizado correctamente.");
    } else {
      console.error("Error al actualizar el calendario.");
    }
          }
            
        }

      }
    }
    return response;
  } catch (error) {
    console.log(error);
  }
};

export const GETUserDayLogs = async (userId: any) => {
  const response = await axios.get(
    `${API_URL}/asistlogs?filters[accounts][id][$eq]=${userId}`,
    { headers: authHeader() }
  );
  return response.data.data;
};

export const getUsersDayLogsByManager = async (userId: number) => {
  try {
    const departmentsManagedTest = await axios.get(
      `${API_URL}/accounts/${userId}?populate[department_managers][populate][accounts][fields]=id,firstName,lastName,email,asignedCalendar&populate[department_managers][fields]=id,name`, 
      { headers: authHeader() }
    );
    
    const departmentManagers = departmentsManagedTest.data.data.attributes.department_managers.data.map((department : any) => ({
      id: department.id,
      name: department.attributes.name,
      accounts: department.attributes.accounts?.data.map((account : any) => ({
        id: account.id,
        firstName: account.attributes.firstName,
        lastName: account.attributes.lastName,
        email: account.attributes.email,
        asignedCalendar: account.attributes.asignedCalendar,
      })) || []
    }));

    const usersMapped = departmentManagers.map((user: any) => {
      const accounts = user.accounts.map((account: any) => {
        // Filtrar las fechas futuras en asignedCalendar
        const currentDate = new Date();
        const filteredCalendar: { [key: string]: any } = {};

        if (account.asignedCalendar) {
          Object.keys(account.asignedCalendar).forEach((date) => {
            const calendarDate = new Date(date);
            if (calendarDate <= currentDate) {
              filteredCalendar[date] = account.asignedCalendar[date];
            }
          });
        }

        return {
          id: account.id,
          firstName: account.firstName,
          lastName: account.lastName,
          email: account.email,
          name: `${account.firstName.split(" ")[0]} ${account.lastName.split(" ")[0]}`,
          asignedCalendar: filteredCalendar,
        };
      });

      if (accounts.includes(userId)) {
        return null;
      }
      return {
        accounts,
      };
    }).filter((user: any) => user !== null);

    const flatUsers = usersMapped.map((user: any) => user.accounts).flat();

    const uniqueUsers = flatUsers.filter((user: any, index: number) => {
      const isDuplicate =
        flatUsers.findIndex((u: any) => u.id === user.id) !== index;
      return !isDuplicate;
    }).sort((a: any, b: any) => a.id - b.id);

    return uniqueUsers;
  } catch (err) {
    console.error(err);
    if (axios.isAxiosError(err)) {
      return new Error(`Axios error: ${err.message}`);
    } else {
      return new Error("Unknown error occurred");
    }
  }
};

/* ////////////////////////////////////////////////////////// */
/* /////////////////////// AsistLogs /////////////////////// */
/* ////////////////////////////////////////////////////////// */

/*
  https://itback.consumerlaw.com/api/accounts?pagination[start]=0&pagination[limit]=10&sort=firstName:asc&filters[departments][name][$in]=OFFICE%20-%20MX&pagination[withCount]=true&populate[departments][populate][office_groups]=*&populate[departments][populate][sugar_teams]=*&populate[departments][populate][sugar_roles]=*
*/

/* /////////////////////////////////////////////////////// */
/* /////////////////////// Shifts //////////////////////// */
/* /////////////////////////////////////////////////////// */

// Servicio para obtener los turnos
export const GETShifts = () => {
  return axios.get(
    `${API_URL}/shifts?sort=name:asc&pagination[start]=0&pagination[limit]=200`,
    { headers: authHeader() }
  );
};

export const GETShiftsById = async (id: number) => {
  try {
    const response = await axios.get(
      `${API_URL}/shifts/${id}?populate[accounts]=*`,
      { headers: authHeader() }
    );
    const shift = response.data.data.attributes;
    return shift;
  } catch (error) {
    console.log(error);
  }
};

// Servicio para crear un nuevo turno
export const POSTShift = async (shiftData: any) => {
  const config = {
    method: "post",
    url: `${API_URL}/shifts`,
    headers: {
      Authorization: `${authHeader().Authorization}`,
      "Content-Type": "application/json",
    },
    data: shiftData,
  };

  return await axios(config);
};

// Servicio para editar un turno existente
export const PUTShift = async (shiftId: number, shiftData: any) => {
  return axios.put(`${API_URL}/shifts/${shiftId}`, shiftData, {
    headers: authHeader(),
  });
};

export const PUTShiftAccount = async (
  shiftId: number,
  shiftData: any,
  newUserId: number,
  action: string,
  timesheet: any
) => {
  try {
    const response = await axios.put(
      `${API_URL}/shifts/${shiftId}`,
      { data: { accounts: shiftData } },
      {
        headers: authHeader(),
      }
    );
    const updateResponse = await updateUserCalendar(
      newUserId,
      shiftId,
      action,
      timesheet
    );
    return updateResponse;
  } catch (error) {
    console.log(error);
  }
};

export const updateUserCalendar = async (
  id: any,
  shiftId: number,
  action: string,
  timesheet: any
) => {
  try {
    const userResponse = await axios.get(`${API_URL}/accounts/${id}`, {
      headers: authHeader(),
    });

    const asignedCalendar = userResponse.data.data.attributes.asignedCalendar;

    if (action === "add") {
      const shiftData = await GETShiftsById(shiftId);
      if (shiftId === 35) { //custom calendar
        // custom Calendars
        const calendar = await genCstmCalFixedMorningRotateWeek();
        const addCalendar = await axios.put(
          `${API_URL}/accounts/${id}`,
          { data: { asignedCalendar: calendar } },
          {
            headers: authHeader(),
          }
        );
        console.log("addCalendar", calendar);
        return addCalendar;
      }

      let calendar = await generateCalendar(shiftData, timesheet);

      if (asignedCalendar) {
        const mergedCalendar = { ...asignedCalendar, ...calendar };
        calendar = mergedCalendar;
      }

      console.log("calendar", calendar);

      const addCalendar = await axios.put(
        `${API_URL}/accounts/${id}`,
        { data: { asignedCalendar: calendar } },
        {
          headers: authHeader(),
        }
      );

      return addCalendar;
    } else if (action === "remove") {
      try {

        if (!asignedCalendar) {
          console.log("No calendar assigned.");
          return;
        }
    
        // Obtener la fecha actual
        const today = new Date().toISOString().split("T")[0];
    
        // Filtrar el calendario eliminando las entradas desde hoy en adelante
        const updatedCalendar = Object.fromEntries(
          Object.entries(asignedCalendar).filter(([date]) => date < today)
        );

        console.log("updatedCalendar", updatedCalendar);
    
        // Actualizar el calendario en la base de datos
        const response = await axios.put(
          `${API_URL}/accounts/${id}`,
          { data: { asignedCalendar: updatedCalendar } },
          {
            headers: authHeader(),
          }
        );
    
        console.log("Calendar updated:", updatedCalendar);
        return response;
      } catch (error) {
        console.error("Error removing future calendar entries:", error);
      }
    }
    
  } catch (error) {
    console.log(error);
  }
};

export const GETUserSimpleDataById = async (id: any) => {
  try {
    const response = await axios.get(`${API_URL}/accounts/${id}`, {
      headers: authHeader(),
    });
    const user = response.data.data.attributes;
    user.id = response.data.data.id;
    return user;
  } catch (error) {
    console.log(error);
  }
};

// Servicio para eliminar un turno
export const DELETEShift = (shiftId: number) => {
  return axios.delete(`${API_URL}/shifts/${shiftId}`, {
    headers: authHeader(),
  });
};

/* /////////////////////////////////////////////////////// */
/* /////////////////////// Shifts /////////////////////// */
/* /////////////////////////////////////////////////////// */

/* /////////////////////////////////////////////////////////// */
/* /////////////////////// Departments /////////////////////// */
/* /////////////////////////////////////////////////////////// */

export const returnDepartmentManager = async (
  email: string
): Promise<number[]> => {
  try {
    // Realizar la solicitud para obtener todos los departamentos y sus managers
    const response = await axios.get(
      `${API_URL}/departments?populate[managers]=*`,
      { headers: authHeader() }
    );

    const departments = response.data.data;

    // Filtrar los departamentos donde el email coincide con alguno de los managers
    const matchingDepartments = departments.filter((department: any) =>
      department.attributes.managers.data.some(
        (manager: any) => manager.attributes.email === email
      )
    );

    // Obtener los IDs de los departamentos coincidentes
    const departmentIds = matchingDepartments.map(
      (department: any) => department.id
    );

    return departmentIds;
  } catch (error) {
    console.error("Error fetching departments:", error);
    return [];
  }
};

export const getUsersFromDepartments = async (departments: number[]) => {
  try {
    const allUsers: Map<number, any> = new Map();

    // Iterar sobre los departamentos y obtener usuarios
    for (const department of departments) {
      const response = await axios.get(
        `${API_URL}/accounts?${filterManagers}&filters[departments][id][$eq]=${department}`,
        { headers: authHeader() }
      );
      const users = response.data.data;
      const departmentName = await GETDepartmentName(department);

      // Transformar y agregar usuarios al Map
      users.forEach((user: any) => {
        const userAttributes = user.attributes;
        const userId = user.id;
        const firstName = userAttributes.firstName;
        const lastName = userAttributes.lastName;
        const email = userAttributes.email;
        const department = departmentName;

        // Si ya existe un usuario con este ID, no lo sobrescribas
        if (!allUsers.has(userId)) {
          allUsers.set(userId, {
            userId,
            firstName,
            lastName,
            email,
            department,
          });
        }
      });
    }

    // Convertir el Map a un array
    return Array.from(allUsers.values());
  } catch (error) {
    console.error("Error fetching users from departments: ", error);
    return [];
  }
};

export const GETDepartmentName = async (id: number) => {
  try {
    const response = await axios.get(`${API_URL}/departments/${id}`, {
      headers: authHeader(),
    });
    return response.data.data.attributes.name;
  } catch (error) {
    console.error(`Error fetching department name for ID ${id}: `, error);
    return `Desconocido`;
  }
};

/* /////////////////////////////////////////////////////////// */
/* /////////////////////// Departments /////////////////////// */
/* /////////////////////////////////////////////////////////// */

/* ///////////////////////////////////////////////////////// */
/* /////////////////////// Functions /////////////////////// */
/* ///////////////////////////////////////////////////////// */

export const fetchIp = async () => {
  try {
    const response = await axios.get(ipProxy);
    return response.data.ip;
  } catch (error) {
    console.log("Error fetching IP: ", error);
  }
};

/* ///////////////////////////////////////////////////////// */
/* /////////////////////// Functions /////////////////////// */
/* ///////////////////////////////////////////////////////// */

export async function GETMyselfUserData () {
  try {
    const userData = await axios.get(`${API_URL}/users/me?populate=role`, {
      headers: authHeader(),
    });

    const accountId = await axios.get(
      `${API_URL}/accounts?filters[email][$eq]=${userData.data.email}`,
      {
        headers: authHeader(),
      }
    );

    let user = accountId.data.data[0].attributes;
    user.id = accountId.data.data[0].id;
    delete user.o365Data;
    delete user.tcxData;
    delete user.sugarData;

    return user;
  } catch (error) {
    console.log(error);
  }
};
