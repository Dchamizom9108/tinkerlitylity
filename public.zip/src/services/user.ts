import axios, { AxiosResponse, CancelTokenSource } from "axios";
import { authHeader } from "@app/services/auth"; // Ajusta la ruta de importación según sea necesario

import { UserAttributes } from "@app/types";

const API_URL = "https://itback.consumerlaw.com/api";
const secureProxyAPI = "https://bots.consumerlaw.com/api";

interface Order {
  column: string;
  direction: string;
}

interface NotificationAttributes {
  // Define aquí los atributos de la notificación que esperas recibir
}

interface UserData {
  id: number;
  attributes: UserAttributes;
}

interface DepartmentData {
  department: any;
  attributes: any;
}

interface APIResponseMeta {
  pagination: {
    total: number;
  };
}

interface UsersResponse {
  data: UserData[];
  meta: APIResponseMeta;
}

interface DepartmentsResponse {
  data: DepartmentData[];
}

interface GetUsersResult {
  data: UserAttributes[];
  departments: DepartmentData[];
  count: number;
}

interface getNotificationsResult {
  data: NotificationAttributes[];
}

export const getUsers = async (
  pagination: { pageSize: number; pageIndex: number },
  filter: string,
  order: Order
): Promise<GetUsersResult | Error> => {
  const ourRequest: CancelTokenSource = axios.CancelToken.source();

  if (pagination === undefined || filter === undefined || order === undefined) {
    ourRequest.cancel();
    return new Error("Missing parameters");
  }

  const orderBy = order
    ? `${order.column}:${order.direction}`
    : "firstName:asc";

  try {
    const accountsURL = `${API_URL}/accounts?pagination[start]=${pagination.pageSize * (pagination.pageIndex - 1)}&pagination[limit]=${pagination.pageSize}&sort=${orderBy}${filter}&pagination[withCount]=true&populate[departments][populate][office_groups]=*&populate[departments][populate][sugar_teams]=*&populate[departments][populate][sugar_roles]=*`;
    const departmentsURL = `${API_URL}/departments?pagination[start]=0&pagination[limit]=200`;

    const [userDataResponse, departmentsDataResponse]: [
      AxiosResponse<UsersResponse>,
      AxiosResponse<DepartmentsResponse>,
    ] = await Promise.all([
      axios.get(accountsURL, {
        headers: authHeader(),
        cancelToken: ourRequest.token,
      }),
      axios.get(departmentsURL, {
        headers: authHeader(),
        cancelToken: ourRequest.token,
      }),
    ]);

    const workData = userDataResponse.data.data;
    const exportData = workData.map((el: UserData) => {
      const id = el.id;
      return {
        ...el.attributes,
        id,
      };
    });

    return {
      data: exportData,
      departments: departmentsDataResponse.data.data,
      count: userDataResponse.data.meta.pagination.total,
    };
  } catch (err) {
    console.error(err);
    if (axios.isAxiosError(err)) {
      return new Error(`Axios error: ${err.message}`);
    } else {
      return new Error("Unknown error occurred");
    }
  }
};

export const getUser = () => {
  return axios.get(`${API_URL}/users/me?populate=role`, {
    headers: authHeader(),
  });
};

export const getUserDetail = (id: any) => {
  return axios.get(
    `${API_URL}/accounts/${id}?&populate[departments][populate][office_groups]=*&populate[departments][populate][sugar_teams]=*&populate[departments][populate][sugar_roles]=*`,
    { headers: authHeader() }
  );
};

export const getAccountId = async (email: string) => {
  try {
    const response = await axios.get(
      `${API_URL}/accounts?filters[email][$eq]=${email}`,
      {
        headers: authHeader(),
      }
    );
    return response.data.data[0].id;
  } catch (error) {
    console.log(error);
    return null;
  }
};

export const syncData = async () => {
  try {
    await axios.get(`${API_URL}/office-sync-groups`, { headers: authHeader() });
    console.log("office groups");
    await axios.get(`${API_URL}/office-sync-users`, { headers: authHeader() });
    console.log("office done");
    await axios.get(`${API_URL}/sugar-sync-teams`, { headers: authHeader() });
    console.log("sugar teams and roles done");
    await axios.get(`${API_URL}/sugar-sync-users`, { headers: authHeader() });
    console.log("sugar users done");
    await axios.get(`${API_URL}/tcx-sync-users`, { headers: authHeader() });
    console.log("3cx users done");
    return;
  } catch (error) {
    console.log(error);
  }
};

export const syncDataOne = async (id: any, sugarId: any) => {
  try {
    await axios.get(
      `https://itback.consumerlaw.com/api/office-sync-one?user=${id}`,
      { headers: authHeader() }
    );
    console.log("office done");
    await axios.get(
      `https://itback.consumerlaw.com/api/sugar-sync-users?user=${sugarId}`,
      { headers: authHeader() }
    );
    console.log("sugar users done");
    await axios.get("https://itback.consumerlaw.com/api/tcx-sync-users", {
      headers: authHeader(),
    });
    console.log("3cx users done");
    return;
  } catch (error) {
    console.log(error);
    return error;
  }
};

export const getUserPic = async (id: string): Promise<string> => {
  try {
    const token = await axios.get(
      `https://itback.consumerlaw.com/api/office-sync-get-token`,
      { headers: authHeader() }
    );

    const config = {
      method: "get",
      url: `https://graph.microsoft.com/beta/users/${id}/photo/$value`,
      headers: {
        Authorization: `Bearer ${token.data.accessToken}`,
      },
      responseType: "arraybuffer" as const,
    };

    const basePic = await axios(config);

    // Convertir ArrayBuffer a cadena base64
    const base64String = btoa(
      new Uint8Array(basePic.data).reduce(
        (data, byte) => data + String.fromCharCode(byte),
        ""
      )
    );

    return `data:image/jpeg;base64,${base64String}`;
  } catch (error) {
    console.log(error);
    return "error";
  }
};

export const createUser = async (data: any) => {
  const checkEmail = async (email: string) => {
    return axios.get(`${API_URL}/accounts?filters[email][$eq]=${email}`, {
      headers: authHeader(),
    });
  };

  const userExists = await checkEmail(data.email);
  if (userExists.data.data.length > 0) {
    return "userExist";
  } else {
    const formatData = { data: data };
    console.log(formatData);

    let config = {
      method: "post",
      url: `${API_URL}/accounts`,
      headers: {
        Authorization: `${authHeader().Authorization}`,
        "Content-Type": "application/json",
      },
      data: {
        data: {
          firstName: formatData.data.firstName,
          lastName: formatData.data.lastName,
          email: formatData.data.email,
          username: formatData.data.email,
          accountsPassword: formatData.data.accountsPassword,
          jobTitle: formatData.data.jobTitle,
          notes: formatData.data.notes,
          createdBy: formatData.data.createdBy,
          startDate: formatData.data.startDate,
          departments: formatData.data.departments,
        },
      },
    };

    const apiResponse = await axios(config);
    if (apiResponse.status === 200) {
      const emailData = {
        whoSendModification: formatData.data.createdBy,
        firstName: formatData.data.firstName,
        lastName: formatData.data.lastName,
        strappiUserId: apiResponse.data.data.id,
        jobTitle: formatData.data.jobTitle,
        notes: formatData.data.notes,
        effectiveDate: formatData.data.startDate,
        departments: {},
        actionToExecute: "Create",
      };

      axios.post(`${secureProxyAPI}/sendEmail`, emailData).then((response) => {
        return response;
      });
    } else {
      return "error";
    }
  }
};

export const disableExtension = async (email: string) => {
  return await axios.get(
    // `${API_URL}/tcx-disable-users?ext=${ext}&jobTitle=${jobTitle}`,
    `${API_URL}/tcx-disable-user?email=${email}`,
    { headers: authHeader() }
  );
};

export const deleteExtension = async (email: string) => {
  return await axios.get(`${API_URL}/tcx-delete-user?email=${email}`, {
    headers: authHeader(),
  });
};

// async deleteExtension(jobTitle, ext) {
//   return await axios.get(
//     `${API_URL}/tcx-delete-users?ext=${ext}&jobTitle=${jobTitle}`,
//     { headers: authHeader() }
//   );
// }

export const createPassword = (username: string) => {
  // Separar el nombre de usuario en partes
  const parts = username.split(".");
  if (parts.length < 2) {
    throw new Error("El nombre de usuario debe contener un punto.");
  }

  // Tomar las iniciales de las partes del nombre de usuario
  const initials = parts
    .map((part) => part[0])
    .join("")
    .toUpperCase();

  // Crear la base de la contraseña
  let password = initials + username.slice(1, 4) + username.slice(-2);

  // Añadir números y caracteres especiales
  const numbers = "0123456789";
  const specialCharacters = "!.$";
  const characters = numbers + specialCharacters;

  const addRandomCharacter = (charSet: any) => {
    // Función para añadir un carácter aleatorio de un conjunto dado
    return charSet.charAt(Math.floor(Math.random() * charSet.length));
  };

  // Asegurarse de tener al menos un número y un carácter especial
  password += addRandomCharacter(numbers);
  password += addRandomCharacter(specialCharacters);

  // Añadir caracteres aleatorios hasta alcanzar la longitud deseada
  while (password.length < 12) {
    password += addRandomCharacter(characters);
  }

  // Limitar la longitud de la contraseña a un máximo de 12 caracteres
  if (password.length > 12) {
    password = password.slice(0, 12);
  }

  return password;
};

export const getUniversities = async (
  pageSize: number,
  pageIndex: number,
  filter: string,
  order: Order,
  department: string
) => {
  let orderBy = order ? `${order.column}:${order.direction}` : "name:asc";
  return await axios.get(
    `${API_URL}/universities?pagination[page]=${pageIndex}&pagination[pageSize]=${pageSize}&sort[0]=${orderBy}${filter}&filters[Department][$eq]=${department}`,
    { headers: authHeader() }
  );
};

export const createUniversity = async (data: any) => {
  console.log(data);
  const config = {
    method: "post",
    url: "https://itback.consumerlaw.com/api/universities",
    headers: {
      Authorization: `${authHeader().Authorization}`,
      "Content-Type": "application/json",
    },
    data: data,
  };

  return await axios(config);
};

export const getUserByTcxExt = async (userExt: string) => {
  return await axios.get(
    `${API_URL}/accounts?filters[tcxExtension][$eq]=${userExt}`,
    { headers: authHeader() }
  );
};

export const getSugarTeams = async () => {
  return await axios.get(`${API_URL}/sugar-teams`, { headers: authHeader() });
};


/* ///////////////////////////////////////////////////////////////////*/
/*////////////////////////// DEPARTMENTS /////////////////////////////////*/
/*//////////////////////////////////////////////////////////////////////*/

export const getUsersByManager = async (userId: number) => {
  try {
    const departmentsManagedTest = await axios.get(
      `${API_URL}/accounts/${userId}?populate[department_managers][populate][accounts][fields]=id,firstName,lastName,email,asignedCalendar&populate[department_managers][fields]=id,name`, 
      { headers: authHeader() }
    );
    
    const departmentManagers = departmentsManagedTest.data.data.attributes.department_managers.data.map((department : any) => ({
      id: department.id,
      name: department.attributes.name,
      accounts: department.attributes.accounts?.data.map((account : any) => ({
        id: account.id,
        firstName: account.attributes.firstName,
        lastName: account.attributes.lastName,
        email: account.attributes.email,
        asignedCalendar: account.attributes.asignedCalendar,
      })) || []
    }));

    // Filter only users in Mexico (department ID 78)
    const usersMapped = departmentManagers.map((user: any) => {
      const accounts = user.accounts.map((account: any) => {
        return {
          id: account.id,
          firstName: account.firstName,
          lastName: account.lastName,
          email: account.email,
          name: `${account.firstName.split(" ")[0]} ${account.lastName.split(" ")[0]}`,
          asignedCalendar: account.asignedCalendar,
        };
      });
      if (accounts.includes(userId)) {
        return null;
      }
      return {
        accounts,
      };
    });
    const flatUsers = usersMapped.map((user: any) => user.accounts).flat();

    const uniqueUsers = flatUsers.filter((user: any, index: number) => {
      const isDuplicate =
        flatUsers.findIndex((u: any) => u.id === user.id) !== index;
      return !isDuplicate;
    });

    return uniqueUsers;
  } catch (err) {
    console.error(err);
    if (axios.isAxiosError(err)) {
      return new Error(`Axios error: ${err.message}`);
    } else {
      return new Error("Unknown error occurred");
    }
  }
};

export const getDepartments = () => {
  return axios.get(
    `${API_URL}/departments?sort=name:asc&pagination[start]=0&pagination[limit]=200&populate[accounts]=*&populate[managers]=*`,
    { headers: authHeader() }
  );
};

export const getDepartmentsNames = () => {
  return axios.get(`${API_URL}/departments?sort=name:asc&pagination[start]=0&pagination[limit]=200`, {
    headers: authHeader(),
  });
}

export const GETDepartment = (name : string) => {
  return axios.get(
    `${API_URL}/departments?filters[name][$eq]=${name}&populate[accounts]=*&populate[managers]=*`,
    { headers: authHeader() }
  );
};

export const GETDepartmentById = (id: number) => {
  return axios.get(
    `${API_URL}/departments/${id}?populate[accounts]=*&populate[managers]=*`,
    { headers: authHeader() }
  );
};

export const PUTDepartmentAccount = (depId: number, depData: any) => {
  return axios.put(
    `${API_URL}/departments/${depId}`,
    { data: { accounts: depData } },
    {
      headers: authHeader(),
    }
  );
};

export const GETDepartmentCalendar = (depId: number) => {
  return axios.get(
    `${API_URL}/departments/${depId}?populate[accounts]=*`,
    { headers: authHeader() }
  );
}
/*//////////////////////////////////////////////////////////////////////*/
/*////////////////////////// NOTIFICATIONS /////////////////////////////////*/
/*//////////////////////////////////////////////////////////////////////*/

export const getNotifications = async (
  pageSize: number,
  pageIndex: number,
  filter: string,
  order: Order
): Promise<getNotificationsResult | Error> => {
  let orderBy = order ? `${order.column}:${order.direction}` : "subject:asc";
  return await axios.get(
    `${API_URL}/notifications?pagination[page]=${pageIndex}&pagination[pageSize]=${pageSize}&populate[users]=*&populate[users_completed]=*&sort[0]=${orderBy}${filter}`,
    { headers: authHeader() }
  );
};

export const getAllNotifications = async ( ): Promise<getNotificationsResult | Error> => {
  return await axios.get(
    `${API_URL}/notifications?populate[users]=*&populate[users_completed]=*`,
    { headers: authHeader() }
  );
};

export const getNotificationsDetails = async(id : number) => {
  return axios.get(
    `${API_URL}/notifications/${id}?&populate[users]=*&populate[users_completed]=*`,
    { headers: authHeader() }
  );
}

export const getDataFromPerformance = async(date: string) => {
  return axios.get(
      `${API_URL}/performances?filters[date]=${date}`, 
      { headers: authHeader() }
    );
}

/*//////////////////////////////////////////////////////////////////////*/
/*////////////////////////// NOTIFICATIONS /////////////////////////////////*/
/*//////////////////////////////////////////////////////////////////////*/

/*

  async createNotification(data) {
    //Get users for the department
    let filter = "";
    data.data.departments.map((dep, i) => {
      filter = `${filter}&filters[departments][id][$in][${i}]=${dep}`;
      return null;
    });
    let users = await axios.get(
      `${API_URL}/users?start=0&limit=10000${filter}`,
      { headers: authHeader() }
    );
    users = await users.data.map((user) => user.id);

    data.data.users = users;

    let config = {
      method: "post",
      url: "https://itback.consumerlaw.com/api/notifications",
      headers: {
        Authorization: `${authHeader().Authorization}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(config);
  }

  async getUserNotifications(userId) {
    // console.log(userId)
    return await axios.get(
      `https://itback.consumerlaw.com/api/user-notifications?users=${userId}`,
      { headers: authHeader() }
    );
  }

  async completeUserNotification(notificationId, userId) {
    const notification = await axios.get(
      `${API_URL}/notifications/${notificationId}?populate[users_completed]=id`,
      { headers: authHeader() }
    );
    const userCompleted =
      notification.data.data.attributes.users_completed?.data.map(
        (user) => user.id
      );
    userCompleted.push(userId);
    let config = {
      method: "put",
      url: `https://itback.consumerlaw.com/api/notifications/${notificationId}`,
      headers: {
        Authorization: `${authHeader().Authorization}`,
        "Content-Type": "application/json",
      },
      data: { data: { users_completed: userCompleted } },
    };

    return await axios(config);
  }

  async getUniversities(pageSize, pageIndex, filter, order, department) {
    let orderBy = order ? `${order.column}:${order.direction}` : "name:asc";
    return await axios.get(
      `${API_URL}/universities?pagination[page]=${pageIndex}&pagination[pageSize]=${pageSize}&sort[0]=${orderBy}${filter}&filters[Department][$eq]=${department}`,
      { headers: authHeader() }
    );
  }

  async createUniversity(data) {
    console.log(data)
    const config = {
      method: "post",
      url: "https://itback.consumerlaw.com/api/universities",
      headers: {
        Authorization: `${authHeader().Authorization}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(config);
  }

  

  async getUserSales(url) {
    return await axios
      .post(
        "https://node.consumerlaw.com/proxy",
        {
          parameters: {},
          url: `${url}`,
        },
        {
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
        }
      )
      .then((response) => response.data)
      .catch((error) => {
        throw new Error(`Error fetching data from ${url}. ${error.message}`);
      });
  }
}

export default new UserService();

*/
