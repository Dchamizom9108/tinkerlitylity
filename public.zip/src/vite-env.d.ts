/// <reference types="vite/client" />
/// <reference types="vite-plugin-comlink/client" />
