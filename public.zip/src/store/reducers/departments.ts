import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { getDepartments } from '@app/services/user'; // Asegúrate de importar tu función de API

export interface Department {
  id: number;
  name: string;
}

interface DepartmentsState {
  find(arg0: (d: any) => boolean): unknown;
  departments: Department[];
  lastUpdated: number | null;
  status: 'idle' | 'loading' | 'failed';
}

const initialState: DepartmentsState = {
  departments: [],
  lastUpdated: null,
  status: 'idle',
  find: (d) => d,
};

export const fetchDepartments = createAsyncThunk(
  'departments/fetchDepartments',
  async () => {
    const response = await getDepartments();
    return response.data.data.map((dep: any) => ({
      id: dep.id,
      name: dep.attributes.name,
    }));
  }
);

const departmentsSlice = createSlice({
  name: 'departments',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchDepartments.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchDepartments.fulfilled, (state, action) => {
        state.departments = action.payload;
        state.lastUpdated = Date.now();
        state.status = 'idle';
      })
      .addCase(fetchDepartments.rejected, (state) => {
        state.status = 'failed';
      });
  },
});

export default departmentsSlice.reducer;
