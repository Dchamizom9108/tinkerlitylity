import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface AuthState {
  currentUser: Record<string, any> | null;
}

const initialState: AuthState = {
  currentUser: JSON.parse(localStorage.getItem('user') || 'null'),
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setCurrentUser: (
      state: AuthState,
      { payload }: PayloadAction<Record<string, any> | null>
    ) => {
      state.currentUser = payload;
      if (payload) {
        localStorage.setItem('user', JSON.stringify(payload));
      } else {
        localStorage.removeItem('user');
      }
    },
  },
});

export const { setCurrentUser } = authSlice.actions;

export default authSlice.reducer;
