import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface HeaderNavItem {
  url: string;
  text: string;
}

interface HeaderNavState {
  items: HeaderNavItem[];
}

const initialState: HeaderNavState = {
  items: [], // Especificamos que será un array de HeaderNavItem
};

const headerReducer = createSlice({
  name: 'header',
  initialState,
  reducers: {
    setHeaderNavItems: (state, action: PayloadAction<HeaderNavItem[] | HeaderNavItem>) => {
      // Si el payload es un array, lo asignamos directamente; si no, lo envolvemos en un array
      state.items = Array.isArray(action.payload) ? action.payload : [action.payload];
    },
  },
});

export const { setHeaderNavItems } = headerReducer.actions;
export default headerReducer.reducer;
