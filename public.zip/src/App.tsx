import { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Main from "@modules/main/Main";
import Login from "@modules/login/Login";
import { useWindowSize } from "@app/hooks/useWindowSize";
import { calculateWindowSize } from "@app/utils/helpers";
import { setWindowSize } from "@app/store/reducers/ui";
import ReactGA from "react-ga4";

import PublicRoute from "./routes/PublicRoute";
import PrivateRoute from "./routes/PrivateRoute";

import { useAppDispatch, useAppSelector } from "./store/store";

import Dashboard from "@pages/Dashboard";
import Blank from "@pages/Blank";
import SubMenu from "@pages/SubMenu";

/* Users */
import Profile from "@pages/profile/Profile";
import UsersList from "@pages/users/UsersList";
import UserCreate from "@pages/users/UserCreate";
import DepartmentDetail from "./pages/users/DepartmentDetail";
import PrintData from "@pages/PrintData";
/* /Users */

/* RH */
import SetAssistance from "@pages/rh/setAssistance";
import RhDashboard from "@pages/rh/RhDashboard";
import AssistanceList from "@pages/rh/AssistanceList";
import ShiftsPortal from "./pages/rh/Shifts";
import ShiftDetails from "./pages/rh/ShiftDetails";
import DepCalendar from "./pages/rh/DepCalendar";
/* /RH */

/* UNIVERSITIES */
import UniversityCreate from "@pages/university/universityCreate";
import UniversityListLegal from "@pages/university/univesity-list-legal";
import UniversityListLegalDocs from "@pages/university/university-list-legal-docs";
import UniversityListLegalVideos from "@pages/university/university-list-legal-videos";
import UniversityListSales from "@pages/university/university-list-sales";
/* END UNIVERSITIES */

/* REPORTS */
// import SalesQ from "@pages/reports/salesQ";
import OrgList from "./pages/org/OrgList";
import Wallboard from "./pages/reports/wallboard";
import TcxReport from "./pages/reports/tcx/TcxReport";
import SalesTv from "./modules/tv/salesTv";
/* END REPORTS */

const { VITE_NODE_ENV } = import.meta.env;

const App = () => {
  const windowSize = useWindowSize();
  const screenSize = useAppSelector((state) => state.ui.screenSize);
  const dispatch = useAppDispatch();
  const location = useLocation();

  useEffect(() => {
    const size = calculateWindowSize(windowSize.width);
    if (screenSize !== size) {
      dispatch(setWindowSize(size));
    }
  }, [windowSize, dispatch, screenSize]);

  useEffect(() => {
    if (location && location.pathname && VITE_NODE_ENV === "production") {
      ReactGA.send({
        hitType: "pageview",
        page: location.pathname,
      });
    }
  }, [location]);

  return (
    <>
      <Routes>
        <Route path="/print/:id" element={<PrintData />} />
        <Route path="/tv/salesTvReport" element={<SalesTv />} />
        <Route path="/login" element={<PublicRoute />}>
          <Route path="/login" element={<Login />} />
        </Route>


        <Route path="/" element={<PrivateRoute />}>
          <Route path="/" element={<Main />}>
            <Route path="/sub-menu-2" element={<Blank />} />
            <Route path="/sub-menu-1" element={<SubMenu />} />
            <Route path="/blank" element={<Blank />} />

            <Route path="/" element={<Dashboard />} />

            <Route path="/users/:id" element={<Profile />} />
            <Route path="/users" element={<UsersList />} />
            <Route path="/users/create" element={<UserCreate />} />
            <Route path="/departments/:name" element={<DepartmentDetail />} />
            

            {/* RH Services */}
            {/* <Route path="/rh/set-log" element={<SetLog />} /> */}
            <Route path="/set-assistance" element={<SetAssistance />} />
            {/* <Route path="/assistance/timer/:timerValue" element={<Timer />} /> */}
            <Route path="/rh/dashboard" element={<RhDashboard />} />
            <Route path="/rh/assistance/list" element={<AssistanceList />} />
            <Route path="/rh/shifts" element={<ShiftsPortal />} />
            <Route path="/rh/shifts/:id" element={<ShiftDetails />} />
            <Route path="/rh/calendar/department" element={<DepCalendar />} />
            {/* END RH Services */}

            {/* UNIVERSITIES */}
            <Route path="/uLlDoc" element={<UniversityListLegalDocs />} />
            <Route path="/uLlVideo" element={<UniversityListLegalVideos />} />
            <Route path="/university/create" element={<UniversityCreate />} />
            <Route path="/university-legal" element={<UniversityListLegal />} />
            <Route path="/university-sales" element={<UniversityListSales />} />
            {/* END UNIVERSITIES */}
            {/* <Route path="/sales-q/status" element={<SalesQ />} /> */}
            {/* REPORTS */}
            <Route path="/reports/wallboard" element={<Wallboard />} />
            <Route path="/reports/tcx-report" element={<TcxReport />} />
            {/* END REPORTS */}
            {/* ORG */}
            <Route path="/org" element={<OrgList />} />
            {/* END ORG */}
          </Route>
        </Route>
      </Routes>
    </>
  );
};

export default App;
