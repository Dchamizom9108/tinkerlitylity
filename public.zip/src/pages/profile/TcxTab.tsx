import { useEffect, useState } from 'react';
import { useParams } from "react-router-dom";
import { getUserDetail } from '@app/services/user';

interface tcxData {
  Number: string;
  DID: string;
  OutboundCallerID: string;
}

const TcxTab = ({ isActive }: { isActive: boolean }) => {
  const { id } = useParams();
  const [tcxData, setTcxData] = useState<tcxData | null>(null);
  const [load, setLoad] = useState(false);

  useEffect(() => {
    const getUserData = async (uId: any) => {
      try {
        const response = await getUserDetail(uId);

        let data = response.data.data.attributes;

        const tcxData: tcxData = {
          Number: data.tcxData.Number,
          DID: data.tcxData.DID,
          OutboundCallerID: data.tcxData.OutboundCallerID,
        }

        setTcxData(tcxData)
        return response;
      } catch (error) {
        console.log(error);
        return error;
      }
    };

    if (!load && isActive) {
      getUserData(id).then((res) => {
        setLoad(true);
      });
    }
  }, [id, load, isActive]);

  return (
    <div className={`tab-pane ${isActive ? 'active' : ''}`}>
    <div className="row">
        <div className="row d-flex col-sm-6 pr-3">
            <div className="col-5 text-bold label">Extension: <i className="fas fa-check-circle text-sm text-success"></i></div>
            <div className="col-7 ml-auto">{tcxData?.Number}</div>
        </div>

        <div className="row d-flex col-sm-6 pr-3">
            <div className="col-5 text-bold label"></div>
            <div className="col-7 ml-auto"></div>
        </div>
    </div>
    <div className="row mt-4">
        <div className="row d-flex col-sm-6 pr-3">
            <div className="col-5 text-bold label">Direct Line: <i className="fas fa-check-circle text-sm text-success"></i></div>
            <div className="col-7 ml-auto">{tcxData?.DID}</div>
        </div>

        <div className="row d-flex col-sm-6 pr-3">
            <div className="col-5 text-bold label">Outbound CID: <i className="fas fa-check-circle text-sm text-success"></i></div>
            <div className="col-7 ml-auto">{tcxData?.OutboundCallerID}</div>
        </div>
    </div> 
    </div>
  )
}

export default TcxTab