import { useEffect, useState } from 'react';
import { useParams } from "react-router-dom";
import { getUserDetail } from '@app/services/user';
import { GroupsTable } from '@app/components';

import { useAppSelector } from "@app/store/store";

interface OfficeGroup {
  displayName: string;
  mail: string;
}

interface OfficeTemplateGroup {
  attributes: {
    name: string;
    email: string;
  };
}

interface OfficeTemplate {
  attributes: {
    office_groups: {
      data: OfficeTemplateGroup[];
    };
  };
}

interface OfficeData {
  office: {
    id: string;
    memberOf: OfficeGroup[];
  } | null;
  template: {
    data: OfficeTemplate[];
  };
}

const OfficeTab = ({ isActive }: { isActive: boolean }) => {
  const currentUser = useAppSelector((state) => state.auth.currentUser);
  const { id } = useParams();
  const [officeData, setOfficeData] = useState<OfficeData | null>(null);
  const [load, setLoad] = useState(false);
  const username = currentUser?.user?.email?.split("@")[0];

  useEffect(() => {
    const userId = id || currentUser?.user?.id;
    const getUserData = async (uId: string) => {
      try {
        const response = await getUserDetail(uId);

        let data = response.data.data.attributes;

        const officeData: OfficeData = {
          office: data.o365Data,
          template: data.departments,
        };
        setOfficeData(officeData);
        return response;
      } catch (error) {
        console.log(error);
        return error;
      }
    };

    if (!load && isActive) {
      getUserData(userId).then((res) => {
        setLoad(true);
      });
    }
  }, [id, load, currentUser?.user?.id, isActive]);

  let userGroups: string[] = [];
  let tempGroups: string[] = [];
  let extraGroups: string[] = [];
  let matchGroups: string[] = [];
  let missingGroups: string[] = [];
  const officeUri = `https://admin.microsoft.com/?auth_upn=${username}%40consumerlaw.com&source=applauncher#/users/:/UserDetails/${officeData?.office?.id}`;

  if (
    officeData &&
    officeData.office !== null &&
    officeData.template !== null
  ) {
    userGroups = officeData.office.memberOf
      .map((rl) => `${rl.displayName} - ${rl.mail}`)
      .sort();
    tempGroups = officeData.template.data
      .map((el) =>
        el.attributes.office_groups.data.map(
          (rl) => `${rl.attributes.name} - ${rl.attributes.email}`
        )
      )
      .flat(1)
      .sort();

    tempGroups = [...new Set(tempGroups)];
    matchGroups = tempGroups.filter((element) => userGroups.includes(element));
    missingGroups = tempGroups.filter((element) => !userGroups.includes(element));
    extraGroups = userGroups.filter((element) => !tempGroups.includes(element));
  }

  return (
    <div className={`tab-pane ${isActive ? 'active' : ''}`}>
      <div className="row d-flex">
        <a
          href={officeUri}
          target="_blank"
          rel="noreferrer"
          className="btn btn-light ml-auto btn-xs"
        >
          Open Office Profile
        </a>
      </div>
      <div>
        <h3>Office 365 Groups</h3>
        {matchGroups.length > 0 && (
          <GroupsTable
            groups={matchGroups}
            tableName="O365 Teams"
            tableColor="bg-success"
          />
        )}
        {missingGroups.length > 0 && (
          <GroupsTable
            groups={missingGroups}
            tableName="Missing O365 Groups"
            tableColor="bg-danger"
          />
        )}
        {extraGroups.length > 0 && (
          <GroupsTable
            groups={extraGroups}
            tableName="Extra O365 Groups"
            tableColor="bg-warning"
          />
        )}
      </div>
    </div>
  );
}

export default OfficeTab;
