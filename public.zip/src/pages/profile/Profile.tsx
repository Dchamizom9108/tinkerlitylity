import { useState, useEffect } from "react";
import { ContentHeader, ShowAlert } from "@components";
import { Image, Button as RawButton } from "@profabric/react-components";
import styled from "styled-components";
import Swal from "sweetalert2";
import ModifyUserTab from "./ModifyUserTab";
import SugarTab from "./SugarTab";
import OfficeTab from "./OfficeTab";
import TcxTab from "./TcxTab";
import { useAppSelector } from "@app/store/store";

import { getUserPic } from "@app/services/user";
import { useParams } from "react-router-dom";

import {
  getUserDetail,
  disableExtension,
  deleteExtension,
} from "@app/services/user";

const StyledUserImage = styled(Image)`
  --pf-border: 3px solid #adb5bd;
  --pf-padding: 3px;
`;

export const TabButton = styled(RawButton)`
  margin-right: 0.25rem;
  --pf-width: 8rem;
`;

interface userData {
  [key: string]: any;
}

const Profile = () => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState("OFFICE365");
  const currentUser = useAppSelector((state) => state.auth.currentUser);

  const [pic, setPic] = useState("/img/default-profile.png");
  const [userData, setUserData] = useState<userData>({});
  const [departments, setDepartments] = useState([]);
  const [disableDeleteExtBtn, setDisableDeleteExtBtn] = useState(false);
  const [showCopyIcon, setShowCopyIcon] = useState(false);
  const [load, setLoad] = useState(false);
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [userScript, setUserScript] = useState("");

  const toggle = (tab: string) => {
    if (activeTab !== tab) setActiveTab(tab);
  };

  useEffect(() => {
    const fetchUserData = async (uId: string) => {
      try {
        const { data: { data: { attributes: user } } } = await getUserDetail(uId);
        setDepartments(user.departments.data);
        setUserData(user);
        console.log(user);
        const jobTitle = user.jobTitle.split(" ")[0] === "Legal" ? 'legal' : 'sales';
        setFullName(`${user.firstName} ${user.lastName}`);
        setEmail(user.email);
        document.title = `${user.username.split("@")[0]} | CLG`;
        const oid = user.o365Data?.id;
        const userScriptTemplate = `# Variables del nuevo usuario
$firstName = "${user.firstName}"
$lastName = "${user.lastName}"
$fullName = "$firstName $lastName"
$userName = "${user.username.split("@")[0]}"
$email = "${user.email}"
$password = "${user.accountsPassword || "C0nsumerL4w!!"}"
$ou = "OU=${jobTitle},OU=MEXICO USERS,OU=CLG Users,DC=lawoffice,DC=local"

# Crear el usuario en Active Directory
New-ADUser \`
    -Name $fullName \`
    -GivenName $firstName \`
    -Surname $lastName \`
    -UserPrincipalName "$userName@consumerlaw.com" \`
    -SamAccountName $userName \`
    -EmailAddress $email \`
    -Path $ou \`
    -AccountPassword (ConvertTo-SecureString $password -AsPlainText -Force) \`
    -Enabled $true \`
    -ChangePasswordAtLogon $false \`
    -PasswordNeverExpires $true \`
    -Title "${user.jobTitle}" \`

# Habilitar el usuario
Enable-ADAccount -Identity $userName`;

    // -Department "${departments[0]?.attributes?.name}"
        setUserScript(userScriptTemplate);
        getPic(oid);
        
      } catch (error) {
        console.log(error);
      }
    };

    const getPic = async (oid: string) => {
      const res = await getUserPic(oid);
      if (res !== "error") {
        setPic(res);
        localStorage.setItem(`userPic-${oid}`, res);
      }
    };

    if (!load) {
      fetchUserData(id!);
      setLoad(true);
    }
  }, [id, load]);

  const setDeleteExtension = (e: any) => {
    e.preventDefault();
    setDisableDeleteExtBtn(true);
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        console.log(email)
        disableExtension(email).then((resp) => {
          if (resp.status === 200) {
            ShowAlert("success", "Extension disabled", "", false, "OK");
          } else {
            ShowAlert("error", "Error", "Something went wrong", false, "OK");
          }
          setDisableDeleteExtBtn(false);
        })
      }
    });
  };

  const copyToClipboard = (value: string, message: string) => {
    navigator.clipboard.writeText(value)
      .then(() => ShowAlert("success", `${message} copied to clipboard`, "", false, "OK"))
      .catch((err) => console.error("Failed to copy: ", err));
  };

  const handleCopyScript = () => {
    navigator.clipboard
      .writeText(userScript)
      .then(() => {
        ShowAlert("success", "Script copied to clipboard", "", false, "OK");
      })
      .catch((err) => {
        console.error("Failed to copy: ", err);
      });
  };

  return (
    <div>
      <ContentHeader title="Profile" />
      <section className="content">
        <div className="container-fluid">
          <div className="row">
          <div className="col-md-3">
              <div className="card card-primary card-outline">
                <div className="card-body box-profile">
                  <div className="text-center" onClick={() => copyToClipboard(userData.accountsPassword, "Password")}>
                    <StyledUserImage width={100} height={100} rounded src={pic} alt="User profile" />
                  </div>
                  <h3 className="profile-username text-center" onClick={() => copyToClipboard(fullName, "Full name")}>
                    {userData.firstName} {userData.lastName}
                  </h3>
                  <p className="text-muted text-center">{userData.o365Data?.jobTitle}</p>
                  <ul className="list-group list-group-unbordered mb-3">
                    {email && (
                      <li className="list-group-item" >
                        <i className="fas fa-envelope text-lg align-middle" onClick={() => copyToClipboard(email, "Email")}></i>
                        <span className="text-sm ml-2" onMouseEnter={() => setShowCopyIcon(true)} onMouseLeave={() => setShowCopyIcon(false)} onClick={() => copyToClipboard(userData.username.split("@")[0], "Username")}>{email}</span>
                        {showCopyIcon && <i className="fas fa-copy text-lg align-middle ml-2" ></i>}
                      </li>
                    )}
                    <li style={{ listStyle: "none" }}>
                      {departments?.map((res: any, i) => (
                        <span key={i} className="badge badge-secondary p-1 mt-1 ml-1" style={{ fontSize: 11 }}>
                          {res.attributes.name}
                        </span>
                      ))}
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="col-md-9">
              <div className="card">
                <div className="card-header p-2">
                  <ul className="nav nav-pills">
                    <li className="nav-item">
                      <TabButton
                        variant={
                          activeTab === "OFFICE365" ? "primary" : "light"
                        }
                        onClick={() => toggle("OFFICE365")}
                      >
                        Office 365
                      </TabButton>
                    </li>
                    <li className="nav-item">
                      <TabButton
                        variant={activeTab === "SUGAR" ? "primary" : "light"}
                        onClick={() => toggle("SUGAR")}
                      >
                        Sugar
                      </TabButton>
                    </li>
                    <li className="nav-item">
                      <TabButton
                        variant={activeTab === "TCX" ? "primary" : "light"}
                        onClick={() => toggle("TCX")}
                      >
                        TCX
                      </TabButton>
                    </li>
                    {currentUser?.user?.role === "Admin" ? (
                      <li className="nav-item">
                      <TabButton
                        variant={activeTab === "MODIFY" ? "primary" : "light"}
                        onClick={() => toggle("MODIFY")}
                      >
                        Modify
                      </TabButton>
                    </li>
                    ) : null}
                    
                  </ul>
                  <div className="col-g-sm-4 float-right">
                    {currentUser?.user?.email === "dchamizo@consumerlaw.com" ? (
                      <button
                        className="btn btn-light ml-2"
                        onClick={setDeleteExtension}
                        id="delete-extension"
                        disabled={disableDeleteExtBtn}
                      >
                        <i className="fas fa-phone-slash"></i>
                      </button>
                    ) : null}
                    {currentUser?.user?.email === "dchamizo@consumerlaw.com" ? (
                      <button className="btn btn-light ml-2" onClick={handleCopyScript}>
                        <i className="fas fa-copy"></i>
                      </button>
                    ) : null }
                    {(() => {
                      return currentUser?.user?.role === "Admin" ||
                        currentUser?.user?.account?.id === id ? (
                        <a
                          href={`/print/${id}`}
                          target="_blank"
                          rel="noreferrer"
                          className="btn btn-light ml-2"
                        >
                          <i className="fas fa-print"></i>
                        </a>
                      ) : null;
                    })()}
                  </div>
                </div>
                <div className="card-body">
                  <div className="tab-content">
                    <OfficeTab isActive={activeTab === "OFFICE365"} />
                    <SugarTab isActive={activeTab === "SUGAR"} />
                    <TcxTab isActive={activeTab === "TCX"} />
                    {currentUser?.user?.role === "Admin" && <ModifyUserTab isActive={activeTab === "MODIFY"} />}
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Profile;
