import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useAppSelector } from "@app/store/store";
import Select from "react-select";
import { getDepartments, getUserDetail, getDepartmentsNames } from "@app/services/user";
import Swal from "sweetalert2";
import { UserForm } from "@app/components";
import DatePicker from "react-datepicker";
import axios from "axios";
import { FormData } from "@app/types"; // Asegúrate de importar la interfaz correcta

const ModifyUserTab = ({ isActive }: { isActive: boolean }) => {
  const secureEmailProvider = "https://bots.consumerlaw.com/api/sendEmail";
  const whoIsConnected = useAppSelector((state) => state.auth.currentUser);
  const [startDate, setStartDate] = useState<Date | null>(new Date());
  const [ deactDate, setDeactDate ] = useState<Date | null>(new Date());  
  const [ deactNotes, setDeactNotes ] = useState('');
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    actionToExecute: "Modify",
    effectiveDate: new Date(),
    jobTitle: null,
    departments: [],
    notes: "",
    suspensionPeriod: "",
    deactivationType: "",
    processing: false,
    startDate: null, // Asegúrate de incluir startDate aquí también
  });
  const { id } = useParams();
  const [load, setLoad] = useState(false);

  const actionOptions = [
    { value: "Modify", label: "Modify" },
    { value: "Deactivate", label: "Deactivate" },
  ];

  const deactivationTypeOptions = [
    { value: "Permanent", label: "Permanent" },
    { value: "Temporary", label: "Temporary" },
  ];

  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      backgroundColor: "#343a4000",
      color: "#fff",
    }),
    menu: (provided: any) => ({
      ...provided,
      backgroundColor: "#70757a",
      color: "#000",
    }),
    singleValue: (provided: any) => ({
      ...provided,
      color: "#fff",
    }),
    placeholder: (provided: any) => ({
      ...provided,
      color: "#bbb",
    }),
  };

  useEffect(() => {
    const getUserData = async (uId: string) => {
      try {
        console.log(uId, 'modify');
        const response = await getUserDetail(uId);
        let data = response.data.data.attributes;

        const userData: FormData = {
          firstName: data.firstName,
          lastName: data.lastName,
          email: data.email,
          actionToExecute: "Modify",
          effectiveDate: new Date(),
          jobTitle: data.jobTitle || null,
          departments: data.departments.data.map((dep: any) => dep.attributes.name),
          notes: "",
          suspensionPeriod: "",
          deactivationType: "",
          processing: false,
          startDate: null, // Asegúrate de incluir startDate aquí también
        };

        setFormData(userData);

        const depts = await getDepartmentsNames();
        console.log(depts);
        let options = depts.data.data.map((dep: any) => ({
          value: dep.id,
          label: dep.attributes.name,
        }));
        setFormData((prevData) => ({
          ...prevData,
          departmentsOptions: options,
        }));

        return response;
      } catch (error) {
        console.log(error);
        return error;
      }
    };

    if (!load && isActive) {
      getUserData(id!).then((res) => {
        setLoad(true);
      });
    }
  }, [id, load, isActive]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormData({ ...formData, processing: true });

    const payload = {
      ...formData,
      whoSendModification: whoIsConnected?.user?.email,
      strappiUserId: id,
      deactDate: deactDate,
      deactNotes: deactNotes
    };

    sendEmail(payload)
      .then(() => {
        Swal.fire({
          title: "User request submitted successfully",
          text: "User request has been submitted. We will notify you when changes are ready.",
          icon: "success",
          confirmButtonText: "Ok",
        });
        setFormData({ ...formData, processing: false });
      })
      .catch(() => {
        Swal.fire({
          title: "Error",
          text: "There was an error submitting the request, please try again",
          icon: "error",
          confirmButtonText: "Ok",
        });
        setFormData({ ...formData, processing: false });
      });
  };

  const sendEmail = async (data: FormData) => {
    try {
      let sendData = JSON.stringify(data);
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: secureEmailProvider,
        headers: { "Content-Type": "application/json" },
        data: sendData,
      };

      const response = await axios.request(config);
      return response.data;
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className={`tab-pane ${isActive ? 'active' : ''}`}>
      <h2>Modify User</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group row">
          <label htmlFor="actionToExecute" className="col-sm-2 col-form-label">Action</label>
          <div className="col-sm-10">
            <Select
              id="actionToExecute"
              options={actionOptions}
              value={actionOptions.find((option) => option.value === formData.actionToExecute)}
              onChange={(e : any) => setFormData({ ...formData, actionToExecute: e.value })}
              styles={customStyles}
            />
          </div>
        </div>
        {formData.actionToExecute === "Deactivate" && (
          <div>
            <div className="form-group row">
              <label htmlFor="deactivationType" className="col-sm-2 col-form-label">Deactivation Type</label>
              <div className="col-sm-10">
                <Select
                  id="deactivationType"
                  options={deactivationTypeOptions}
                  value={deactivationTypeOptions.find((option) => option.value === formData.deactivationType)}
                  onChange={(e : any) => setFormData({ ...formData, deactivationType: e.value })}
                  styles={customStyles}
                />
              </div>
            </div>
            <div className="form-group row">
                <label htmlFor="deactivationDate" className="col-sm-2 col-form-label">Deactivation Date</label>
                <div className="col-sm-10">
                  <DatePicker
                    id="deactivationDate"
                    selected={startDate}
                    onChange={(date: Date | null) => {
                      setStartDate(date);
                      setDeactDate(date);
                    }}
                  />
                </div>
            </div>
            <div className="form-group row">
              <label htmlFor="deactivationNotes" className="col-sm-2 col-form-label">Deactivation Notes</label>
              <div className="col-sm-10">
                <textarea
                  id="deactivationNotes"
                  className="form-control"
                  onChange={(e) => setDeactNotes(e.target.value)}
                />
              </div>
            </div>
          </div>
        )}
        {formData.actionToExecute === "Modify" && (
          <UserForm formData={formData} setFormData={setFormData} handleSubmit={handleSubmit} />
        )}
        <div className="form-group row">
          <div className="offset-sm-2 col-sm-10">
            <button type="submit" className="btn btn-primary" disabled={formData.processing}>
              Submit
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default ModifyUserTab;
