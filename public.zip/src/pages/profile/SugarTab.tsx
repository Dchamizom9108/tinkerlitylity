import { useEffect, useState } from 'react';
import { useParams } from "react-router-dom";
import { getUserDetail } from '@app/services/user';
import { GroupsTable } from '@app/components';

interface SugarData {
  sugar: {
    id: string;
    roles: { name: string }[];
    teams: { name: string }[];
  } | null;
  template: {
    data: {
      attributes: {
        sugar_roles: {
          data: { attributes: { roleName: string } }[]
        };
        sugar_teams: {
          data: { attributes: { teamName: string } }[]
        };
      }
    }[];
  } | null;
}

const SugarTab = ({ isActive }: { isActive: boolean }) => {
  const { id } = useParams();
  const [sugarData, setSugarData] = useState<SugarData | null>(null);
  const [load, setLoad] = useState(false);

  useEffect(() => {
    const getUserData = async (uId: any) => {
      try {
        const response = await getUserDetail(uId);

        let data = response.data.data.attributes;

        const sugarData: SugarData = {
          sugar: data.sugarData,
          template: data.departments,
        };
        setSugarData(sugarData);
        return response;
      } catch (error) {
        console.log(error);
        return error;
      }
    };

    if (!load && isActive) {
      getUserData(id).then((res) => {
        setLoad(true);
      });
    }
  }, [id, load, isActive]);

  let extraTeams: string[] = [];
  let matchTeams: string[] = [];
  let missingTeams: string[] = [];
  let matchRoles: string[] = [];
  let extraRoles: string[] = [];
  let missingRoles: string[] = [];

  const sugarUri = `https://sugar.consumerlaw.com/#bwc/index.php?module=Users&offset=1&stamp=1665456917033250100&return_module=Users&action=DetailView&record=${sugarData?.sugar?.id}`;

  if (sugarData && sugarData.sugar && sugarData.template) {
    let userRoles = sugarData.sugar.roles.map((rl: { name: any; }) => rl.name).sort();
    let tempRoles = sugarData.template.data.map((el: { attributes: { sugar_roles: { data: any[]; }; }; }) => el.attributes.sugar_roles.data.map(rl => rl.attributes.roleName)).flat(1).sort();
    tempRoles = [...new Set(tempRoles)];
    matchRoles = tempRoles.filter((element: any) => userRoles.includes(element));
    missingRoles = tempRoles.filter((element: any )=> !userRoles.includes(element));
    extraRoles = userRoles.filter((element : any) => !tempRoles.includes(element));

    let userTeams = sugarData.sugar.teams.map((rl: { name: any; }) => rl.name).sort();
    let tempTeams = sugarData.template.data.map((el: { attributes: { sugar_teams: { data: any[]; }; }; }) => el.attributes.sugar_teams.data.map(rl => rl.attributes.teamName)).flat(1).sort();
    tempTeams = [...new Set(tempTeams)];
    matchTeams = tempTeams.filter((element: any) => userTeams.includes(element));
    missingTeams = tempTeams.filter((element: any) => !userTeams.includes(element));
    extraTeams = userTeams.filter((element: any) => !tempTeams.includes(element));
  }

  return (
    <div className={`tab-pane ${isActive ? 'active' : ''}`}>
      <div>
        <div className='row d-flex'>
          <a href={sugarUri} target="_blank" rel="noreferrer" className='btn btn-light ml-auto btn-xs'>Open Sugar Profile</a>
        </div>
        <div>
          <h3>Roles</h3>
          {matchRoles.length > 0 ? <GroupsTable groups={matchRoles} tableName="Sugar Roles" tableColor="bg-success" /> : ''}
          {missingRoles.length > 0 ? <GroupsTable groups={missingRoles} tableName="Missing Roles" tableColor="bg-danger" /> : ''}
          {extraRoles.length > 0 ? <GroupsTable groups={extraRoles} tableName="Extra Roles" tableColor="bg-warning" /> : ''}
        </div>
        <div>
          <h3>Teams</h3>
          {matchTeams.length > 0 ? <GroupsTable groups={matchTeams} tableName="Sugar Teams" tableColor="bg-success" /> : ''}
          {missingTeams.length > 0 ? <GroupsTable groups={missingTeams} tableName="Missing Teams" tableColor="bg-danger" /> : ''}
          {extraTeams.length > 0 ? <GroupsTable groups={extraTeams} tableName="Extra Teams" tableColor="bg-warning" /> : ''}
        </div>
      </div>
    </div>
  );
};

export default SugarTab;
