import { ContentHeader, SmallBox } from '@components';

const Dashboard = () => {
  document.title = "Home | CLG";
  return (
    <div>
      <br></br>
      <section className="content">
        <div className="container-fluid">
        <div className="row">
              <SmallBox
                href="https://sugar.consumerlaw.com"
                icon={"img/sugar.png"}
                alt="Sugar Logo"
                title="Sugar CRM"
                colClass="col-lg-3 col-6"
                cardStyle={"small-box bg-green"}
              ></SmallBox>
              <SmallBox
                href="https://outlook.office.com/mail/"
                icon={"img/outlook.png"}
                alt="Outlook Logo"
                title="Outlook"
                colClass="col-lg-3 col-6"
                cardStyle={"small-box bg-blue"}
              ></SmallBox>
              <SmallBox
                href="https://teams.microsoft.com/v2/"
                icon={"img/teams.png"}
                alt="Teams Logo"
                title="Teams"
                colClass="col-lg-3 col-6"
                cardStyle={"small-box bg-indigo"}
              ></SmallBox>
              <SmallBox
                href="https://consumerlaw.my3cx.us/webclient/#/people"
                icon={"img/3cx.png"}
                alt="3cx Logo"
                title="3cx"
                colClass="col-lg-3 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
            </div>
            <div className="row">
              <SmallBox
                href="https://access.paylocity.com/"
                icon={"img/paylocity.png"}
                alt="Paylocity Logo"
                title="Paylocity"
                colClass="col-lg-2 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
              <SmallBox
                href="https://immpro.consumerlaw.com/"
                icon={"img/immigrantpro.png"}
                alt="ImmigrantPro Logo"
                title="ImmigrantPro"
                colClass="col-lg-2 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
              <SmallBox
                href="https://logicsdocs.consumerlaw.com/"
                icon={"img/netdocs.png"}
                alt="NetDocs Logo"
                title="NetDocs"
                colClass="col-lg-2 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
              <SmallBox
                href="http://office.consumerlaw.com/"
                icon={"img/intranet.png"}
                alt="Intranet Logo"
                title="Intranet"
                colClass="col-lg-2 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
              <SmallBox
                href="https://firma.consumerlaw.com/es/"
                icon={"img/firma.png"}
                alt="Firma Logo"
                title="Firma CLG"
                colClass="col-lg-2 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
              <SmallBox
                href="https://www.consumerlaw.com/"
                icon={"img/logoshield.png"}
                alt="CLG Logo"
                title="Conocenos"
                colClass="col-lg-2 col-6"
                cardStyle={"small-box bg-navy"}
              ></SmallBox>
            </div>
          </div>
      </section>

    </div>
  );
};

export default Dashboard;
