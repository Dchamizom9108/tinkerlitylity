import React, { useEffect, useState } from "react";
import { ShowAlert } from "@app/components";
import proxyService from "@app/services/proxy.service";
import { getUserByTcxExt } from "@app/services/user";
import DataTableCh from "@components/table/DataTableCh";

import "./salesQ.css";

function SalesQ() {
  document.title = "SalesQ | Consumer Law Group";
  const [dataUsersIn, setDataUsersIn] = useState([{}]);
  const [today, setToday] = useState('');
  const [loading, setLoading] = React.useState(false);

  const user = JSON.parse(localStorage.getItem("user"));
  const role = user?.user.role;
  const isGuardian = user?.user?.account.attributes.sugarData.teams.some(
    (team) => team.id === "ab044694-c78b-11ee-b23b-dadc21ba0c54"
  );

  const qStatURL = "https://home.justicialaboral.com/bot_db/api/qStats.php";

  useEffect(() => {
    async function fetchData() {
      try{
        let date = new Date();
        date.setHours(date.getUTCHours() - 5);
        date = date.toISOString().split("T")[0];
        setToday(date);
        const qData = await proxyService.getDataGET(qStatURL);
        const userData = await proxyService.getUsersData();

        const dataIn = await createGlobalData(qData, userData, date, 'all');
        setDataUsersIn(dataIn);

      } catch (error) {
        console.error(error);
      }
    }
    fetchData();
  }, []);

  async function createGlobalData(data, users, end, filter) {
  
    // filtrar los agentes que la fecha no sea la actual.
    const filteredData = data.filter(item => item.last_checked.slice(0, 10) === end);
  
    const checkDate = filteredData[0].last_checked.slice(11, 16);
    const managersExt = [191, 192, 457, 221, 455, 462, 465, 527]

    const flatUsersWithTeam = users.reduce((accumulator, team) => {
      const teamData = team.data.map(user => ({
        ...user,
        team: team.label
      }));
      return accumulator.concat(teamData);
    }, []);
    
    // Exluir Ext de los managers usando el array de managersExt
    const allAgentsFiltered = flatUsersWithTeam.filter(agent =>!managersExt.includes(parseInt(agent.phone_ext_c)))
    // Iterar sobre los agentes del equipo y buscar su estado en qStatsData
    const globalUsersWithTeam = allAgentsFiltered.map(agent => {
      const agentStatus = filteredData.find(item => item.ext === agent.phone_ext_c);
      let formattedDate = "";
      let qStatus = "Deactivated";
  
      if (agentStatus) { // Obtenemos la fecha y hora en formato local
        const isoDateString = agentStatus.last_checked;
        formattedDate = isoDateString.slice(5, 16).replace('T', '-');
        if (agentStatus.top_bucket_status === "0" && agentStatus.bottom_bucket_status === "0") {
          qStatus = "Deactivated";
        } else if (agentStatus.top_bucket_status === "1" && agentStatus.bottom_bucket_status === "1") {  
          qStatus = "Active";
        }
      }
  
      return {
        ...agent,
        qStatus: qStatus,
        lastChecked: agentStatus ? formattedDate : checkDate,
      };
    })
      .sort((a, b) => parseInt(a.phone_ext_c) - parseInt(b.phone_ext_c))
        .filter( item => item.qStatus !== filter)
    return globalUsersWithTeam;
  }

  const handleQueueUpdate = (phoneExt, typeOfAction) => {
    const availableUsers = [ 'imurillo@consumerlaw.com', 'ysalomon@consumerlaw.com', 'mmijangos@consumerlaw', 'dchamizo@consumerlaw.com' ];
    if (!availableUsers.includes(user.email) && loading) {
      ShowAlert('error', 'Error', 'You are not authorized to perform this action');
      return;
    } else {
      switch (typeOfAction) {
        case 'Active':
          updateUserStatus(phoneExt, 'https://bots.consumerlaw.com/tcx/tcx-user-out-of-queue', 'You are out of Q 904 and 905', 'removed');
          break;
        case 'Deactivated':
        case 'Only 904 Q':
        case 'Only 905 Q':
          updateUserStatus(phoneExt, 'https://bots.consumerlaw.com/tcx/tcx-user-add-to-queue', 'You are added to Q 904 and 905', 'added');
          break;
        default:
          break;
      }
    }
  };

  async function updateUserStatus(phoneExt, url, subject, action) {
    setLoading(true);
    let requestData = { 
      "extension": phoneExt,
      "qNumber": 905
    };
    
    proxyService.getDataPOST(url, requestData).then((response) => {
      if (response.request === 'success') {
        getUserByTcxExt(phoneExt).then((user) => {
          user = user.data.data[0].attributes;
          const username = user.email.split('@')[0];
          const emailOptions = {
            recipients: `${user.email}, p1managers@consumerlaw.com`,
            //recipients: `dchamizo@consumerlaw.com`,
            subject: `${username} are ${action} to Q 905`,
            emailBody: generateEmailBody(user.firstName, subject, action)
          };
          ShowAlert('success', 'Success', `User ${action} successfully.`);
          proxyService.sendEmailFromSupport(emailOptions).then(() => {
            const converActionToDb = action === 'added' ? 1 : 0;
            let configUrl = `https://home.justicialaboral.com/bot_db/api/fieldEdit.php?value=${converActionToDb}&table=sales_q_status&id=${phoneExt}&fullname=${user.firstName} ${user.lastName}&last_checked=${new Date().toISOString()}`;
            proxyService.getDataGET(configUrl).then(() => {
              setLoading(false);
              ShowAlert('success', 'Success', `User ${action} successfully, wait 5 minutes to see the changes in the table.`);
              
            }).catch((error) => {
              console.error(error);
            })
          }).catch((error) => {
            console.error(error);
          });
        }).catch((error) => {
          console.error(error);
        });
      }
    }).catch((error) => {
      console.error(error);
    });
  }

  function generateEmailBody(firstName, subject, action) {
    return `
      <div class="container" style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 5px;">
        <div class="header" style="background-color: #f4f4f4; padding: 10px 0; text-align: center;">
          <h2 style="margin: 0;">${subject}</h2>
        </div>
        <div class="content" style="padding: 20px 0;">
          <p style="margin-bottom: 10px;">Hello ${firstName},</p>
          <p style="margin-bottom: 10px;">This is to inform you that you have been ${action === 'removed' ? 'removed from' : 'added to'} the queue 905.</p>
          <p style="margin-bottom: 0;">Thank you.</p>
        </div>
      </div>
    `;
  }

  return (
    <div>
      {role === "Admin" || role === "Manager" || isGuardian ? (
        <div className="report" id="team--performance">

          <div className="title-table-container">
            <h1>Sales In Q</h1>
            <h1 id="dateTitle">{today}</h1>
          </div>

          <div id="team1Table">

          <DataTableCh dataUsersIn={dataUsersIn} loading={loading} handleQueueUpdate={handleQueueUpdate} />

          </div>

        </div>
      ) : (
        <h2>Contact with IT</h2>
      )}
    </div>
  );
}

export default SalesQ;
