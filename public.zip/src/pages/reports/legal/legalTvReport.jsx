import { useState, useEffect } from "react";
import styles from "./legal.module.css";
import proxyService from "../../../services/proxy.service";

const LegalTvReport = () => {
  const [userData, setUserData] = useState([]);
  const [waittingCalls, setWaittingCalls] = useState(0);
  const [servicedCalls, setServicedCalls] = useState(0);
  const [abandonedCalls, setAbandonedCalls] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await proxyService.getDataGET("https://home.justicialaboral.com/bot_db/api/legal.php");
        setUserData(result);

        // Sumar los valores de llamadas en espera, atendidas y abandonadas
        const totalWaiting = result[0].calls_waiting;
        const totalServiced = result[0].calls_serviced;
        const totalAbandoned = result[0].calls_abandoned;

        setWaittingCalls(totalWaiting);
        setServicedCalls(totalServiced);
        setAbandonedCalls(totalAbandoned);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
    const intervalId = setInterval(fetchData, 6000); // Cada 6 segundos

    return () => clearInterval(intervalId); // Limpia el intervalo cuando el componente se desmonta
  }, []);

  const availableUsers = userData.filter(user => user.agent_status === "available");

  return (
    <div className="">
      <div className={styles.container}>
        {/* Lista de usuarios disponibles a la izquierda */}
        <div className={styles.userList}>
          <ul className={styles.userColumns}>
            {/* Primera columna */}
            <div className={styles.userColumn}>
              {availableUsers.slice(0, Math.ceil(availableUsers.length / 2)).map(user => (
                <li key={user.ext}>{user.fullname.split(" ")[0]} {user.fullname.split(" ")[1]}</li>
              ))}
            </div>
            {/* Segunda columna */}
            <div className={styles.userColumn}>
              {availableUsers.slice(Math.ceil(availableUsers.length / 2)).map(user => (
                <li key={user.ext}>{user.fullname.split(" ")[0]} {user.fullname.split(" ")[1]}</li>
              ))}
            </div>
          </ul>
        </div>
    
        {/* Estadísticas de llamadas a la derecha */}
        <div className={styles.callStats}>
          <h1 className={`${styles.countdown} ${waittingCalls > 0 ? styles.overTime : styles.onTime}`}>
            {waittingCalls}
          </h1>
          <p className={styles.waitingLabel}>Waiting Calls</p> {/* Etiqueta debajo de las llamadas en espera */}
          
          <div className={styles.callsInfoRow}> {/* Fila para alineación en línea */}
            <div className={styles.callsInfo}>
              <p>Serviced Calls:</p>
              <h1 className={styles.countdown}>{servicedCalls}</h1>
            </div>
            <div className={styles.callsInfo}>
              <p>Abandoned Calls:</p>
              <h1 className={styles.countdown}>{abandonedCalls}</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  
};

export default LegalTvReport;
