import { useEffect, useState } from "react";
import { getDataFromPerformance } from "@app/services/user";
import { GETMyselfUserData } from "@app/services/rh";
import { UserAttributes } from "@app/types";
import "./salesQ.css";
import moment from "moment";

function Wallboard() {
  const mahedaId = "2e696c94-59a3-11eb-8708-dadc21ba0c54"; // maheda
  document.title = "User Performance | CLG";

  const [userConected, setUserConected] = useState(false);
  const [dataLoaded, setDataLoaded] = useState(false);
  const [data, setData] = useState([]);
  const [user, setUser] = useState<UserAttributes | null>(null);

  useEffect(() => {
    async function fetchUserConected() {
      const userData = await GETMyselfUserData();
      console.log(userData);
      setUser(userData);
      setUserConected(true);
    }
    if (!userConected) {
      fetchUserConected();
    }
  }, [userConected]);

  useEffect(() => {
    const today = moment().format("YYYY-MM-DD");
    const userData = user;

    if (userConected && !dataLoaded) {
      updateData(today, userData);
    }
  }, [userConected, dataLoaded]);

  ////////////////////////////////////Functions///////////////////////////////////////////
  async function updateData(startInput: string, user: any) {
    console.log(startInput, "user", user);
    const fullName = `${user.firstName} ${user.lastName}`;
    // const fullName = "Josafat Maheda Gomez";
    console.log(fullName);

    try {
      const rawData = await getDataFromPerformance(startInput);

      let data = rawData?.data.data[0].attributes.data || [];

      let groupedEngagedData = data
        .filter(
          (item: any) => item.p1_sold_date_c !== null && item.as_name !== null
        )
        .reduce((acc: any, item: any) => {
          if (!acc[item.as_name]) {
            acc[item.as_name] = [];
          }
          acc[item.as_name].push(item);
          return acc;
        }, {});

      // Filtrar por fecha en cada grupo de usuario
      for (const asName in groupedEngagedData) {
        groupedEngagedData[asName] = groupedEngagedData[asName].filter(
          (engagement: any) => {
            const soldDate = new Date(engagement.p1_sold_date_c).getMonth() + 1; // +1 porque getMonth() empieza en 0
            const inputMonth = new Date(startInput).getMonth() + 1;
            return soldDate === inputMonth;
          }
        );

        // Eliminar el grupo si quedó vacío después del filtrado
        if (groupedEngagedData[asName].length === 0) {
          delete groupedEngagedData[asName];
        }
      }

      console.log(
        "Grouped Engaged Data (antes de filtrar por fecha):",
        groupedEngagedData
      );

      data = groupedEngagedData[fullName] || [];
      console.log("Grouped Engaged Data (después de filtrar por fecha):", data);
      setData(data);
      setDataLoaded(true);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  return (
    <div className="wallboard">
      <header className="wallboard-header">
        <h1>Sales Overview - {user?.firstName}</h1>
      </header>
  
      {/* Tabla de datos */}
      <div className="wallboard-table">
        <table className="data-table">
          <thead>
            <tr>
              <th>Cliente</th>
              <th>Fecha</th>
              <th>Colectado</th>
              <th>Fuente</th>
            </tr>
          </thead>
          <tbody>
            {data.map((item: any) => (
              <tr key={item.lead_id}>
                <td><a href={`https://sugar.consumerlaw.com/#Leads/${item.lead_id}`} target="_blank">{item.client_name}</a> </td>
                <td>{moment(item.p1_sold_date_c).format("YYYY-MM-DD")}</td>
                <td>${parseFloat(item.collected_amount).toFixed(0)}</td>
                <td>{item.utm_source_name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
  
}

export default Wallboard;
