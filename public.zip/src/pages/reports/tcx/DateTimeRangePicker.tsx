import { useState, useEffect } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import moment from "moment";

interface DateTimeRangePickerProps {
  onRangeChange: (range: {
    startDate: string | null;
    endDate: string | null;
  }) => void;
}

const DateTimeRangePicker: React.FC<DateTimeRangePickerProps> = ({
  onRangeChange,
}) => {
  // Inicializamos las fechas y horas con valores por defecto
  const [startDate, setStartDate] = useState<Date>(
    moment().startOf("day").toDate()
  ); // Fecha actual
  const [endDate, setEndDate] = useState<Date >(
    moment().endOf("day").toDate()
  ); // Fecha actual
  

  useEffect(() => {
    // Llamar a onRangeChange con los valores iniciales
    onRangeChange({
      startDate: moment(startDate).format("YYYY-MM-DD"),
      endDate: moment(endDate).format("YYYY-MM-DD"),
    });
  }, []); // Este efecto se ejecuta solo una vez cuando el componente se monta

  const handleDateChange = (dates: [Date | null, Date | null]) => {
    console.log(dates);
    const [start, end] = dates;
    setStartDate(start);
    setEndDate(end);
  
    onRangeChange({
      startDate: start ? moment(start).format("YYYY-MM-DD") : null,
      endDate: end ? moment(end).format("YYYY-MM-DD") : null
    });
  };

  return (
    <div className="date-time-picker">
      <label>Date: </label>
      <DatePicker
        selected={startDate}
        onChange={handleDateChange}
        startDate={startDate}
        endDate={endDate}
        selectsRange
        isClearable
        dateFormat="yyyy-MM-dd"
      />

    </div>
  );
};

export default DateTimeRangePicker;
