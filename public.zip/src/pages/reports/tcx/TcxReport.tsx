import { useEffect, useState, useCallback } from "react";
import { getDataGET } from "@app/services/proxy";
import Swal from "sweetalert2";
import "bootstrap/dist/css/bootstrap.min.css";
import DateTimeRangePicker from "./DateTimeRangePicker";
import moment from "moment";

import { utils, writeFile } from "xlsx";

import { getDepartmentsNames, GETDepartmentById } from "@app/services/user";

import { DepartmentFilter } from "@app/components";

import { DepartmentsType, TcxData } from "@app/types";

const excludedAgents = [
  "",
  "Admin Owner",
  "Rafael Castillo",
  "Adam Dayan",
  "Daniel Chamizo",
  "Marcel Cruz Suarez",
];

function TcxReport() {
  const [tableData, setTableData] = useState<TcxData[]>([]);
  const [filteredData, setFilteredData] = useState<TcxData[]>([]);
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: string;
  } | null>(null);
  const [filter, setFilter] = useState({});
  const [departments, setDepartments] = useState<DepartmentsType[]>([]);

  const [range, setRange] = useState<{
    startDate: string | null;
    endDate: string | null;
  }>({
    startDate: null,
    endDate: null,
  });

  const [loadingText, setLoadingText] = useState("Cargando...");

  const handleRangeChange = (newRange: {
    startDate: string | null;
    endDate: string | null;
  }) => {
    setRange(newRange);
  };

  const fetchTableData = useCallback(async () => {
    console.log("Fetching table data", range);
    try {
      // Retornar 0 si startDate o endDate son null
      if (
        !range.startDate ||
        !range.endDate
      ) {
        return;
      }

      const data = await getDataGET(
        `http://home.justicialaboral.com/bot_db/api/tcx.php?fechaInicio=${range.startDate}&fechaFin=${range.endDate}`
      );

      if (data) {
        const filteredData = data.filter((entry: TcxData) => !excludedAgents.includes(entry.agent));
      
        // Agrupar y sumar los datos por agente para el día actual
        const groupedDataToday: { [key: string]: TcxData } = {};
        filteredData.forEach((entry: TcxData) => {
          const existing = groupedDataToday[entry.agent];
      
          if (existing) {
            // Sumar valores numéricos acumulados
            existing.inboundAnswered =
              Number(existing.inboundAnswered) + Number(entry.inboundAnswered);
            existing.inboundUnanswered =
              Number(existing.inboundUnanswered) + Number(entry.inboundUnanswered);
            existing.outboundAnswered =
              Number(existing.outboundAnswered) + Number(entry.outboundAnswered);
            existing.outboundUnanswered =
              Number(existing.outboundUnanswered) + Number(entry.outboundUnanswered);
            existing.totalAnswered =
              Number(existing.totalAnswered) + Number(entry.totalAnswered);
            existing.totalUnanswered =
              Number(existing.totalUnanswered) + Number(entry.totalUnanswered);
      
            // Sumar tiempos (totalTalkingTime) correctamente
            const totalTalkingTime = moment
              .duration(existing.totalTalkingTime)
              .add(moment.duration(entry.totalTalkingTime));
            existing.totalTalkingTime = moment
              .utc(totalTalkingTime.asMilliseconds())
              .format("HH:mm:ss");
          } else {
            // Si no existe, asignar la primera entrada
            groupedDataToday[entry.agent] = { ...entry };
          }
        });
      
        // Convertir el objeto agrupado en un array y ordenar por agente
        const groupedArray = Object.values(groupedDataToday).sort((a, b) => {
          return a.agent.localeCompare(b.agent);
        });
      
        setTableData(groupedArray);
        setFilteredData(groupedArray);
        setLoadingText("");
      }
    } catch (error) {
      console.error("Error fetching table data", error);
      Swal.fire("Error", "Failed to load data.", "error");
      setLoadingText("Error al cargar los datos");
    }
  }, [range]);

  const fetchDepartmentFilters = useCallback(async () => {
    try {
      const response = await getDepartmentsNames();
      const departments = response.data.data.map((dep: any) => {
        const name = dep.attributes.name;
        const id = dep.id;
        return { name, id };
      });
      setDepartments(departments);
    } catch (error) {
      console.error("Error fetching department filters", error);
      Swal.fire("Error", "Failed to load department filters.", "error");
    }
  }, []);

  useEffect(() => {
    const handleDepartmentFilter = async (department: string | object) => {
      try {
        // Si department es undefined, null o un objeto vacío, mostrar todos los datos
        if (
          !department ||
          (typeof department === "object" &&
            Object.keys(department).length === 0)
        ) {
          setFilteredData(tableData);
          return;
        }

        // Encontrar los usuarios asociados al departamento seleccionado
        const selectedDepartment = await GETDepartmentById(parseInt(department as string));

        const accounts = selectedDepartment.data.data?.attributes.accounts.data?.map((acc: any) => {
          const firstName = acc.attributes.tcxData?.FirstName;
          const lastName = acc.attributes.tcxData?.LastName;
          return `${firstName} ${lastName}`;
        });

        // Filtrar la tabla por agentes que pertenezcan al departamento seleccionado
        const filtered = tableData.filter((entry) =>
          accounts.includes(entry.agent)
        );

        setFilteredData(filtered);
      } catch (error) {
        console.error("Error filtering by department", error);
        Swal.fire("Error", "Failed to filter by department.", "error");
      }
    };

    // Llamar a la función cuando cambie el filtro
    if (filter) {
      handleDepartmentFilter(filter as string | object);
    }
  }, [filter, tableData, departments]);

  const handleSort = (key: string) => {
    let direction = "asc";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "asc"
    ) {
      direction = "desc";
    }
    setSortConfig({ key, direction });

    const sortedData = [...filteredData].sort((a, b) => {
      if (a[key as keyof TcxData] < b[key as keyof TcxData])
        return direction === "asc" ? -1 : 1;
      if (a[key as keyof TcxData] > b[key as keyof TcxData])
        return direction === "asc" ? 1 : -1;
      return 0;
    });
    setFilteredData(sortedData);
  };

  useEffect(() => {
    fetchDepartmentFilters();
    fetchTableData();
  }, [fetchTableData, fetchDepartmentFilters]);

  const exportToExcel = () => {
    const wb = utils.book_new();
    const ws = utils.json_to_sheet(tableData);
    utils.book_append_sheet(wb, ws, "Sheet1");
    writeFile(wb, "TCXReport.xlsx");
  };
  return (
    <div>
      <section className="content">
        <div className="card">
          <div className="card-header input-group input-group-md row ">
            <div className="col-12 row">
              <div className="col-6">
                <DateTimeRangePicker onRangeChange={handleRangeChange} />
              </div>
              <DepartmentFilter
                filterChange={setFilter}
                options={departments}
                filter={filter}
                className="col-4"
              ></DepartmentFilter>
                <button className="btn btn-primary col-1" onClick={exportToExcel} title="export" style={{margin: "auto"}}>Export</button>
            </div>

          </div>

          <div className="card-body p-0">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th onClick={() => handleSort("agent")}>Agent</th>
                  <th onClick={() => handleSort("inboundAnswered")}>
                    In Answrd
                  </th>
                  <th onClick={() => handleSort("inboundUnanswered")}>
                    In Unanswrd
                  </th>
                  <th onClick={() => handleSort("outboundAnswered")}>
                    Out Answrd
                  </th>
                  <th onClick={() => handleSort("outboundUnanswered")}>
                    Out Unanswrd
                  </th>
                  <th onClick={() => handleSort("totalAnswered")}>
                    Total Answrd
                  </th>
                  <th onClick={() => handleSort("totalUnanswered")}>
                    Total Unanswrd
                  </th>
                  <th onClick={() => handleSort("totalTalkingTime")}>
                    Total Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredData.length > 0 ? (
                  filteredData.map((row, index) => (
                    <tr key={index}>
                      <td>{row.agent}</td>
                      <td>{row.inboundAnswered}</td>
                      <td>{row.inboundUnanswered}</td>
                      <td>{row.outboundAnswered}</td>
                      <td>{row.outboundUnanswered}</td>
                      <td>{row.totalAnswered}</td>
                      <td>{row.totalUnanswered}</td>
                      <td>{row.totalTalkingTime}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9} className="text-center">
                      {loadingText}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}

export default TcxReport;


/*
import { useEffect, useState, useCallback } from "react";
import { getDataGET } from "@app/services/proxy";
import Swal from "sweetalert2";
import "bootstrap/dist/css/bootstrap.min.css";
import DateTimeRangePicker from "./DateTimeRangePicker";
import moment from "moment";

import { utils, writeFile } from "xlsx";

import { getDepartmentsNames, GETDepartmentById } from "@app/services/user";

import { DepartmentFilter } from "@app/components";

import { DepartmentsType, TcxData } from "@app/types";

const excludedAgents = [
  "",
  "Admin Owner",
  "Rafael Castillo",
  "Adam Dayan",
  "Daniel Chamizo",
  "Marcel Cruz Suarez",
];

function TcxReport() {
  const [tableData, setTableData] = useState<TcxData[]>([]);
  const [filteredData, setFilteredData] = useState<TcxData[]>([]);
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: string;
  } | null>(null);
  const [filter, setFilter] = useState({});
  const [departments, setDepartments] = useState<DepartmentsType[]>([]);

  const [range, setRange] = useState<{
    startDate: string | null;
    endDate: string | null;
    startTime: string | null;
    endTime: string | null;
  }>({
    startDate: null,
    endDate: null,
    startTime: null,
    endTime: null,
  });

  const [loadingText, setLoadingText] = useState("Cargando...");

  const handleRangeChange = (newRange: {
    startDate: string | null;
    endDate: string | null;
    startTime: string | null;
    endTime: string | null;
  }) => {
    setRange(newRange);
  };

  const fetchTableData = useCallback(async () => {
    try {
      // Retornar 0 si startDate o endDate son null
      if (
        !range.startDate ||
        !range.endDate ||
        !range.startTime ||
        !range.endTime
      ) {
        return;
      }

      const data = await getDataGET(
        `http://home.justicialaboral.com/bot_db/api/tcx.php?fechaInicio=${range.startDate}&fechaFin=${range.endDate}`
      );

      if (data) {
        const filteredData = data.filter((entry: TcxData) => {
          if (range.startDate === range.endDate) {
              const entryDate = moment(entry.data_date); // Parse the date from data_date
              const isSameDay = entryDate.isSame(range.startDate, 'day'); //Check if entry date is the same as the selected date
              if (isSameDay) {
                const entryTime = moment(entry.timeSet, "HH:mm:ss");
                const startTime = moment(range.startTime, "HH:mm");
                const endTime = moment(range.endTime, "HH:mm");
      
                return entryTime.isBetween(startTime, endTime, null, '[]');
              }
              return false;
          } else {
              return true; // Keep multi-day filtering as is
          }
      }).filter((entry: TcxData) => !excludedAgents.includes(entry.agent));

        const groupedDataSingleDay: { [key: string]: TcxData } = {};
        const groupedDifference: { [key: string]: TcxData } = {};
        filteredData.forEach((entry: TcxData) => {
          const existing = groupedDataSingleDay[entry.agent];
          if (!existing || Number(entry.id) < Number(existing.id)) {
            // Menor ID (más cercano al inicio)
            groupedDataSingleDay[entry.agent] = { ...entry };
          }

          // Guardar también el mayor ID (más cercano al final)
          if (
            !groupedDifference[entry.agent] ||
            Number(entry.id) > Number(groupedDifference[entry.agent].id)
          ) {
            groupedDifference[entry.agent] = { ...entry };
          }
        });

        // Restar valores entre menor ID y mayor ID para cada agente
        const groupedResult: any = Object.keys(groupedDataSingleDay).map(
          (agent) => {
            const minEntry = groupedDataSingleDay[agent];
            const maxEntry = groupedDifference[agent];

            const minTotalTalkingTime = moment.duration(
              minEntry.totalTalkingTime
            );
            const maxTotalTalkingTime = moment.duration(
              maxEntry.totalTalkingTime
            );
            const totalTalkingTime = moment.duration(
              maxTotalTalkingTime.asMilliseconds() -
                minTotalTalkingTime.asMilliseconds()
            );
            return {
              agent: String(agent),
              inboundAnswered:
                Number(maxEntry.inboundAnswered) -
                Number(minEntry.inboundAnswered),
              inboundUnanswered:
                Number(maxEntry.inboundUnanswered) -
                Number(minEntry.inboundUnanswered),
              outboundAnswered:
                Number(maxEntry.outboundAnswered) -
                Number(minEntry.outboundAnswered),
              outboundUnanswered:
                Number(maxEntry.outboundUnanswered) -
                Number(minEntry.outboundUnanswered),
              totalAnswered:
                Number(maxEntry.totalAnswered) - Number(minEntry.totalAnswered),
              totalUnanswered:
                Number(maxEntry.totalUnanswered) -
                Number(minEntry.totalUnanswered),
              totalTalkingTime: moment
                .utc(totalTalkingTime.asMilliseconds())
                .format("HH:mm:ss"),
            };
          }
        );

        // Agrupar y sumar los datos por agente
        const groupedDataMultiDay: { [key: string]: TcxData } = {};
        filteredData.forEach((entry: TcxData) => {
          const existing = groupedDataMultiDay[entry.agent];

          if (existing) {
            // Sumar valores numéricos acumulados
            existing.inboundAnswered =
              Number(existing.inboundAnswered) + Number(entry.inboundAnswered);
            existing.inboundUnanswered =
              Number(existing.inboundUnanswered) +
              Number(entry.inboundUnanswered);
            existing.outboundAnswered =
              Number(existing.outboundAnswered) +
              Number(entry.outboundAnswered);
            existing.outboundUnanswered =
              Number(existing.outboundUnanswered) +
              Number(entry.outboundUnanswered);
            existing.totalAnswered =
              Number(existing.totalAnswered) + Number(entry.totalAnswered);
            existing.totalUnanswered =
              Number(existing.totalUnanswered) + Number(entry.totalUnanswered);

            // Sumar tiempos (totalTalkingTime) correctamente
            const totalTalkingTime = moment
              .duration(existing.totalTalkingTime)
              .add(moment.duration(entry.totalTalkingTime));
            existing.totalTalkingTime = moment
              .utc(totalTalkingTime.asMilliseconds())
              .format("HH:mm:ss");
          } else {
            // Si no existe, asignar la primera entrada
            groupedDataMultiDay[entry.agent] = { ...entry };
          }
        });

        let groupedData: { [key: string]: TcxData } = {};

        if (range.startDate === range.endDate) {
          groupedData = groupedResult;
        } else {
          groupedData = groupedDataMultiDay;
          console.log(groupedData);
        }

        // Convertir el objeto agrupado de nuevo en un array y excluir los agentes en el objeto excludedAgents
        const groupedArray = Object.values(groupedData).sort((a, b) => {
          return a.agent.localeCompare(b.agent);
        });
        setTableData(groupedArray);
        setFilteredData(groupedArray);
        setLoadingText("");
      }
    } catch (error) {
      console.error("Error fetching table data", error);
      Swal.fire("Error", "Failed to load data.", "error");
      setLoadingText("Error al cargar los datos");
    }
  }, [range]);

  const fetchDepartmentFilters = useCallback(async () => {
    try {
      const response = await getDepartmentsNames();
      const departments = response.data.data.map((dep: any) => {
        const name = dep.attributes.name;
        const id = dep.id;
        return { name, id };
      });
      setDepartments(departments);
    } catch (error) {
      console.error("Error fetching department filters", error);
      Swal.fire("Error", "Failed to load department filters.", "error");
    }
  }, []);

  useEffect(() => {
    const handleDepartmentFilter = async (department: string | object) => {
      try {
        // Si department es undefined, null o un objeto vacío, mostrar todos los datos
        if (
          !department ||
          (typeof department === "object" &&
            Object.keys(department).length === 0)
        ) {
          setFilteredData(tableData);
          return;
        }

        // Encontrar los usuarios asociados al departamento seleccionado
        const selectedDepartment = await GETDepartmentById(parseInt(department as string));

        const accounts = selectedDepartment.data.data?.attributes.accounts.data?.map((acc: any) => {
          const firstName = acc.attributes.tcxData?.FirstName;
          const lastName = acc.attributes.tcxData?.LastName;
          return `${firstName} ${lastName}`;
        });

        // Filtrar la tabla por agentes que pertenezcan al departamento seleccionado
        const filtered = tableData.filter((entry) =>
          accounts.includes(entry.agent)
        );

        setFilteredData(filtered);
      } catch (error) {
        console.error("Error filtering by department", error);
        Swal.fire("Error", "Failed to filter by department.", "error");
      }
    };

    // Llamar a la función cuando cambie el filtro
    if (filter) {
      handleDepartmentFilter(filter as string | object);
    }
  }, [filter, tableData, departments]);

  const handleSort = (key: string) => {
    let direction = "asc";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "asc"
    ) {
      direction = "desc";
    }
    setSortConfig({ key, direction });

    const sortedData = [...filteredData].sort((a, b) => {
      if (a[key as keyof TcxData] < b[key as keyof TcxData])
        return direction === "asc" ? -1 : 1;
      if (a[key as keyof TcxData] > b[key as keyof TcxData])
        return direction === "asc" ? 1 : -1;
      return 0;
    });
    setFilteredData(sortedData);
  };

  useEffect(() => {
    fetchDepartmentFilters();
    fetchTableData();
  }, [fetchTableData, fetchDepartmentFilters]);

  const exportToExcel = () => {
    const wb = utils.book_new();
    const ws = utils.json_to_sheet(tableData);
    utils.book_append_sheet(wb, ws, "Sheet1");
    writeFile(wb, "TCXReport.xlsx");
  };
  return (
    <div>
      <section className="content">
        <div className="card">
          <div className="card-header input-group input-group-md row ">
            <div className="col-12 row">
              <div className="col-6">
                <DateTimeRangePicker onRangeChange={handleRangeChange} />
              </div>
              <DepartmentFilter
                filterChange={setFilter}
                options={departments}
                filter={filter}
                className="col-4"
              ></DepartmentFilter>
                <button className="btn btn-primary col-1" onClick={exportToExcel} title="export" style={{margin: "auto"}}>Export</button>
            </div>

          </div>

          <div className="card-body p-0">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th onClick={() => handleSort("agent")}>Agent</th>
                  <th onClick={() => handleSort("inboundAnswered")}>
                    In Answrd
                  </th>
                  <th onClick={() => handleSort("inboundUnanswered")}>
                    In Unanswrd
                  </th>
                  <th onClick={() => handleSort("outboundAnswered")}>
                    Out Answrd
                  </th>
                  <th onClick={() => handleSort("outboundUnanswered")}>
                    Out Unanswrd
                  </th>
                  <th onClick={() => handleSort("totalAnswered")}>
                    Total Answrd
                  </th>
                  <th onClick={() => handleSort("totalUnanswered")}>
                    Total Unanswrd
                  </th>
                  <th onClick={() => handleSort("totalTalkingTime")}>
                    Total Time
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredData.length > 0 ? (
                  filteredData.map((row, index) => (
                    <tr key={index}>
                      <td>{row.agent}</td>
                      <td>{row.inboundAnswered}</td>
                      <td>{row.inboundUnanswered}</td>
                      <td>{row.outboundAnswered}</td>
                      <td>{row.outboundUnanswered}</td>
                      <td>{row.totalAnswered}</td>
                      <td>{row.totalUnanswered}</td>
                      <td>{row.totalTalkingTime}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={9} className="text-center">
                      {loadingText}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
}

export default TcxReport;
*/