import Iframe from 'react-iframe'

import React, { useEffect, useState } from "react";
import Swal from "sweetalert2";
import proxyService from "../../services/proxy.service";
import userService from "../../services/user.service";
import DataTableCh from "../../components/table/DataTableCh";

import "../../assets/css/salesQ.css";

function Screener() { 
  document.title = "Screeners | Consumer Law Group";
  const [dataUsersIn, setDataUsersIn] = useState([{}]);
  const [today, setToday] = useState('');
  const [loading, setLoading] = React.useState(false);

  const user = JSON.parse(localStorage.getItem("userData"));
  const role = user?.role;
  const isGuardian = user?.sugarData.teams.some(
    (team) => team.id === "ab044694-c78b-11ee-b23b-dadc21ba0c54"
  );

  const qStatURL = "https://home.justicialaboral.com/bot_db/api/qStats.php";

  useEffect(() => {
    async function fetchData() {
      try{
        let date = new Date();
        date.setHours(date.getUTCHours() - 5);
        date = date.toISOString().split("T")[0];
        setToday(date);
        const qData = await proxyService.getDataGET(qStatURL);
        const userData = await proxyService.getUsersData();

        const dataIn = await createGlobalData(qData, userData, date, 'all');
        setDataUsersIn(dataIn);

      } catch (error) {
        console.error(error);
      }
    }
    fetchData();
  }, []);

  async function createGlobalData(data, users, end, filter) {
  
    // filtrar los agentes que la fecha no sea la actual.
    const filteredData = data.filter(item => item.last_checked.slice(0, 10) === end);
  
    const checkDate = filteredData[0].last_checked.slice(11, 16);
    const managersExt = [191, 192, 457, 221, 455, 462, 465, 527]

    const flatUsersWithTeam = users.reduce((accumulator, team) => {
      const teamData = team.data.map(user => ({
        ...user,
        team: team.label
      }));
      return accumulator.concat(teamData);
    }, []);
    
    // Exluir Ext de los managers usando el array de managersExt
    const allAgentsFiltered = flatUsersWithTeam.filter(agent =>!managersExt.includes(parseInt(agent.phone_ext_c)))
    // Iterar sobre los agentes del equipo y buscar su estado en qStatsData
    const globalUsersWithTeam = allAgentsFiltered.map(agent => {
      const agentStatus = filteredData.find(item => item.ext === agent.phone_ext_c);
      let formattedDate = "";
      let qStatus = "Deactivated";
  
      if (agentStatus) { // Obtenemos la fecha y hora en formato local
        const isoDateString = agentStatus.last_checked;
        formattedDate = isoDateString.slice(5, 16).replace('T', '-');
        if (agentStatus.top_bucket_status === "0" && agentStatus.bottom_bucket_status === "0") {
          qStatus = "Deactivated";
        // } else if (agentStatus.top_bucket_status === "0" && agentStatus.bottom_bucket_status === "1") {
        //   qStatus = "Only 904 Q";
        // } else if (agentStatus.top_bucket_status === "1" && agentStatus.bottom_bucket_status === "0") {
        //   qStatus = "Only 905 Q";
        } else if (agentStatus.top_bucket_status === "1" && agentStatus.bottom_bucket_status === "1") {  
          qStatus = "Active";
        }
      }
  
      return {
        ...agent,
        qStatus: qStatus,
        lastChecked: agentStatus ? formattedDate : checkDate,
      };
    })
      .sort((a, b) => parseInt(a.phone_ext_c) - parseInt(b.phone_ext_c))
        .filter( item => item.qStatus !== filter)
    return globalUsersWithTeam;
  }

  return (
    <div className='content-wrapper'>
        <Iframe url="https://home.justicialaboral.com/bot_db/screenerFreeTable/"
            position="absolute"
            width="100%"
            id="myId"
            className="myClassname"
            height="100%"
            styles={{height: "850px"}}/>
                <div className="content-wrapper report">
        <div className="report" id="team--performance">

          <div className="title-table-container">
            <h1>Sales In Q</h1>
            <h1 id="dateTitle">{today}</h1>
          </div>

          <div id="team1Table">

          <DataTableCh dataUsersIn={dataUsersIn} loading={loading} />

          </div>

        </div>
    </div>
    </div>
  )
}

export default Screener;

