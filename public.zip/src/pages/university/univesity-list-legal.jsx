import "./University.css";

function UniversityListLegal() {
  const AppLink = ({ href, icon, alt, title, colClass, cardStyle, color }) => {
    return (
      <div className={colClass}>
        <div className={cardStyle}>
          <div className="icon d-flex" style={{ height: "120px" }}>
            <img
              src={icon}
              alt={alt}
              width="70"
              className="m-auto"
              style={{ fill: color }}
            />
          </div>
          <a href={href} className="small-box-footer d-flex">
            <h5 className="m-auto">
              {title}
              <i className="fas fa-arrow-circle-right ml-2" />
            </h5>
          </a>
        </div>
      </div>
    );
  };

  document.title = "University - Legal | CLG";

  return (
    <div>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h1 className="m-0">Users</h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <a href="/">Home</a>
                </li>
                <li className="breadcrumb-item active">CLG University Legal</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <section className="content">
        <div className="container-fluid">
          <div className="center__elements">
            <AppLink
              href="/uLlDoc"
              icon={"img/pdf.png"}
              alt="Adobe Logo"
              title="Documents & Manuals"
              colClass="col-lg-3 col-6"
              cardStyle={"small-box bg-dark"}
            ></AppLink>
            <AppLink
              href="/uLlVideo"
              icon={"img/mp4.png"}
              alt="mp4 Logo"
              title="Trainings Videos"
              colClass="col-lg-3 col-6"
              cardStyle={"small-box bg-navy"}
            ></AppLink>
          </div>
          {/* /.row (main row) */}
        </div>
        {/* /.container-fluid */}
      </section>
      {/* /.content */}
    </div>
  );
}

export default UniversityListLegal;
