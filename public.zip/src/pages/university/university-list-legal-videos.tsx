import React, { useState, useEffect, useMemo } from "react";
import { Data, OrderByLink, InputFilter, Pagination } from '@app/components';
import { getUniversities } from '@app/services/user';

import "./University.css";

// Definir interfaces para las estructuras de datos
interface University {
    name: string;
    url: string;
    link: {
        name: string;
        link: string;
        createdAt: string;
        type: string;
    };
}

interface OrderBy {
    column: string;
    direction: string;
}

interface Filter {
    [key: string]: string | number;
}

function UniversityListLegalVideos() {
  const [data, setData] = useState<University[]>([]);
  const pageSize = 100;
  const page = 1;
  const [filter, setFilter] = useState<Filter>({});
  const [orderBy, setOrderBy] = useState<OrderBy>({
    column: "name",
    direction: "asc",
  });

  const columns = useMemo(
    () => [
      {
        Header: (
          <OrderByLink
            label="Name"
            onClick={setOrderBy}
            order={orderBy}
            column="name"
          />
        ),
        width: "50%",
        accessor: "link",
        component: (props: University['link']) => <RecordLink props={props} />,
      },
      {
        Header: (
          <OrderByLink
            label="Created At"
            onClick={setOrderBy}
            order={orderBy}
            column="createdAt"
          />
        ),
        accessor: "link", // Define el accessor para la propiedad "createdAt"
        width: "25%",
        component: (props: University['link']) => <RecordDate props={props} />,
      },
    ],
    [orderBy]
  );

  useEffect(() => {
    getData(pageSize, page, filter, orderBy);
  }, [pageSize, page, filter, orderBy]);

  const getData = (pageSize: number, page: number, filter: Filter, orderBy: OrderBy) => {
    let filterUri = "";
    Object.keys(filter).forEach((el) => (filterUri += filter[el]));
    const currentPage = filterUri ? 1 : page;

    getUniversities(pageSize, currentPage, filterUri, orderBy, "Legal")
      .then((res) => {
        const newData = res.data.data.map((nt: any) => {
            const name = nt.attributes.name.trim().split(".")[0];
            const type = nt.attributes.name.trim().split(".")[1];
            const url = nt.attributes.url;
            const createdAt = nt.attributes.createdAt.split("T")[0]; // Obtén la propiedad createdAt
            const row: University = {
              name,
              url,
              link: {
                name,
                link: url,
                createdAt,
                type,
              },
            };
            return row;
          })
          .filter((el: University) => el.link.type === "mp4");
        setData(newData);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  function RecordLink({ props }: { props: University['link'] }) {
    const url = `${props.link}`;
    return (
      <div
        style={{
          overflow: "hidden",
          whiteSpace: "nowrap",
          textOverflow: "ellipsis",
          maxWidth: "600px",
        }}
      >
        <a href={url} target="_blank" rel="noopener noreferrer">
          <i
            className={`list__icon fas ${
              props.type === "mp4"
                ? "fa-video"
                : props.type === "pdf"
                ? "fa-file-pdf"
                : ""
            }`}
          />
          {props.name}
        </a>
      </div>
    );
  }

  function RecordDate({ props }: { props: University['link'] }) {
    return <div>{props.createdAt}</div>;
  }

  document.title = "Videos | CLG University Legal";

  return (
    <div >
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-9">
              <InputFilter
                filterChange={setFilter}
                field="name"
                filter={filter}
              ></InputFilter>
            </div>
            <div className="col-sm-3">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <a href="/">Home</a>
                </li>
                <li className="breadcrumb-item">
                  <a href="/university-legal">CLG University Legal</a>
                </li>
                <li className="breadcrumb-item active">Users</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <section className="content">
        <div className="card">
          <div className="card-body p-0">
            <Data columns={columns} data={data}></Data>
          </div>
        </div>
      </section>
    </div>
  );
}

export default UniversityListLegalVideos;
