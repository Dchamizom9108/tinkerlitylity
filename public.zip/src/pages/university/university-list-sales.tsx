import React, { useState, useEffect, useMemo } from "react";
import {
  Data,
  OrderByLink,
  RecordLink,
  InputFilter,
  Pagination,
} from "@app/components";
import { getUniversities } from "@app/services/user";

// Definir interfaces para las estructuras de datos
interface University {
  name: string;
  url: string;
  link: { name: string; link: string };
}

interface OrderBy {
  column: string;
  direction: string;
}

interface Filter {
  [key: string]: string | number;
}

interface PaginationProperties {
  pageIndex: number;
  pageCount: number;
  pageSize: number;
  total: number;
}

function UniversityListSales() {
  const [data, setData] = useState<University[]>([]);
  const [pagination, setPagination] = useState<PaginationProperties>({
    pageIndex: 1,
    pageCount: 0,
    pageSize: 25,
    total: 0,
  });
  const [filter, setFilter] = useState<Filter>({});
  const [orderBy, setOrderBy] = useState<OrderBy>({
    column: "name",
    direction: "asc",
  });

  const columns = useMemo(
    () => [
      {
        Header: (
          <OrderByLink
            label="Name"
            onClick={setOrderBy}
            order={orderBy}
            column="name"
          />
        ),
        width: "30%",
        accessor: "link",
        component: (props: any) => <RecordLink props={props} />,
      },
    ],
    [orderBy]
  );

  useEffect(() => {
    getData(pagination.pageSize, pagination.pageIndex, filter, orderBy);
  }, [pagination.pageSize, pagination.pageIndex, filter, orderBy]);

  const getData = (
    pageSize: number,
    pageIndex: number,
    filter: Filter,
    orderBy: OrderBy
  ) => {
    let filterUri = "";
    Object.keys(filter).forEach(
      (el) => (filterUri = `${filterUri}${filter[el]}`)
    );
    const page = filterUri ? 1 : pageIndex;

    getUniversities(pageSize, page, filterUri, orderBy, "Sales")
      .then((res) => {
        const data = res.data.data.map((nt: any) => {
          const name = nt.attributes.name;
          const url = nt.attributes.url;
          return { name, link: { name, link: url } };
        });
        setData(data);
        setPagination({
          pageIndex: page,
          pageCount: res.data.meta.pagination.pageCount,
          pageSize,
          total: res.data.meta.pagination.total,
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h1 className="m-0">CLG University</h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <a href="/">Home</a>
                </li>
                <li className="breadcrumb-item active">CLG University</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <section className="content">
        <div className="card">
          <div className="card-header input-group input-group-md">
            <InputFilter
              filterChange={setFilter}
              field="name"
              filter={filter}
            />
          </div>
          <div className="card-body p-0">
            <Data
              columns={columns}
              data={data}
            />
          </div>
          <div className="card-footer">
            {pagination.pageCount > 0 && (
              <Pagination
                pagination={pagination}
                setPagination={setPagination}
              />
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

export default UniversityListSales;
