import React from "react";
import Select from "react-select";
import Swal from "sweetalert2";
import { createUniversity } from "@app/services/user";

function UniversityCreate() {
  const [processing, setProcessing] = React.useState(false);
  const [formValues, setFormValues] = React.useState({});

  const departmentType = [
    { value: "Legal", label: "Legal" },
    { value: "Sales", label: "Sales" },
  ];

  const fileType = [
    { value: ".pdf", label: "Document" },
    { value: ".mp4", label: "Video" },
  ];

  const submit = (e) => {
    e.preventDefault();
    setProcessing(true);

    const dataToAPI = {
      name: formValues.name + formValues.type,
      url: formValues.link,
      Department: formValues.department,
    };


    createUniversity({ data: dataToAPI })
      .then((res) => {
        Swal.fire({
          icon: "success",
          title: "Course added successfully",
          showConfirmButton: false,
          timer: 1000,
        })
        setProcessing(false);
      })
      .catch((err) => {
        // console.log(err.response.data.error.message)
        Swal.fire({
          icon: "error",
          title: "Error",
          text: `Error adding the course, please contact the IT team`,
        })
        setProcessing(false);
      });
  };

  const formChange = (e, field) => {
    if (field === "department") {
      e = e.value;
    }

    if (field === "type") {
      e = e.value;
    }

    formValues[field] = e;
    setFormValues(formValues);
  };

  return (
    <>
      <div className="content-wrapper">
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1 className="m-0">Add New Course</h1>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <a href="/">Home</a>
                  </li>
                  <li className="breadcrumb-item active">
                    <a href="/notification">Notifications</a>
                  </li>
                  <li className="breadcrumb-item active">Create</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <section className="content">
          <div className="container-fluid">
            <div className="row">
              <div className="card d-flex col-sm-12">
                <div className="card-body">
                  <form className="" onSubmit={submit}>
                    <div className="form-group row">
                      <label
                        htmlFor="subject"
                        className="col-sm-2 col-form-label"
                      >
                        Name
                      </label>
                      <div className="col-sm-10">
                        <input
                          type="text"
                          className="form-control"
                          id="subject"
                          placeholder="Subject"
                          required
                          onChange={(e) => formChange(e.target.value, "name")}
                        />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label
                        htmlFor="link"
                        className="col-sm-2 col-form-label"
                      >
                        Sharepoint Link
                      </label>
                      <div className="col-sm-10">
                        <input
                          type="text"
                          className="form-control"
                          id="link"
                          placeholder="Link"
                          required
                          onChange={(e) => formChange(e.target.value, "link")}
                        />
                      </div>
                    </div>
                    <div className="form-group row">
                      <label htmlFor="type" className="col-sm-2 col-form-label">
                        Type
                      </label>
                      <div className="col-sm-10">
                        <Select
                          placeholder="Type"
                          isClearable={true}
                          id="type"
                          options={fileType}
                          className="basic-single"
                          classNamePrefix="select"
                          required="true"
                          onChange={(e) => formChange(e, "type")}
                        />
                      </div>
                    </div>

                    <div className="form-group row">
                      <label
                        htmlFor="department"
                        className="col-sm-2 col-form-label"
                      >
                        Department
                      </label>
                      <div className="col-sm-10">
                        <Select
                          placeholder="Department"
                          isClearable={true}
                          id="department"
                          options={departmentType}
                          className="basic-single"
                          classNamePrefix="select"
                          required="true"
                          onChange={(e) => formChange(e, "department")}
                        />
                      </div>
                    </div>

                    <div className="form-group row">
                      <div className="offset-sm-2 col-sm-10">
                        <button
                          type="submit"
                          className="btn btn-danger"
                          disabled={processing}
                        >
                          {processing ? (
                            <i className="fas fa-spinner mr-2 fa-spin"></i>
                          ) : (
                            ""
                          )}
                          Submit
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

export default UniversityCreate;
