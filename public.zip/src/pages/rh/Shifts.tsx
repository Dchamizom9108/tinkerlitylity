import React, { useState, useEffect } from "react";
import {
  GETShifts,
  POSTShift,
  PUTShift,
} from "@app/services/rh"; // Importa los servicios necesarios para las solicitudes a Strapi
import { useAppDispatch } from "@app/store/store";
import { setHeaderNavItems } from "@app/store/reducers/header";

import { Shift } from "@app/types";

const ShiftsPortal: React.FC = () => {
  document.title = "Shifts Portal | CLG";
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingShift, setEditingShift] = useState<Shift | null>(null);
  const [currentShift, setCurrentShift] = useState<Shift | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const dispatch = useAppDispatch();

  const daysOfWeek = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  useEffect(() => {
    dispatch(setHeaderNavItems({ url: '/rh/shifts', text: 'Shifts' }));

    const fetchShifts = async () => {
      setIsLoading(true);
      setError(null);
  
      try {
        const response = await GETShifts();
        const data = response?.data?.data || [];
        const mappedShifts = data
          .map((item: any) => {
            const shift = {
              id: item.id,
              ...item.attributes,
            };
  
            if (shift.rotative) {
              const createdAtDate = new Date(shift.createdAt);
              const currentDate = new Date();
  
              // Compara si los días entre las fechas son impares
              const daysDifference =
                Math.floor(
                  (currentDate.getTime() - createdAtDate.getTime()) /
                    (1000 * 60 * 60 * 24)
                ) % 2;
  
              if (daysDifference === 1) {
                // Alterna los horarios si es impar
                const tempStartTime = shift.timesheet.startTime;
                shift.timesheet.startTime = shift.timesheet.startTimeB || shift.timesheet.endTime;
                shift.timesheet.endTime = shift.timesheet.endTimeB || tempStartTime;
  
                // Alterna el nombre del turno
                if (shift.name.includes("Morning")) {
                  shift.name = shift.name.replace("Morning", "Late");
                  shift.timesheet.startTime = "12:00";
                  shift.timesheet.endTime = "21:00";
                } else if (shift.name.includes("Late")) {
                  shift.name = shift.name.replace("Late", "Morning");
                  shift.timesheet.startTime = "09:00";
                  shift.timesheet.endTime = "18:00";
                }
              }
            }
  
            return shift;
          })
          .filter((shift: Shift) => shift.active);
  
        console.log("Shifts: ", mappedShifts);
        setShifts(mappedShifts);
      } catch (err) {
        console.error("Error fetching shifts: ", err);
        setError("No se pudieron cargar los turnos. Intenta nuevamente.");
      } finally {
        setIsLoading(false);
      }
    };
  
    fetchShifts();
  }, []);
  

  const handleInputChange = (field: keyof Shift, value: any) => {
    setCurrentShift((prev) => (prev ? { ...prev, [field]: value } : null));
  };

  const toggleWorkDay = (day: string) => {
    setCurrentShift((prev) => {
      if (!prev) return null;
      const isWorkDay = prev.timesheet.workDays.includes(day);
      const workDays = isWorkDay
        ? prev.timesheet.workDays.filter((d) => d !== day)
        : [...prev.timesheet.workDays, day];
      const restDays = daysOfWeek.filter((d) => !workDays.includes(d));
      return {
        ...prev,
        timesheet: { ...prev.timesheet, workDays, restDays },
      };
    });
  };

  const handleSubmit = async () => {
    try {
      if (editingShift) {
        // Editar turno existente
        const data = { data: currentShift };
        await PUTShift(editingShift.id!, data);
      } else {
        if (currentShift?.rotative) {
          // Crear dos turnos si es rotativo
          const shiftA = {
            ...currentShift,
            name: `${currentShift.name} A`,
            timesheet: {
              ...currentShift.timesheet,
              startTime: currentShift.timesheet.startTime,
              endTime: currentShift.timesheet.endTime,
            },
          };
  
          const shiftB = {
            ...currentShift,
            name: `${currentShift.name} B`,
            timesheet: {
              ...currentShift.timesheet,
              startTime: "12:00", // Nuevo horario
              endTime: "21:00", // Nuevo horario
            },
          };
  
          // Enviar solicitudes para crear ambos turnos
          await POSTShift({ data: shiftA });
          await POSTShift({ data: shiftB });
        } else {
          // Crear un solo turno si no es rotativo
          const data = { data: currentShift };
          await POSTShift(data);
        }
      }
  
      // Actualizar la lista de turnos
      const response = await GETShifts();
      const mappedShifts = response.data.data.map((item: any) => ({
        id: item.id,
        ...item.attributes,
      }));
      setShifts(mappedShifts);
      setIsCreating(false);
      setEditingShift(null);
      setCurrentShift(null);
    } catch (error) {
      console.error("Error submitting shift: ", error);
    }
  };
  

  const handleEdit = (shift: Shift) => {
    setEditingShift(shift);
    setCurrentShift({ ...shift });
    setIsCreating(true);
  };

  const handleDeactivate = async (shift : any) => {
    try {
      await PUTShift(shift, { data: { active: false } });
      const response = await GETShifts();
      const mappedShifts = response.data.data.map((item: any) => ({
        id: item.id,
        ...item.attributes,
      })).filter((shift: Shift) => shift.active);
      setShifts(mappedShifts);
    } catch (error) {
      console.error("Error deactivating shift: ", error);
    }
  };

  if (isLoading) {
    return <div>Cargando turnos...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="container mt-4">
      {isCreating && currentShift && (
        <form
          className="card p-4"
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
        >
          <h4 className="mb-4">{editingShift ? "Editar Turno" : "Crear Nuevo Turno"}</h4>
  
          <div className="mb-3">
            <label htmlFor="shiftName" className="form-label">
              Nombre del Turno
            </label>
            <input
              id="shiftName"
              type="text"
              className="form-control"
              placeholder="Shift Name"
              value={currentShift.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
            />
          </div>
  
          <div className="mb-3 form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="active"
              checked={currentShift.active}
              onChange={(e) => handleInputChange("active", e.target.checked)}
            />
            <label className="form-check-label" htmlFor="active">
              Activo
            </label>
          </div>
  
          <div className="mb-3 form-check">
            <input
              type="checkbox"
              className="form-check-input"
              id="rotative"
              checked={currentShift.rotative}
              onChange={(e) => handleInputChange("rotative", e.target.checked)}
            />
            <label className="form-check-label" htmlFor="rotative">
              Rotativo
            </label>
          </div>
  
          <div className="row g-3">
            <div className="col-md-6">
              <label htmlFor="startTimeA" className="form-label">
                Hora de Inicio (A)
              </label>
              <input
                id="startTimeA"
                type="time"
                className="form-control"
                value={currentShift.timesheet.startTime}
                onChange={(e) =>
                  handleInputChange("timesheet", {
                    ...currentShift.timesheet,
                    startTime: e.target.value,
                  })
                }
              />
            </div>
  
            <div className="col-md-6">
              <label htmlFor="endTimeA" className="form-label">
                Hora de Fin (A)
              </label>
              <input
                id="endTimeA"
                type="time"
                className="form-control"
                value={currentShift.timesheet.endTime}
                onChange={(e) =>
                  handleInputChange("timesheet", {
                    ...currentShift.timesheet,
                    endTime: e.target.value,
                  })
                }
              />
            </div>
          </div>
  
          {/* {currentShift.rotative && (
            <div className="row g-3 mt-3">
              <div className="col-md-6">
                <label htmlFor="startTimeB" className="form-label">
                  Hora de Inicio (B)
                </label>
                <input
                  id="startTimeB"
                  type="time"
                  className="form-control"
                  value={currentShift.timesheet.startTime || ""}
                  onChange={(e) =>
                    handleInputChange("timesheet", {
                      ...currentShift.timesheet,
                      startTimeB: e.target.value,
                    })
                  }
                />
              </div>
  
              <div className="col-md-6">
                <label htmlFor="endTimeB" className="form-label">
                  Hora de Fin (B)
                </label>
                <input
                  id="endTimeB"
                  type="time"
                  className="form-control"
                  value={currentShift.timesheet.endTime || ""}
                  onChange={(e) =>
                    handleInputChange("timesheet", {
                      ...currentShift.timesheet,
                      endTimeB: e.target.value,
                    })
                  }
                />
              </div>
            </div>
          )} */}
  
          <div className="mb-3">
            <label className="form-label">Días Laborales</label>
            <div className="d-flex flex-wrap gap-2">
              {daysOfWeek.map((day) => (
                <button
                  key={day}
                  type="button"
                  className={`btn ${currentShift.timesheet.workDays.includes(day) ? "btn-success" : "btn-outline-secondary"}`}
                  onClick={() => toggleWorkDay(day)}
                >
                  {day}
                </button>
              ))}
            </div>
          </div>
  
          <div className="d-flex justify-content-end">
            <button type="submit" className="btn btn-primary">
              {editingShift ? "Guardar Cambios" : "Crear Turno"}
            </button>
          </div>
        </form>
      )}
  
      {!isCreating && (
        <button
          onClick={() => {
            setIsCreating(true);
            setCurrentShift({
              id: 0,
              accounts: [],
              name: "new_shift",
              active: true,
              rotative: false,
              timesheet: {
                workDays: [],
                restDays: [],
                startTime: "",
                endTime: "",
              },
            });
          }}
          className="btn btn-primary"
        >
          Crear Nuevo Turno
        </button>
      )}

      <table className="table table-striped mt-4">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Estado</th>
            <th>Días Laborales</th>
            <th>Días de Descanso</th>
            <th>Inicio</th>
            <th>Fin</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {shifts.map((shift) => (
            <tr key={shift.id}>
              <td>
                <a href={`/rh/shifts/${shift.id}`}>{shift.name}</a>
              </td>
              <td>{shift.active ? "Activo" : "Inactivo"}</td>
              <td>{shift.timesheet.workDays.join(", ")}</td>
              <td>{shift.timesheet.restDays.join(", ")}</td>
              <td>{shift.timesheet.startTime}</td>
              <td>{shift.timesheet.endTime}</td>
              <td>
                <button
                  className="btn btn-primary btn-sm me-2"
                  onClick={() => handleEdit(shift)}
                >
                  <i className="fas fa-edit"></i>
                </button>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => {
                    if (window.confirm("¿Deseas desactivar este turno?")) {
                      handleDeactivate(shift.id);
                    }
                  }}
                >
                  <i className="fas fa-times"></i>
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
  
};

export default ShiftsPortal;
