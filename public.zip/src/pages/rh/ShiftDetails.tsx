import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { GETShiftsById, PUTShiftAccount } from "@app/services/rh";
import { getUsersByManager } from "@app/services/user";
import { ShowAlert } from "@app/components";
import { Shift, UserAttributes } from "@app/types";
import { useAppSelector, useAppDispatch } from "@app/store/store";
import { setHeaderNavItems } from "@app/store/reducers/header";
import Select from "react-select";

import { PUTAccountAsignedCalendarRestDays } from "@app/services/time";

const ShiftDetails = () => {
  const paramId = useParams();
  const shiftId = Number(paramId.id) || 0;
  const [shift, setShift] = useState<Shift | null>(null);
  const [users, setUsers] = useState<UserAttributes[]>([]);
  const [availableUsers, setAvailableUsers] = useState<UserAttributes[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null as string | null);

  const [restDays, setRestDays] = useState<string>("");
  const [restUserId, setRestUserId] = useState(0);
  const restOptions = [
    { value: "Monday", label: "Monday" },
    { value: "Tuesday", label: "Tuesday" },
    { value: "Wednesday", label: "Wednesday" },
    { value: "Thursday", label: "Thursday" },
    { value: "Friday", label: "Friday" },
    { value: "Saturday", label: "Saturday" },
    { value: "Sunday", label: "Sunday" },
  ];

  const daysOfWeek = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];

  const dispatch = useAppDispatch();

  const actualUser = useAppSelector((state) => state.auth.currentUser);

  useEffect(() => {
    dispatch(setHeaderNavItems({ url: "/rh/shifts", text: "Shifts" }));
  
    const fetchShiftDetails = async () => {
      try {
        const shiftData = await GETShiftsById(shiftId);

        if (shiftData.rotative) {
          const createdAtDate = new Date(shiftData.createdAt);
          const currentDate = new Date();

          // Compara si los días entre las fechas son impares
          const daysDifference =
            Math.floor(
              (currentDate.getTime() - createdAtDate.getTime()) /
                (1000 * 60 * 60 * 24)
            ) % 2;

          if (daysDifference === 1) {
            // Alterna los horarios si es impar
            const tempStartTime = shiftData.timesheet.startTime;
            shiftData.timesheet.startTime = shiftData.timesheet.startTimeB || shiftData.timesheet.endTime;
            shiftData.timesheet.endTime = shiftData.timesheet.endTimeB || tempStartTime;

            // Alterna el nombre del turno
            if (shiftData.name.includes("Morning")) {
              shiftData.name = shiftData.name.replace("Morning", "Late");
              shiftData.timesheet.startTime = "12:00";
              shiftData.timesheet.endTime = "21:00";
            } else if (shiftData.name.includes("Late")) {
              shiftData.name = shiftData.name.replace("Late", "Morning");
              shiftData.timesheet.startTime = "09:00";
              shiftData.timesheet.endTime = "18:00";
            }
          }
        }
  
        document.title = shiftData.name + " | CLG";
  
        setShift(shiftData);
  
        const formattedInitialAccounts = shiftData?.accounts.data
          .map((account: any) => {
            const restDays = account.attributes.asignedCalendar;
  
            // Obtener la fecha de hoy y el inicio y fin de la semana actual (lunes a domingo)
            const today = new Date();
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay() + 1); // Mover al lunes
            const endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(startOfWeek.getDate() + 6); // Mover al domingo
  
            // Filtrar los días de la semana actual en el calendario
            const currentWeekDays = Object.entries(restDays).filter(([dateKey]) => {
              const date = new Date(dateKey);
              return date >= startOfWeek && date <= endOfWeek;
            });
  
            // Buscar el primer día con `work: false` en la semana actual
            const restDayKey = currentWeekDays.find(([_, dayData]) => dayData.work === false)?.[0];
  
            // Convertir la fecha a un día de la semana (Ej. "Jueves")
            let restDayString = "";
            if (restDayKey) {
              const date = new Date(restDayKey);
              restDayString = daysOfWeek[date.getDay()];
            }
  
            if (account.id === 4391) {
              console.log("restDayString", restDayString, "user", account);
            }
  
            return {
              id: account.id,
              firstName: account.attributes.firstName,
              lastName: account.attributes.lastName,
              email: account.attributes.email,
              name: `${account.attributes.firstName.split(" ")[0]} ${account.attributes.lastName.split(" ")[0]}`,
              restDay: restDayString, // Día de descanso
            };
          })
          .sort((a: any, b: any) => {
            return a.name.localeCompare(b.name);
          });
  
        console.log("formattedInitialAccounts", formattedInitialAccounts);
  
        setUsers(formattedInitialAccounts || []);
  
        const availableResponse = await getUsersByManager(actualUser?.user.account.id);
  
        const filteredAvailableUsers = availableResponse
          .filter((user: any) => {
            return !formattedInitialAccounts.some(
              (initialAccount: any) => initialAccount.id === user.id
            );
          })
          .sort((a: any, b: any) => {
            return a.name.localeCompare(b.name);
          });
  
        const filteredCalendarActiveAccounts = filteredAvailableUsers.filter(
          // Filtrar usuarios con calendario asignado y que incluyan la fecha de hoy
          (user: any) => {
            const today = new Date().toISOString().split("T")[0];
            return !user?.asignedCalendar || !user.asignedCalendar[today];
          }
        );
  
        setAvailableUsers(filteredCalendarActiveAccounts || []);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching shift details:", err);
        setError("No se pudieron cargar los detalles del turno.");
      }
    };
    if (loading) {
      fetchShiftDetails();
    }
  }, [shiftId, loading]);
  

  const handleAddUser = async (userId: number) => {
    try {
      const response: any = shift;

      const shiftUsers = response?.accounts.data.map(
        (account: any) => account.id
      );
      const calendar = response?.timesheet;

      const updatedAccounts = [...shiftUsers, userId];

      const resPut = await PUTShiftAccount(
        shiftId,
        updatedAccounts,
        userId,
        "add",
        calendar
      );
      if (resPut?.status === 200) {
        setLoading(true);
      } else {
        ShowAlert("error", "Error", "No se pudo agregar el usuario al turno");
      }
    } catch (err) {
      console.error("Error adding user to shift:", err);
      ShowAlert("error", "Error", "No se pudo agregar el usuario al turno");
    }
  };

  const handleRemoveUser = async (userId: number) => {
    try {
      const response: any = shift;

      const updatedAccounts = response?.accounts.data
        .filter((account: any) => account.id !== userId)
        .map((account: any) => account.id);
      const putRes = await PUTShiftAccount(
        shiftId,
        updatedAccounts,
        userId,
        "remove",
        response?.timesheet
      );

      if (putRes?.status === 200) {
        setLoading(true);
      }
    } catch (err) {
      console.error("Error removing user from shift:", err);
      ShowAlert("error", "Error", "No se pudo eliminar el usuario del turno");
    }
  };

  const handleSaveRestDays = async (id: number) => {
    try {
      const res = await PUTAccountAsignedCalendarRestDays(id, restDays);
      if (res?.status === 200) {
        setRestUserId(0);
        const shiftData = await GETShiftsById(shiftId);

        document.title = shiftData.name + " CLG";

        setShift(shiftData);

        const formattedInitialAccounts = shiftData?.accounts.data
          .map((account: any) => {
            const restDays = account.attributes.asignedCalendar;

            // Buscar el primer día con `work: false`
            const restDayKey = Object.keys(restDays).find(
              (date) => restDays[date].work === false
            );

            // Convertir la fecha a un día de la semana (Ej. "Sábado")
            let restDayString = "";
            if (restDayKey) {
              const date = new Date(restDayKey);
              restDayString = daysOfWeek[date.getDay()];
            }

            return {
              id: account.id,
              firstName: account.attributes.firstName,
              lastName: account.attributes.lastName,
              email: account.attributes.email,
              name: `${account.attributes.firstName.split(" ")[0]} ${account.attributes.lastName.split(" ")[0]}`,
              restDay: restDayString, // Día de descanso
            };
          })
          .sort((a: any, b: any) => {
            return a.name.localeCompare(b.name);
          });

        setUsers(formattedInitialAccounts || []);
      } else {
        ShowAlert("error", "Error", "No se pudo actualizar el dia de descanso");
      }
    } catch (err) {
      console.error("Error removing user from shift:", err);
      ShowAlert("error", "Error", "No se pudo actualizar el dia de descanso");
    }
  };

  if (loading) return <div>Cargando...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container">
      <div className="card">
        <div className="card-header">
          <h1 style={{ textAlign: "center" }}>{shift?.name}</h1>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <p>
              <strong>Rotativo:</strong> {shift?.rotative ? "Sí" : "No"}
            </p>
            <p>
              <strong>Horario:</strong> {shift?.timesheet.startTime} -{" "}
              {shift?.timesheet.endTime}
            </p>
            <p>
              <strong>Días Laborales:</strong>{" "}
              {shift?.timesheet.workDays.join(", ")}
            </p>
            <p>
              <strong>Días de Descanso:</strong>{" "}
              {shift?.timesheet.restDays.join(", ")}
            </p>
          </div>
        </div>

        <div className="card-body">
          <h2>Usuarios</h2>
          <ul
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
              gap: "15px",
              listStyle: "none",
              padding: 0,
            }}
          >
            {users.map((user) => (
              <li key={user.id}>
                <div className="card">
                  <div className="card-body">
                    <h5 className="card-title">{user.name}</h5>
                  </div>
                  <div
                    className="card-footer"
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      justifyContent: "space-between",
                    }}
                  >
                    {user.id === restUserId ? ( // Verificar si estamos editando este usuario
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "row",
                          gap: "10px",
                          width: "100%",
                          justifyContent: "space-between",
                        }}
                      >
                        <Select
                          placeholder={user.restDay}
                          id="deactivationType"
                          name="deactivationType"
                          options={restOptions}
                          onChange={(e: any) => setRestDays(e.value)}
                          className="dchm2-select"
                        />

                        <button
                          className="btn btn-primary"
                          onClick={() => {
                            handleSaveRestDays(user.id); // Guardar los cambios
                          }}
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <>
                        <button
                          className="btn btn-primary"
                          onClick={() => setRestUserId(user.id)} // Entrar en modo edición
                        >
                          Edit
                        </button>
                        <button
                          className="btn btn-danger"
                          onClick={() => handleRemoveUser(user.id)} // Eliminar usuario
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        <div className="card-footer">
          <h2>Usuarios Disponibles</h2>
          <ul
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
              gap: "15px",
              listStyle: "none",
              padding: 0,
            }}
          >
            {availableUsers.map((user) => (
              <li
                key={user.id}
                style={{
                  padding: "10px 15px",
                  borderRadius: "5px",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.3)" /* Sombra ligera */,
                }}
              >
                {user.name}{" "}
                <button
                  onClick={() => handleAddUser(user.id)}
                  style={{
                    backgroundColor: "green",
                    color: "white",
                    border: "none",
                    padding: "5px 10px",
                    borderRadius: "5px",
                  }}
                >
                  Agregar
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ShiftDetails;
