import { useState, useEffect, useCallback } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { GETDepartmentCalendar, getDepartmentsNames } from "@app/services/user";
import { UserAttributes, DepartmentsType } from "@app/types";

import { DepartmentFilter } from "@app/components";

interface EventsType {
  title: string;
  start: string;
  extendedProps: any;
}

const DepCalendar = () => {
  const [depId, setDepId] = useState(82);
  const [department, setDepartment] = useState<DepartmentsType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [events, setEvents] = useState<EventsType[]>([]);
  const [noCalendarUsers, setNoCalendarUsers] = useState<UserAttributes[]>([]);
  const [dayDetails, setDayDetails] = useState<any>(null); // Detalle del día seleccionado

  useEffect(() => {
    const fetchCalendarView = async () => {
      try {
        const response = await GETDepartmentCalendar(depId);
        document.title = `${response.data.data.attributes.name} - Calendar`;

        const formattedAccounts =
          response.data.data.attributes.accounts.data.map((account: any) => ({
            id: account.id,
            firstName: account.attributes.firstName,
            lastName: account.attributes.lastName,
            email: account.attributes.email,
            name: `${account.attributes.firstName.split(" ")[0]} ${account.attributes.lastName.split(" ")[0]}`,
            calendar: account.attributes.asignedCalendar || {},
          }));

        const usersWithNoCalendar = formattedAccounts.filter(
          (account: any) =>
            !account.calendar || Object.keys(account.calendar).length === 0
        );

        setNoCalendarUsers(usersWithNoCalendar);

        const formattedEvents = Object.entries(
          formattedAccounts.reduce((acc: any, account: any) => {
            Object.entries(account.calendar).forEach(
              ([date, shift]: [string, any]) => {
                acc[date] = acc[date] || {
                  working: 0,
                  resting: 0,
                  morning: 0,
                  afternoon: 0,
                  vacation: 0,
                  users: [],
                };

                if (shift.work) {
                  acc[date].working += 1;
                  shift.startwork === "09:00:00 AM" && (acc[date].morning += 1);
                  shift.startwork === "12:00:00 PM" &&
                    (acc[date].afternoon += 1);
                  acc[date].users.push({ ...account, shift });
                } else {
                  acc[date].resting += 1;
                  if (shift.motive === "vacation") {
                    acc[date].vacation += 1;
                  }
                  acc[date].users.push({ ...account, shift });
                }
              }
            );
            return acc;
          }, {})
        ).map(([date, data]: [string, any]) => ({
          title: `W: ${data.working}, R: ${data.resting}, M: ${data.morning}, A: ${data.afternoon}`,
          start: date,
          // color: data.working > 0 ? "green" : "red",
          extendedProps: data, // Pasar detalles para interacción
        }));

        setEvents(formattedEvents);
      } catch (err) {
        console.error("Error fetching shift details:", err);
        setError("No se pudieron cargar los detalles del turno.");
      } finally {
        setLoading(false);
      }
    };

    fetchCalendarView();
  }, [depId]);

    const fetchDepartmentFilters = useCallback(async () => {
      try {
        const response = await getDepartmentsNames();
        const departments = response.data.data.map((dep: any) => {
          const name = dep.attributes.name;
          const id = dep.id;
          return { name, id };
        }).filter((dep: any) => {
          // filtrar departamentos que incluyan la palabra "sales" o "p1"
          return dep.name.toLowerCase().includes("sales") || dep.name.toLowerCase().includes("p1");
        });
        setDepartment(departments);
      } catch (error) {
        console.error("Error fetching department filters", error);
      }
    }, []);
  
    useEffect(() => {
      fetchDepartmentFilters();
    }, [fetchDepartmentFilters]);

  const handleDayClick = (info: any) => {
    const clickedDay = events.find(
      (event: any) => event.start === info.dateStr
    )?.extendedProps;
    setDayDetails(clickedDay || null);
  };

  if (loading) return <div>Cargando...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container">
      <div className="card">
          <div className="card-header input-group input-group-md row" style={{ display: "flex", justifyContent: "space-between" }}>
            <h3>Calendar View: </h3>
            <div className="row col-8">
              <DepartmentFilter
                filterChange={setDepId}
                options={department}
                filter={depId}
                className="col-4"
              ></DepartmentFilter>
            </div>
          </div>

      {noCalendarUsers.length > 0 && !dayDetails ? (
        <div className="card-body">
          <h3>Usuarios sin calendario asignado</h3>

          <ul>
            {noCalendarUsers.map((user) => (
              <li key={user.id}>
                {user.name} - {user.email}
              </li>
            ))}
          </ul>
        </div>
      ) : (
        ""
      )}

      {dayDetails && (
        <div className="card">
          <div
            className="card-header"
            style={{ display: "flex", justifyContent: "space-between" }}
          >
            <h4>Detalles del Día: {dayDetails.date}</h4>
            <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
              <i className="fas fa-print"></i>
              <i
                className="fas fa-times"
                onClick={() => setDayDetails(null)}
              ></i>
            </div>
          </div>

          <h4>Trabajando:</h4>
          <ul>
            {dayDetails.users
              .filter((user: any) => user.shift.work)
              .map((user: any) => (
                <li key={user.id}>
                  {user.name} - {user.shift.startwork} a {user.shift.endwork}
                </li>
              ))}
          </ul>
          <h4>Descansando:</h4>
          <ul>
            {dayDetails.users
              .filter((user: any) => !user.shift.work)
              .map((user: any) => (
                <li key={user.id}>
                  {user.name} - {user.shift.motive || "Descanso"}
                </li>
              ))}
          </ul>
        </div>
      )}

      </div>

      <FullCalendar
        plugins={[dayGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        showNonCurrentDates={false}
        headerToolbar={{
          left: "prev,next",
          center: "title",
          right: "dayGridMonth",
        }}
        events={events}
        editable={true}
        dateClick={handleDayClick}
        locale="es"
        aspectRatio={2}
      />
    </div>
  );
};

export default DepCalendar;