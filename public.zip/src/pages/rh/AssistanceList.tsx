import { useState, useEffect, useRef } from "react";
import { getUsersDayLogsByManager } from "@app/services/rh";
import { GETMyselfUserData } from "@app/services/rh";
import { Form, Table, Row, Col, Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faChevronDown,
  faChevronUp,
  faCopy,
  faFileCsv,
} from "@fortawesome/free-solid-svg-icons";
import { toPng } from "html-to-image";
import * as XLSX from "xlsx";
import { ShowAlert } from "@app/components";
import { Select } from "@profabric/react-components";

interface User {
  id: number;
  name: string;
  email: string;
  asignedCalendar: {
    [date: string]: {
      work: boolean;
      startwork?: string;
      endwork?: string;
      logs?: any[];
    };
  };
}

interface UserSummary {
  name: string;
  late: number;
  onTime: number;
  noLogs: number;
  details: { date: string; logs: any[]; startwork?: string; endwork?: string }[];
}

const AssistanceList = () => {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [dateRange, setDateRange] = useState<{ start: string; end: string }>({
    start: new Date().toISOString().split("T")[0],
    end: new Date().toISOString().split("T")[0],
  });
  const [filteredUsers, setFilteredUsers] = useState<UserSummary[]>([]);
  const [expandedUsers, setExpandedUsers] = useState<{ [key: string]: boolean }>({});

  const tableRefs = {
    resting: useRef<HTMLTableElement>(null),
    extraTurn: useRef<HTMLTableElement>(null),
    onTime: useRef<HTMLTableElement>(null),
    noLogs: useRef<HTMLTableElement>(null),
    incidences: useRef<HTMLTableElement>(null),
  };

  const [departmentsManaged, setDepartmentsManaged] = useState<string[]>([]);
  const [departments, setDepartments] = useState<string[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const actualUser = await GETMyselfUserData();
        const usersManaged = await getUsersDayLogsByManager(actualUser?.id || 0);
        setUsers(usersManaged);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching data", error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (users.length > 0) {
      filterDataByDateRange(dateRange.start, dateRange.end);
    }
  }, [dateRange, users]);

  const filterDataByDateRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);

    const userSummaryMap: { [key: string]: UserSummary } = {};

    users.forEach((user) => {
      Object.keys(user.asignedCalendar).forEach((date) => {
        const currentDate = new Date(date);
        if (currentDate >= start && currentDate <= end) {
          const calendarEntry = user.asignedCalendar[date];
          if (calendarEntry) {
            if (!userSummaryMap[user.id]) {
              userSummaryMap[user.id] = {
                name: user.name,
                late: 0,
                onTime: 0,
                noLogs: 0,
                details: [],
              };
            }

            const logs = calendarEntry.logs || [];
            const hasLate = logs.some((log) => log.status === "Late");
            const hasOnTime = logs.length > 0 && logs.every((log) => log.status === "OnTime");

            if (hasLate) {
              userSummaryMap[user.id].late += 1;
            } else if (hasOnTime) {
              userSummaryMap[user.id].onTime += 1;
            } else if (!logs.length) {
              userSummaryMap[user.id].noLogs += 1;
            }

            userSummaryMap[user.id].details.push({
              date,
              logs,
              startwork: calendarEntry.startwork,
              endwork: calendarEntry.endwork,
            });
          }
        }
      });
    });

    setFilteredUsers(Object.values(userSummaryMap));
  };

  const handleDateRangeChange = (e: React.ChangeEvent<HTMLInputElement>, type: "start" | "end") => {
    setDateRange((prev) => ({
      ...prev,
      [type]: e.target.value,
    }));
  };

  const toggleUserDetails = (userId: string) => {
    setExpandedUsers((prev) => ({
      ...prev,
      [userId]: !prev[userId],
    }));
  };

  const copyTableImage = async (tableRef: React.RefObject<HTMLTableElement>) => {
    if (tableRef.current) {
      try {
        const dataUrl = await toPng(tableRef.current);
        const blob = await (await fetch(dataUrl)).blob();
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": blob }),
        ]);
        ShowAlert("success", "Imagen copiada", "");
      } catch (error) {
        console.error("Error al copiar la imagen:", error);
      }
    }
  };

  const exportTableToCSV = (tableRef: React.RefObject<HTMLTableElement>, fileName: string) => {
    if (tableRef.current) {
      const table = tableRef.current;
      const ws = XLSX.utils.table_to_sheet(table);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
      XLSX.writeFile(wb, `${fileName}.csv`);
    }
  };

  if (loading) return <div>Cargando...</div>;

  return (
    <div className="container mt-4">
      <div className="mb-4">
      
        <Row><h2>Incidencias</h2>
          <Col md={3}> 
            <Form.Control
              type="date"
              value={dateRange.start}
              onChange={(e) => handleDateRangeChange(e, "start")}
            />
          </Col>
          <Col md={3}>
            <Form.Control
              type="date"
              value={dateRange.end}
              onChange={(e) => handleDateRangeChange(e, "end")}
            />
          </Col>
        </Row>
      </div>

      {/* Tabla de Incidencias */}
      <div className="mb-4">
        
        <Table striped bordered hover ref={tableRefs.incidences} style={{ fontWeight: "bold", textAlign: "center" }}>
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Llegadas Tarde</th>
              <th>Puntuales</th>
              <th>Sin Registro</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map((user) => (
              <>
                <tr key={user.name} onClick={() => toggleUserDetails(user.name)} style={{ cursor: "pointer" }}>
                  <td>{user.name}</td>
                  <td>{user.late}</td>
                  <td>{user.onTime}</td>
                  <td>{user.noLogs}</td>
                </tr>
                {expandedUsers[user.name] && (
                  <tr>
                    <td colSpan={4}>
                      <Table style={{ fontWeight: "bold", textAlign: "center" }}>
                        <thead>
                          <tr>
                            <th>Fecha</th>
                            <th>Horario</th>
                            <th>Logs</th>
                          </tr>
                        </thead>
                        <tbody>
                          {user.details.map((detail, index) => {
                            const hasLate = detail.logs.some((log) => log.status === "Late");
                            const hasOnTime = detail.logs.length > 0 && detail.logs.every((log) => log.status === "OnTime");
                            const noLogs = detail.logs.length === 0;

                            let backgroundColor = "";
                            if (noLogs) {
                              backgroundColor = "#ffa500"; // Naranja
                            } else if (hasOnTime) {
                              backgroundColor = "#1a9b1a"; // Verde
                            } else if (hasLate) {
                              backgroundColor = "#CF2B28"; // Rojo
                            }

                            return (
                              <tr key={index} style={{ backgroundColor }}>
                                <td>{detail.date}</td>
                                <td>
                                  {detail.startwork} - {detail.endwork}
                                </td>
                                <td>
                                  {detail.logs.map((log, logIndex) => (
                                    <div key={logIndex}>
                                      <strong>Tipo:</strong> {log.typeOfLog},{" "}
                                      <strong>Hora:</strong> {log.setAt},{" "}
                                      <strong>Estado:</strong> {log.status}
                                    </div>
                                  ))}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </Table>
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </Table>
      </div>
    </div>
  );
};

export default AssistanceList;