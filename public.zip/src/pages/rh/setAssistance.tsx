import { useState, useEffect } from "react";
import { ShowAlert, Timeline } from "@app/components";
import {
  getToday,
  getMonthName,
  userTimeCheck,
  getTimeDifferenceInMinutes,
  formatTime,
} from "@app/services/time";
import {
  POSTDayLog,
  GETUserDayLogs,
  fetchIp,
  PUTDayLogs,
  GETDayLogs,
  GETMyselfUserData,
} from "@app/services/rh";
import Select from "react-select";

import styles from "./setLog.module.css";
import { UserAttributes, LogEntries, OptionType } from "@app/types";

import { logout } from "@app/services/auth";

const officeLocations = [ '200.94.89.11', '209.35.184.107' ];

const useUserData = () => {
  const [userData, setUserData] = useState<UserAttributes | null>(null);
  const [userLoaded, setUserLoaded] = useState(false);
  const [ip, setIp] = useState("");
  const [userId, setUserId] = useState<number>(0);
  const [userLocation , setUserLocation] = useState<string>("");

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userData = await GETMyselfUserData();
        setUserData(userData);
        setUserId(userData.id);
        const localIP = await fetchIp();
        setIp(localIP);
        if (officeLocations.includes(localIP)) {
          setUserLocation("Office");
        } else {
          setUserLocation("Home");
        }
        setUserLoaded(true);
      } catch (error) {
        console.error(error);
        ShowAlert(
          "error",
          "Error getting user data",
          "PLASE CONTACT THE ADMINISTRATOR"
        )
        await new Promise((resolve) => setTimeout(resolve, 2000));
        logout();
      }
    };

    if (!userLoaded) {
      fetchUserData();
    }
  }, [userLoaded]);

  // each 2 min set null to force reload
  useEffect(() => {
    const interval = setInterval(() => {
      setUserData(null);
      setUserLoaded(false);
    }, 120000);
  })

  return { userData, userLoaded, ip, userId, userLocation };
};

const SetAssistance = () => {
  const { userData, userLoaded, ip, userId, userLocation } = useUserData();
  const [user_asistLog_Id, setUser_asistLog_Id] = useState<number | null>(null);
  const [logOptions, setLogOptions] = useState<OptionType[]>([]);
  const [selectedLogType, setSelectedLogType] = useState<string>("");
  const [todayLogsData, setTodayLogsData] = useState<LogEntries | null>(null);
  const [endOfDay, setEndOfDay] = useState(false);
  const [resting, setResting] = useState(false);
  const [restingTime, setRestingTime] = useState<number | null>(null);

  useEffect(() => { // Inicia el temporizador de descanso si `resting` es verdadero
    let timer: any;
    if (resting && restingTime !== null) {
      timer = setInterval(() => {
        setRestingTime((prevCountdown: any) =>
          prevCountdown !== null ? parseInt(prevCountdown) - 1 : 0
        );
      }, 1000);
    }

    //auto refresh this page every 2 minutes
    setInterval(() => {
      console.log('refreshing page');
      window.location.reload();
    }, 190000);

    return () => clearInterval(timer); // Limpia el intervalo al desmontar o al cambiar `resting` o `countdown`
  }, [resting, restingTime]);

  useEffect(() => { // Función para obtener el id asistlogs si no existe lo crea
    const GETasistlogId = async () => {
      try {
        const user = userData as UserAttributes;
        const time =
          getToday("time") ||
          new Date().toISOString().split("T")[1].split(".")[0];
        const date = getToday("date") || new Date().toISOString().split("T")[0];
        const month = getMonthName(date);

        let dayLogs = await GETUserDayLogs(user.id);

        if (dayLogs.length > 0) {
          const dayLogId = dayLogs[0].id;
          setUser_asistLog_Id(dayLogId);

          const logsData = dayLogs[0]?.attributes || {};
          const monthLogs = logsData[month] || {}; // Logs del mes actual
          const todayLogs = monthLogs[date] || null; // Logs del día actual

          if (todayLogs === null) {
            const status = await userTimeCheck(
              "startShift",
              {},
              userData as UserAttributes
            );
            const data = {
              ...logsData,
              [month]: {
                ...monthLogs,
                [date]: {
                  1: {
                    typeOfLog: "startShift",
                    setAt: time,
                    status: status,
                    ip: ip,
                  },
                },
              },
            };

            const response = await PUTDayLogs(dayLogId, data); // Realiza la solicitud para actualizar el log de asistencia
            console.log(response, month, date);
            ShowAlert("success", "Start Shift log created successfully", "");
            manageSelectedLogType(response?.data.data.attributes[month][date] || {});
          } else {
            manageSelectedLogType(todayLogs);
          }
        } else {
          const status = await userTimeCheck( "startShift", {}, userData as UserAttributes );

          // GET data from the API
          const userAssistanceLog = {
            data: {
              [month]: {
                [date]: {
                  1: {
                    typeOfLog: "startShift",
                    setAt: time,
                    status: status,
                    ip: ip,
                  },
                },
              },
              accounts: user.id,
            },
          };

          const postResponse = await POSTDayLog(userAssistanceLog);

          if (postResponse.status === 200) {
            ShowAlert("success", "Start Shift log created successfully", "");
            window.location.reload();
          } else {
            ShowAlert(
              "error",
              "Error creating the log",
              "PLASE CONTACT THE ADMINISTRATOR"
            );
          }
        }
      } catch (error) {
        console.log(error);
        ShowAlert(
          "error",
          "Error creating the log",
          "PLASE CONTACT THE ADMINISTRATOR"
        )
        await new Promise((resolve) => setTimeout(resolve, 15000));
        console.log('this 4');
        // logout();
      }
    };
    if (userLoaded) {
      GETasistlogId();
    }
  }, [userLoaded, ip]);

  /* ///////////////////////////////////////////////////////////// */
  /* ///////////////////////// FUNCIONES ///////////////////////// */
  /* ///////////////////////////////////////////////////////////// */

  async function manageSelectedLogType(logEntries: LogEntries) {
    try {
    const logValues = Object.values(logEntries).map((entry) => entry.typeOfLog);
    const lastLog = logValues[logValues.length - 1];
    const endShiftCount = logValues.filter((log) => log === "endShift").length;

    setEndOfDay(endShiftCount > 0);

    let filteredLogTypes = [
      { value: "startBreak", label: "Start Break" },
      { value: "endBreak", label: "End Break" },
      { value: "startLunch", label: "Start Lunch" },
      { value: "endLunch", label: "End Lunch" },
      { value: "endShift", label: "End Shift" },
    ];

    const lastLogTime = Object.values(logEntries).pop()?.setAt;
    const currentTime = getToday("time") || new Date().toISOString().split("T")[1].split(".")[0];
    const timeDiff = getTimeDifferenceInMinutes(
      currentTime,
      lastLogTime || currentTime
    );

    const logActions: any = { // Lógica basada en el último tipo de log
      startBreak: () => {
        filteredLogTypes = filterLogTypes(filteredLogTypes, ["endBreak"]);
        setResting(true);
        setRestingTime((10 - timeDiff) * 60);
      },
      startLunch: () => {
        filteredLogTypes = filterLogTypes(filteredLogTypes, ["endLunch"]);
        setResting(true);
        setRestingTime((60 - timeDiff) * 60);
      },
      startShift: () => {
        filteredLogTypes = filterLogTypes(filteredLogTypes, [
          "endShift",
          "startBreak",
          "startLunch",
        ]);
      },
      endBreak: () => {
        filteredLogTypes = filterLogTypes(filteredLogTypes, [
          "startBreak",
          "startLunch",
          "endShift",
        ]);
        resetRestingState();
      },
      endLunch: () => {
        filteredLogTypes = filterLogTypes(filteredLogTypes, [
          "startBreak",
          "endShift",
        ]);
        resetRestingState();
      },
    };

    if (lastLog && logActions[lastLog]) {
      logActions[lastLog]();
    }

    if (hasBothLogs(logValues, "startLunch", "endLunch")) {
      filteredLogTypes = excludeLogTypes(filteredLogTypes, [
        "startLunch",
        "endLunch",
      ]);
    }

    if (hasExcessiveLogs(logValues, "startBreak", "endBreak", 3)) {
      filteredLogTypes = excludeLogTypes(filteredLogTypes, [
        "startBreak",
        "endBreak",
      ]);
    }

    setTodayLogsData(logEntries);
    setLogOptions(filteredLogTypes);

    await new Promise((resolve) => setTimeout(resolve, 2000));
    // window.location.reload();

    } catch (error) {
      console.log(error);
      ShowAlert("error", "Error creating the log", "PLASE CONTACT THE ADMINISTRATOR");
    }
  }

  const filterLogTypes = (logTypes : any, allowedTypes : any) => logTypes.filter((logType : any) => allowedTypes.includes(logType.value));
  const excludeLogTypes = (logTypes : any, excludedTypes : any) => logTypes.filter((logType : any) => !excludedTypes.includes(logType.value));
  const hasBothLogs = (logValues : any, logA : any, logB : any) => logValues.includes(logA) && logValues.includes(logB);
  const hasExcessiveLogs = (logValues : any, logA : any, logB : any, limit : any) =>
    logValues.filter((log : any) => log === logA).length >= limit &&
    logValues.filter((log : any) => log === logB).length >= limit;

  const resetRestingState = () => {
    setResting(false);
    setRestingTime(null);
  };

  async function PUTdata_asistLog(dayLogId: number) {
    try {
      const time = getToday("time") || new Date().toISOString().split("T")[1].split(".")[0];
      const date = getToday("date") || new Date().toISOString().split("T")[0];
      const month = getMonthName(date).toLowerCase(); // Ej: "dec"
      const ip = await fetchIp();

      const assistLogs = await GETDayLogs(dayLogId);
      const logsData = assistLogs?.data?.data?.attributes || {};
      const monthLogs = logsData[month] || {}; // Logs del mes actual
      const todayLogs = monthLogs[date] || null; // Logs del día actual
      const logCount = Object.keys(todayLogs).length;

      const status = await userTimeCheck(
        selectedLogType,
        todayLogs,
        userData as UserAttributes
      );

      const newLog = {
        typeOfLog: selectedLogType,
        setAt: time,
        status: status,
        ip: ip,
      };

      const data = {
        ...logsData,
        [month]: {
          ...monthLogs,
          [date]: {
            ...todayLogs,
            [logCount + 1]: newLog,
          },
        },
      };

      const createAssistanceDayLog = await PUTDayLogs(dayLogId, data);

      return createAssistanceDayLog?.status || null;
    } catch (error) {
      console.log(error);
      await new Promise((resolve) => setTimeout(resolve, 1000));
      // logout();
    }
  }

  async function handleSubmit() {
    try {
      if (user_asistLog_Id === null) {
        ShowAlert(
          "error",
          "Error creating the log",
          "PLASE CONTACT THE ADMINISTRATOR"
        )
      } else {
        const set2 = await PUTdata_asistLog(user_asistLog_Id);

        if (set2 === 200) {
          ShowAlert("success", "Log created successfully", "");
          // segun el tipo de log, redirigir a la pagina correspondiente usando case
          switch (selectedLogType) {
            case "startBreak":
              setResting(true);
              setRestingTime(10 * 60);
              break;
            case "endBreak":
              setResting(false);
              setRestingTime(null);
              break;
            case "startLunch":
              setResting(true);
              setRestingTime(60 * 60);
              break;
            case "endLunch":
              setResting(false);
              setRestingTime(null);
              break;
            case "endShift":
              setEndOfDay(true);
              break;
          }

          window.location.reload();
        } else {
          ShowAlert(
            "error",
            "Error creating the log",
            "PLASE CONTACT THE ADMINISTRATOR"
          );
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div style={{ backgroundColor: "#0a233a",
      height: "90vh",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
     }}>
      <div className={styles.container}>
          {resting && restingTime !== null &&(
          <h1
            className={`${styles.countdown} ${restingTime < 0 ? styles.overTime : styles.onTime}`}
          >
            {formatTime(restingTime)}
          </h1>
        )}

        <div className={styles.logSection}>
          <h1 className={styles.endOfDay}>Day Logs</h1>
          <div className={styles.logContainer}>
            <table className={styles.table}>
              <thead>
                <tr>
                  <th>Log</th>
                  <th>Time</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {todayLogsData ? (
                  Object.values(todayLogsData).map((log, index) => (
                    <tr key={index}>
                      <td>{log.typeOfLog}</td>
                      <td>{log.setAt}</td>
                      <td>{log.status}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3}>No logs available</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
        {endOfDay ? (
          <h1 className={styles.endOfDay}>End of day</h1>
        ) : (
          <div className={styles.formContainer}>
            
            <div className={styles.submitContainer}>
              <button
                type="button"
                className={`btn btn-primary mt-1 ${styles.submitButton}`}
                onClick={handleSubmit}
                {...(!selectedLogType ? { disabled: true } : {})}
              >
                Submit
              </button>
              <Select
                placeholder="Log Type"
                id="deactivationType"
                name="deactivationType"
                options={logOptions}
                onChange={(e: any) => setSelectedLogType(e.value)}
                className="dchm-select"
              />
            </div>
          </div>
        )}
              
              
      </div>
      {/* { userId !== 0 && (
                <Timeline />
              )} */}
      
    </div>
  );
};

export default SetAssistance;