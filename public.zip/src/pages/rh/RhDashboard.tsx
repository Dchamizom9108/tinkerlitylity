import React, { useState } from "react";
import {
  GETAssistanceUsersById,
  returnDepartmentManager,
  getUsersFromDepartments,
  GETDepartmentName,
  GETAssistance,
} from "@app/services/rh";

import { getToday, getMonthName } from "@app/services/time";

import { UserCard } from "@app/components"

interface User {
  userId: number;
  logs: any;
  firstName: string;
  lastName: string;
  email: string;
  department: string;
}

const RhDashboard = () => {
  const [activeUsers, setActiveUsers] = useState<any[]>([]);
const [inactiveUsers, setInactiveUsers] = useState<any[]>([]);
const [lunchUsers, setLunchUsers] = useState<any[]>([]);
const [breakUsers, setBreakUsers] = useState<any[]>([]);
const [endShiftUsers, setEndShiftUsers] = useState<any[]>([]);

const [userDepManager, setUserDepManager] = useState<any[]>([]);
const [userDepManagerName, setUserDepManagerName] = useState<any[]>([]);

  React.useEffect(() => {
    async function fetchDepManager() {
      try {
        const depNames = await Promise.all(
          userDepManager.map(async (dep: any) => {
            const depName = await GETDepartmentName(dep);
            return depName;
          })
        )
        setUserDepManagerName(depNames);
        return depNames;
      } catch (error) {
        console.log(error);
      }
    }

    if (userDepManager.length > 0) {
      fetchDepManager();
    }
  }, [userDepManager]);

  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const date = getToday("date") || new Date().toISOString().split("T")[0];
        const month = getMonthName(date);
        const email = JSON.parse(localStorage.getItem("user") || "null").user.email;
        const userDepartment = await returnDepartmentManager(email);
      
        setUserDepManager(userDepartment);

        const users = await getUsersFromDepartments(userDepartment);
        // console.log(users);

        const assistanceData = await GETAssistanceUsersById(assistId);

        let presentUsers = assistanceData?.attributes.accounts.data
          .map((log : any) => {
            const userId = log.id;
            const logs = log.attributes.asistlogs.data[0]?.attributes || null;
            const firstName = log.attributes.firstName;
            const lastName = log.attributes.lastName;
            const email = log.attributes.email;
            return {
              userId,
              logs,
              firstName,
              lastName,
              email,
            };
          })
          .filter((user : User) => user.logs !== null);
        
        // filter present users of users list and add department
        presentUsers = presentUsers.filter((user : User) =>
          users.some((userList) => userList.userId === user.userId)
        ).map((user : User) => {
          const department = users.find(
            (userList) => userList.userId === user.userId
          )?.department;
          return {
            ...user,
            department,
          };
        })

        const activeUsers = presentUsers.filter((user : User) => {
          const userLogs = user.logs[month][date] || {};
          const logEntries = Object.entries(userLogs).sort(([timeA], [timeB]) =>
            timeA.localeCompare(timeB)
          );

          if (logEntries.length === 0) {
            return false; // No logs for today
          }

          const lastLog : any = logEntries[logEntries.length - 1][1];
          return !["startLunch", "startBreak", "endShift"].includes(
            lastLog.typeOfLog
          );
        });

        const inactiveUsers = users.filter(
          (user) =>
            !presentUsers.some(
              (activeUser : User) => activeUser.userId === user.userId
            )
        );
        const activeUsersFiltered = users.filter((user) =>
          activeUsers.some((activeUser : User) => activeUser.userId === user.userId)
        );

        // Determinar usuarios en lunch o break
        const lunchUsers : any = [];
        const breakUsers : any = [];
        const endShiftUsers : any = [];

        presentUsers.forEach((user : User) => {
          const userLogs = user.logs[month][date] || {};

          // Convertir los logs en una matriz de entradas y ordenar por tiempo
          const logEntries = Object.entries(userLogs).sort(([timeA], [timeB]) =>
            timeA.localeCompare(timeB)
          );
          const lastLog : any = logEntries[logEntries.length - 1][1];

          if (lastLog.typeOfLog === "startLunch") {
            lunchUsers.push(user);
          } else if (lastLog.typeOfLog === "startBreak") {
            breakUsers.push(user);
          } else if (lastLog.typeOfLog === "endShift") {
            endShiftUsers.push(user);
          }
        });

        // console.log(lunchUsers, breakUsers, endShiftUsers, activeUsersFiltered, inactiveUsers);

        setLunchUsers(lunchUsers);
        setBreakUsers(breakUsers);
        setEndShiftUsers(endShiftUsers);

        setActiveUsers(activeUsersFiltered);
        setInactiveUsers(inactiveUsers);
      } catch (error) {
        console.error("Error fetching users: ", error);
      }
    };
    fetchData();
  }, []);

  //set title of page to RH Dashboard
  React.useEffect(() => {
    document.title = "RH Dashboard";
  }, []);
  return (
    <div>
      {/* Content Header (Page header) */}
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h1 className="m-0">RH Dashboard</h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                {/* por cada departamento que administre crear un texto con el nombre */}
                {userDepManagerName.map((name, index) => (
                  <li className="breadcrumb-item" key={index}>
                    {name}
                  </li>
                ))}
                {userDepManagerName.length === 0 && (
                  <li className="breadcrumb-item">No Departments</li>
                )}
              </ol>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="container-fluid">
        <div className="row">
          {/* Inactive Users */}
          <UserCard
            title="Not Logged"
            users={inactiveUsers}
            badgeColor="danger"
          />

          {/* Active Users */}
          <UserCard
            title="At Office"
            users={activeUsers}
            badgeColor="success"
          />
        </div>

        <div className="row">
          {/* Lunch Users */}
          <UserCard title="Lunch" users={lunchUsers} badgeColor="warning" />

          {/* Break Users */}
          <UserCard title="Break" users={breakUsers} badgeColor="info" />
        </div>

        <div className="row">
          <UserCard
            title="End Shift"
            users={endShiftUsers}
            badgeColor="secondary"
          />

          {/* Resting */}
          <UserCard title="Resting" users={[]} badgeColor="secondary" />
        </div>
      </div>
    </div>
  );
};

export default RhDashboard;
