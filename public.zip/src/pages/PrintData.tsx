import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { getUserDetail } from "@app/services/user";

function PrintData() {
  const { id } = useParams<{ id: string }>();
  const [userData, setUserData] = React.useState<any>({});
  const [tcxData, setTcxData] = React.useState<any>({});
  const username = userData?.email?.split("@")[0];

  const customStyles = {
    headerPrint: {
      width: "100%",
      height: "3rem",
      padding: "20px",
      margin: "auto",
      marginTop: "20px",
      textAlign: "center" as "center",
    },
    mainPrint: {
      position: "relative" as "relative",
      maxWidth: "60rem",
      margin: "auto",
      marginTop: "6rem",
    },
    sectionPrint: {
      position: "relative" as "relative",
      maxWidth: "50rem",
      margin: "0 auto",
      border: "2px solid #d0d0d5",
    },
    tableWrapPrint: {
      padding: "0 0.75rem 1.5rem 0.75rem",
    },
    tablePrint: {
      borderCollapse: "collapse" as "collapse",
      border: "2px solid #000",
      width: "100%",
      position: "relative" as "relative",
      marginTop: "3rem",
    },
    tbodyPrintTd: {
      width: "30%",
      border: "2px solid #000",
      fontWeight: 550,
    },
    tbodyPrintTh: {
      width: "20%",
      border: "2px solid #000",
    },
    dataPrintTh: {
      textAlign: "left" as "left",
      paddingTop: "0.3rem",
      paddingLeft: "0.5rem",
      border: "2px solid #000",
    },
    dataPrintTd: {
      verticalAlign: "top" as "top",
      padding: "0.3rem 0.25rem 0",
      textAlign: "left" as "left",
      border: "2px solid #000",
    },
    footerPrint: {
      marginTop: "20px",
      backgroundColor: "white",
      padding: "20px",
      textAlign: "center" as "center",
    },
    footerPrintP: {
      marginBottom: "10px",
    },
    centerPrint: {
      textAlign: "center" as "center",
      marginTop: "20px",
    },
    spanishPrint: {
      marginTop: "20px",
    },
    signPrint: {
      marginTop: "40px",
      textAlign: "center" as "center",
    },
    signPrintH2: {
      fontSize: "18px",
    },
  };

  useEffect(() => {
    getUserDetail(id).then((res) => {
      const data = res.data.data.attributes;
      setTcxData(data.tcxData);
      setUserData(data);
      document.title = `${data.jobTitle} - ${username}`;
    });
  }, [id, username]);

  return (
    <div>
      <header style={customStyles.headerPrint}>
        <div>
          <h1>Welcome Consumer Law Group</h1>
          <div>
            <h2>New User Info</h2>
          </div>
        </div>
      </header>

      <main style={customStyles.mainPrint}>
            <table style={customStyles.tablePrint}>
              <tbody>
                <tr style={customStyles.dataPrintTh}>
                  <th>Name</th>
                  <td style={customStyles.dataPrintTd}>{userData.firstName}</td>
                  <th>Last name</th>
                  <td style={customStyles.dataPrintTd}>{userData.lastName}</td>
                </tr>
                <tr style={customStyles.dataPrintTh}>
                  <th>Position</th>
                  <td style={customStyles.dataPrintTd}>{userData.jobTitle}</td>
                  <th>Office</th>
                  <td style={customStyles.dataPrintTd}>CLG Office</td>
                </tr>
                <tr style={customStyles.dataPrintTh}>
                  <th>Email</th>
                  <td style={customStyles.dataPrintTd}>{userData.email}</td>
                  <th>Username</th>
                  <td
                    style={customStyles.dataPrintTd}
                    onClick={() => navigator.clipboard.writeText(username)}
                  >
                    {username}
                  </td>
                </tr>
                <tr style={customStyles.dataPrintTh}>
                  <th>Extension</th>
                  <td style={customStyles.dataPrintTd}>{tcxData?.Number}</td>
                  <th>Direct Line</th>
                  <td style={customStyles.dataPrintTd}>
                    {tcxData?.OutboundCallerID}
                  </td>
                </tr>
                <tr style={customStyles.dataPrintTh}>
                  <th>Effective Day</th>
                  <td style={customStyles.dataPrintTd}>
                    {new Date(userData?.startDate).toLocaleDateString()}
                  </td>
                  <th>Intranet Password</th>
                  <td
                    style={customStyles.dataPrintTd}
                    onClick={() =>
                      navigator.clipboard.writeText(userData.accountsPassword)
                    }
                  >
                    {userData.accountsPassword}
                  </td>
                </tr>
              </tbody>
            </table>
      </main>

      <footer style={customStyles.footerPrint}>
        <div>
          <p style={customStyles.footerPrintP}>
            In home.consumerlaw.com you find all Company Apps
            <br />
            Your username is the same for all applications which is your email
            <br />
            This document shows the passwords for the network and O365.
            <br />
          </p>
          <p style={customStyles.footerPrintP}>
            You can have a single password for all applications, but you must
            comply with the established policy. <br />
          </p>
          <div style={customStyles.centerPrint}>
            Must be more than 10 characters.
            <br />
            Have at least one uppercase and one lowercase letter.
            <br />
            You must use any symbol and number.
            <br />
          </div>
        </div>

        <div style={customStyles.spanishPrint}>
          <p>
            En https://home.consumerlaw.com encontrará todas las aplicaciones de
            la compañía <br />
            Su nombre de usuario es el mismo para todas las aplicaciones, que es su correo electrónico.
            <br />
            En este documento se muestra las contraseñas para la red y O365.
            <br />
          </p>
          <p>
            Puede tener una contraseña única para todas las aplicaciones, pero
            debe cumplir con la política establecida. <br />
          </p>
          <div style={customStyles.centerPrint}>
            Debe tener más de 10 caracteres.
            <br />
            Tener al menos una letra mayúscula y una letra minúscula.
            <br />
            Debe usar cualquier símbolo y número.
            <br />
          </div>
          <p />
        </div>

        <div style={customStyles.signPrint}>
          <h2 style={customStyles.signPrintH2}>CLG IT Departament</h2>
        </div>
      </footer>
    </div>
  );
}

export default PrintData;
