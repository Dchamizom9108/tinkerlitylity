import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import {
  GETDepartment,
  getUsersByManager,
  PUTDepartmentAccount,
} from "@app/services/user";

import { ShowAlert } from "@app/components";
import { UserAttributes } from "@app/types";

const rhBotId = 4244;

const DepartmentDetail = () => {
  const paramId = useParams();
  const depName = String(paramId.name) || "";
  const [depID, setDepID] = useState(78);
  const [department, setDepartment] = useState<UserAttributes[]>([]);
  const [availableUsers, setAvailableUsers] = useState<UserAttributes[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null as string | null);

  useEffect(() => {
    const fetchDepartmentDetail = async () => {
      try {
        const response = await GETDepartment(depName);
        console.log(response, "response", depName);

        setDepID(response.data.data[0].id);

        const formattedInitialAccounts =
          response.data.data[0].attributes.accounts.data.map((account: any) => {
            return {
              id: account.id,
              firstName: account.attributes.firstName,
              lastName: account.attributes.lastName,
              email: account.attributes.email,
              name: `${account.attributes.firstName.split(" ")[0]} ${account.attributes.lastName.split(" ")[0]}`,
            };
          });

        setDepartment(formattedInitialAccounts || []);

        const availableResponse = await getUsersByManager(rhBotId);

        const filteredAvailableUsers = availableResponse.filter((user: any) => {
          return !formattedInitialAccounts.some(
            (initialAccount: any) => initialAccount.id === user.id
          );
        });

        setAvailableUsers(filteredAvailableUsers || []);
      } catch (err) {
        console.error("Error fetching shift details:", err);
        setError(`No se pudieron cargar los detalles del departamento. ${err}");`);
      } finally {
        setLoading(false);
      }
    };

    fetchDepartmentDetail();
  }, [depName]);

  const handleAddUser = async (userId: number) => {
    try {
      const response = await GETDepartment(depName);
      const res = response.data.data[0];

      const updatedAccounts = [
        ...res.attributes.accounts.data.map((account: any) => account.id),
        userId,
      ];
      const resPut = await PUTDepartmentAccount(depID, updatedAccounts);

      if (resPut.status === 200) {
        const userFromAvailable = availableUsers.find(
          (availableUser) => availableUser.id === userId
        );
        if (userFromAvailable) {
          setAvailableUsers((prevUsers) =>
            prevUsers.filter((user) => user.id !== userId)
          );
          setDepartment((prevUsers) => [...prevUsers, userFromAvailable]);
        }
      } else {
        ShowAlert("error", "Error", "No se pudo agregar el usuario al turno");
      }
    } catch (err) {
      console.error("Error adding user to shift:", err);
      ShowAlert("error", "Error", "No se pudo agregar el usuario al turno");
    }
  };

  const handleRemoveUser = async (userId: number) => {
    try {
      const response = await GETDepartment(depName);
      const res = response.data.data[0];

      const updatedAccounts = res.attributes.accounts.data
        .filter((account: any) => account.id !== userId)
        .map((account: any) => account.id);
      const putRes = await PUTDepartmentAccount(depID, updatedAccounts);

      if (putRes.status === 200) {
        const userFromShift = department?.find((user) => user.id === userId);
        if (userFromShift) {
          setDepartment((prevUsers) =>
            prevUsers.filter((user) => user.id !== userId)
          );
          setAvailableUsers((prevUsers) => [...prevUsers, userFromShift]);
        }
      }
    } catch (err) {
      console.error("Error removing user from shift:", err);
      ShowAlert("error", "Error", "No se pudo eliminar el usuario del turno");
    }
  };

  if (loading) return <div>Cargando...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container">
      <div className="card">
        <div className="card-header" style={{ display: "flex", justifyContent: "space-between" }}>
          <div className="col-md-6"><h1 style={{ textAlign: "center" }}>{depName}</h1></div>
        </div>
          <div className="card-body">
            <h2>Usuarios</h2>
            <ul className="list-group-top-ch"
            >
              {department?.map((user) => (
                <li key={user.id}>
                  <div className="card">
                    <div className="card-body">
                      <h5 className="card-title">{user.name}</h5>
                    </div>
                    <div className="card-footer">
                      <button
                        className="btn btn-danger"
                        onClick={() => handleRemoveUser(user.id)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
          <div className="card-footer">
            <h2>Usuarios Disponibles</h2>
            <ul className="list-group-ch"
            >
              {availableUsers.map((user) => (
                <li
                  key={user.id}
                  className="list-group-item-ch"
                >
                  {user.name}{" "}
                  <button
                    onClick={() => handleAddUser(user.id)}
                    className="btn btn-success"
                  >
                    Agregar
                  </button>
                </li>
              ))}
            </ul>
          </div>
      </div>
    </div>
  );
};

export default DepartmentDetail;
