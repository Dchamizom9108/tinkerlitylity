import React, { useState, useEffect } from "react";
import { getUsers, syncData } from "@app/services/user";

import { utils, writeFile } from "xlsx"; // Importa la librería xlsx

import {
  // ContentHeader,
  InputFilter,
  DropDownFilter,
  OrderByLink,
  Data,
  Pagination,
  WarningCell,
  RecordLink,
  List,
  Toggle,
} from "@app/components";

interface Department {
  name: string;
  // otros atributos si es necesario
}

interface PaginationProperties {
  pageIndex: number;
  pageCount: number;
  pageSize: number;
  total: number;
}

interface paginationShowProperties {
  pageIndex: number;
  pageCount: number;
  pageSize: number;
  total: number;
}

function UsersList() {
  const user = JSON.parse(localStorage.getItem("user") || "{}");
  const role = user?.user.role;
  const [data, setData] = React.useState<any>([]);
  const [pagination, setPagination] = React.useState<PaginationProperties>({
    pageIndex: 1,
    pageCount: 0,
    pageSize: 10,
    total: 0,
  });

  const [paginationShow, setPaginationShow] =
    React.useState<paginationShowProperties>({
      pageIndex: 1,
      pageCount: 2,
      pageSize: 10,
      total: 30,
    });
    const [filter, setFilter] = React.useState<Record<string, string>>({});
    const [depSelected, setDepSelected] = React.useState<string>("");
  const [orderBy, setOrderBy] = React.useState({
    column: "firstName",
    direction: "asc",
  });
  const [departments, setDepartments] = useState<Department[]>([]);
  const [spin, setSpin] = useState(false);

  const columns = React.useMemo(
    () => [
      {
        Header: (
          <OrderByLink
            label="Name"
            onClick={setOrderBy}
            order={orderBy}
            column="firstName"
          />
        ),
        width: "22%",
        accessor: "link",
        component: (props: any) => <RecordLink props={props} />,
      },
      {
        Header: (
          <OrderByLink
            label="Job Title"
            onClick={setOrderBy}
            order={orderBy}
            column="jobTitle"
          />
        ),
        width: "12%",
        accessor: "jobTitle",
      },
      {
        Header: "Template",
        width: "40%",
        accessor: "userTemplate",
        component: (props: any) => <List items={props} />,
      },
      {
        Header: "O 365",
        accessor: "o365",
        component: (props: any) => <WarningCell props={props} />,
      },
      {
        Header: "SugarCRM",
        accessor: "sugar",
        component: (props: any) => <WarningCell props={props} />,
      },
      {
        Header: "3cx",
        accessor: "tcx",
        component: (props: any) => <WarningCell props={props} />,
      },
    ],
    [orderBy]
  );

  useEffect(() => {
    const getData = async (filter: any, orderBy: any) => {
      //Create the filter URL
      let filterUri =
        Object.keys(filter).length > 0 ? "" : "&filters[o365Enable][$eq]=true";
      Object.keys(filter).map(
        (el) => (filterUri = `${filterUri}${filter[el]}`)
      );

      //Call accounts and departments API at once
      try {
        const resp = await getUsers(pagination, filterUri, orderBy);

        if (resp instanceof Error) {
          throw resp;
        }

        // Set the values to the Department Filter
        const departments = resp.departments
          .map((dep) => dep.attributes.name)
          .sort();

        setDepartments(departments);

        setPaginationShow({
          pageIndex: pagination.pageIndex,
          pageCount: Math.ceil(resp.count / pagination.pageSize),
          pageSize: pagination.pageSize,
          total: resp.count,
        });

        let data = resp.data.map((usersData) => {
          let o365Warning = true;
          let sugarWarning = true;
          let tcxWarning = true;

          function validateOffice365(usersData: any) {
            const memberOf = usersData.o365Data?.memberOf
              .map((mo: any) => mo.id)
              .sort();
            let templateGroups = usersData.departments.data
              .map((el: any) =>
                el.attributes.office_groups.data.map(
                  (rl: any) => rl.attributes.groupId
                )
              )
              .flat()
              .sort();
            templateGroups = [...new Set(templateGroups)];
            return JSON.stringify(memberOf) !== JSON.stringify(templateGroups);
          }

          function validateSugar(usersData: any) {
            const sugarRoles = usersData.sugarData?.roles
              .map((rl: any) => rl.id)
              .sort();
            let templateRoles = usersData.departments.data
              .map((el: any) =>
                el.attributes.sugar_roles.data.map(
                  (rl: any) => rl.attributes.roleId
                )
              )
              .flat()
              .sort();
            templateRoles = [...new Set(templateRoles)];
            const sugarTeams = usersData.sugarData?.teams
              .map((tm: any) => tm.id)
              .sort();
            let templateTeams = usersData.departments.data
              .map((el: any) =>
                el.attributes.sugar_teams.data.map(
                  (rl: any) => rl.attributes.teamId
                )
              )
              .flat()
              .sort();
            templateTeams = [...new Set(templateTeams)];
            return (
              JSON.stringify(sugarRoles) !== JSON.stringify(templateRoles) ||
              JSON.stringify(sugarTeams) !== JSON.stringify(templateTeams)
            );
          }

          function validate3cx(usersData: any) {
            const tcxRangeStart =
              usersData.departments.data[0]?.attributes.txcRangeStart;
            const tcxRangeEnd =
              usersData.departments.data[0]?.attributes.txcRangeEnd;
            const tcxNumber = usersData.tcxData?.Number;
            return (
              tcxRangeStart !== undefined &&
              tcxRangeEnd !== undefined &&
              tcxNumber !== undefined &&
              (tcxNumber < tcxRangeStart || tcxNumber > tcxRangeEnd)
            );
          }

          if (usersData.departments.data.length > 0) {
            o365Warning = validateOffice365(usersData);
            sugarWarning = validateSugar(usersData);
            tcxWarning = validate3cx(usersData);
          }

          if (usersData.ignoreErrors) {
            o365Warning = false;
            sugarWarning = false;
            tcxWarning = false;
          }

          if (usersData.departments.data.length > 0) {
            usersData.userTemplate = usersData.departments.data.map(
              (el_5: any) => {
                return el_5.attributes.name;
              }
            );
          } else {
            usersData.userTemplate = [];
          }
          usersData.link = {
            name: `${usersData.firstName} ${usersData.lastName}`,
            link: `/users/${usersData.id}`,
            ignoreErrors: usersData.ignoreErrors,
          };
          usersData.o365 = {
            status: usersData.o365Enable,
            warning: o365Warning,
          };
          usersData.sugar = {
            status: usersData.sugarEnable,
            warning: sugarWarning,
          };
          usersData.tcx = { status: usersData.tcxEnable, warning: tcxWarning };

          return usersData;
        });
        // data = data.length > 0 ? data : 'no data'

        setData(data);
        return data;
      } catch (err) {
        return console.log(err);
      }
    };

    getData(filter, orderBy);
  }, [filter, orderBy, pagination]);


  const sync = (e: any) => {
    // console.log(e)
    e.preventDefault();
    setSpin(true);
    syncData().then(() => {
      setSpin(false);
    });
  };

  // Función para exportar los datos a Excel
  const exportToExcel = (exportData: any) => {
    const worksheet = utils.json_to_sheet(exportData);
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, "Users");

    // Genera y descarga el archivo
    writeFile(workbook, "users_list.xlsx");
  };

  // Función para exportar todos los usuarios
  const exportAll = async (e: any) => {
    e.preventDefault();

    const exportData = data
      .filter(
        (item: any) =>
          item.email.endsWith("@consumerlaw.com") && item.tcx.status === true
      )
      .map((item: any) => ({
        fullName: `${item.firstName} ${item.lastName}`,
        email: item.email,
        jobTitle: item.jobTitle,
        departments: item.departments.data
          ?.reduce((acc : any, curr : any) => `${acc}, ${curr.attributes.name}`, "")
          .substring(2),
        o365: item.o365.status,
        o365Groups: item.o365Data?.memberOf
          .map((mo : any) => mo.displayName)
          .reduce((acc : any, curr : any) => `${acc}, ${curr}`, "")
          .substring(2),
        sugar: item.sugar.status,
        sugarRoles: item.sugarData?.roles
          .map((rl : any) => rl.name)
          .reduce((acc : any, curr : any) => `${acc}, ${curr}`, "")
          .substring(2),
        sugarTeams: item.sugarData?.teams
          .map((tm : any) => tm.name)
          .reduce((acc : any, curr : any) => `${acc}, ${curr}`, "")
          .substring(2),
        tcx: item.tcx.status,
        tcxExtension: item.tcxData?.Number,
        tcxNumber: item.tcxData?.DID,
      }));

    exportToExcel(exportData); // Llama a la función para generar el archivo Excel
  };

  useEffect(() => { 
    console.log("Filter:", filter);
    
    // Asegúrate de acceder a la clave correcta y que exista
    const filterValue = filter["[departments][name][$in]"] 
      ? filter["[departments][name][$in]"].split("=")[1]
      : "";
  
    console.log("Filter Value:", filterValue);
    setDepSelected(filterValue || "");
  }, [filter]);

  return (
    <div>
      {/* <ContentHeader title="Users List" /> */}

      <section className="content">
        {/* <DataTable/> */}

        <div className="card">
          <div className="card-header input-group input-group-md row ">
            <div className="col-10 row">
              <InputFilter
                filterChange={setFilter}
                field="firstName"
                filter={filter}
                className="col-5"
              ></InputFilter>
              <DropDownFilter
                filterChange={setFilter}
                field="[departments][name][$in]"
                options={departments}
                filter={filter}
                className="col-4"
              ></DropDownFilter>
              <div className="col-1 d-flex align-items-center" ><a href={`/departments/${depSelected}`}><i className="fas fa-edit" ></i></a></div>
              
              {/* <Toggle
                label={"Disabled"}
                filterChange={setData} // Pasa setData para modificar el estado
                fullData={data} // Pasa los datos completos para filtrado
              /> */}
            </div>
            <div
              className="col-2 d-flex align-items-center ml-auto "
              style={{ justifyContent: "space-around" }}
            >
              <i className="fas fa-file-csv fa-2x" onClick={exportAll}></i>

              {role === "Admin" ? (
                <i className={
                    spin ? "fas fa-sync-alt fa-spin" : "fas fa-sync-alt"
                  } onClick={sync} ></i>
              ) : ( "" )}
            </div>
          </div>
          <div className="card-body p-0">
            <Data columns={columns} data={data}></Data>
          </div>
          <div className="card-footer">
            <Pagination
              pagination={paginationShow}
              setPagination={setPagination}
            ></Pagination>
          </div>
        </div>
      </section>
    </div>
  );
}

export default UsersList;
