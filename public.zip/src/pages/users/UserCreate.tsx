import React, { useState, useEffect } from "react";
import { createUser, createPassword, getDepartmentsNames } from "@app/services/user";
import Swal from "sweetalert2";
import { useAppSelector } from "@app/store/store";
import { UserForm } from "@app/components";
import { OptionType, FormData } from "@app/types";

const UserCreate = () => {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    actionToExecute: "Modify",
    effectiveDate: new Date(),
    jobTitle: null,
    departments: [],
    notes: "",
    suspensionPeriod: "",
    deactivationType: "",
    processing: false,
    startDate: new Date(),
  });

  const [processing, setProcessing] = useState(false);

    const [fullDepartments, setFullDepartments] = useState<OptionType[]>([]);
    const [loaded, setLoaded] = useState(false);
  
    useEffect(() => {
      const fetchDepartments = async () => {
        const departments = await getDepartmentsNames();
        setFullDepartments(
          departments.data.data.map((dep: any) => ({
            value: dep.id,
            label: dep.attributes.name,
          }))
        );
        return departments;
      };
  
      if (!loaded) {
        setLoaded(true);
        fetchDepartments();
      }
    }, [loaded]);

  const whoIsConnected = useAppSelector((state) => state.auth.currentUser);

  const formChange = (e: any, field: string) => {
    setFormData({ ...formData, [field]: e });
  };

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setProcessing(true);

    // Mapear los nombres de departamentos a sus respectivos IDs
    const departmentIds = formData.departments.map((deptName:any) => {
      const dept = fullDepartments.find((d:any) => {
        return d.label === deptName || d.name === deptName});
      return dept ? dept.value : null;
    }).filter((id:any) => id !== null); // Eliminar nulls

    const payload = {
      ...formData,
      email: `${formData.firstName.split(" ")[0].toLowerCase()}.${formData.lastName.split(" ")[0].toLowerCase()}@consumerlaw.com`,
      username: `${formData.firstName.split(" ")[0].toLowerCase()}.${formData.lastName.split(" ")[0].toLowerCase()}@consumerlaw.com`,
      accountsPassword: createPassword(`${formData.firstName.split(" ")[0].toLowerCase()}.${formData.lastName.split(" ")[0].toLowerCase()}`),
      provider: "microsoft",
      status: "New",
      displayName: `${formData.firstName} ${formData.lastName}`,
      createdBy: whoIsConnected?.user.email,
      departments: departmentIds, // Aquí utilizas los IDs de departamentos
    };

    createUser(payload).then((resp) => {
      if (resp === "userExist") {
        Swal.fire({
          title: "Error",
          text: "The email already exists",
          icon: "error",
          confirmButtonText: "Ok",
        });
        setProcessing(false);
      } else {
        Swal.fire({
          title: "New user created",
          text: "The user has been created. We will notify you when all accounts are ready.",
          icon: "success",
          confirmButtonText: "Ok",
        }).then(() => {
          window.location.reload();
        })
        setProcessing(false);
      }
    });
  };

  const capitalizeWords = (str: string) => {
      return str
        .trim() // Elimina espacios al principio y final
        .split(/\s+/) // Divide por uno o más espacios
        .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitaliza cada palabra
        .join(" "); // Une las palabras nuevamente con un solo espacio
    };

  return (
    <div>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h1 className="m-0">Create New User</h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <a href="/">Home</a>
                </li>
                <li className="breadcrumb-item active">
                  <a href="/users">Users</a>
                </li>
                <li className="breadcrumb-item active">Create</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <section className="content">
        <div className="container-fluid">
          <div className="row">
            <div className="card d-flex col-sm-12">
              <div className="card-header">User Info</div>
              <div className="card-body">
                <form className="form-horizontal" onSubmit={submit}>
                  <div className="form-group row">
                    <label
                      htmlFor="firstName"
                      className="col-sm-2 col-form-label"
                    >
                      First Name
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="text"
                        className="form-control"
                        id="firstName"
                        placeholder="First Name"
                        required
                        value={formData.firstName}
                        onChange={(e) =>
                          formChange(e.target.value, "firstName")
                        }
                        onBlur={(e) => formChange(capitalizeWords(e.target.value), "firstName")} // Capitaliza al perder foco
                      />
                    </div>
                  </div>
                  <div className="form-group row">
                    <label
                      htmlFor="lastName"
                      className="col-sm-2 col-form-label"
                    >
                      Last Name
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="text"
                        className="form-control"
                        id="lastName"
                        placeholder="Last Name"
                        required
                        value={formData.lastName}
                        onChange={(e) => formChange(e.target.value, "lastName")}
                        onBlur={(e) => formChange(capitalizeWords(e.target.value), "lastName")}
                      />
                    </div>
                  </div>
                  <div className="form-group row">
                    <label htmlFor="email" className="col-sm-2 col-form-label">
                      Email
                    </label>
                    <div className="col-sm-10">
                      <input
                        type="text"
                        className="form-control"
                        id="email"
                        placeholder="Email"
                        required
                        value={`${formData.firstName.split(" ")[0].toLowerCase()}.${formData.lastName.split(" ")[0].toLowerCase()}@consumerlaw.com`}

                        readOnly
                      />
                    </div>
                  </div>

                  <UserForm formData={formData} setFormData={setFormData} handleSubmit={submit} />                

                  <div className="form-group row">
                    <div className="offset-sm-2 col-sm-10">
                      <button
                        type="submit"
                        className="btn btn-danger"
                        disabled={processing}
                      >
                        {processing ? (
                          <i className="fas fa-spinner mr-2 fa-spin"></i>
                        ) : (
                          ""
                        )}
                        Submit
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default UserCreate;