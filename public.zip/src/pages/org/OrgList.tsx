import React, { useState, useEffect } from 'react';

import { getSugarTeams } from '@app/services/user';

interface Employee {
  id: number;
  employeeName: string;
  reportsTo: number | null;
  department: string;
  teams: number[];
}

interface Team {
  id: number;
  name: string;
}

const OrgList: React.FC = () => {
  const [teams, setTeams] = useState<Team[]>([]);
  const [newEmployee, setNewEmployee] = useState<Employee>({
    id: 0,
    employeeName: '',
    reportsTo: null,
    department: '',
    teams: []
  });

  useEffect(() => {
    // Cargar empleados y equipos desde Strapi

    const fetchTeams = async () => {
      const { data } = await getSugarTeams();
      console.log(data.data);
      setTeams(data.data);
    };

    fetchTeams();
  }, []);


  return (
    <div className="container">

    </div>
  );
};

export default OrgList;
