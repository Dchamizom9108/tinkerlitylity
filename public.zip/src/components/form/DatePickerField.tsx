import React from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

type DatePickerProps = {
  label: string;
  id: string;
  selected: Date | null;
  onChange: (date: Date | null) => void;
  required?: boolean;
};

export const DatePickerField: React.FC<DatePickerProps> = ({ label, id, selected, onChange, required }) => (
  <div className="form-group row">
    <label htmlFor={id} className="col-sm-2 col-form-label">
      {label}
    </label>
    <div className="input-group col-sm-10">
      <DatePicker
        className="form-control"
        selected={selected}
        onChange={onChange}
        id={id}
        required={required}
      />
    </div>
  </div>
);