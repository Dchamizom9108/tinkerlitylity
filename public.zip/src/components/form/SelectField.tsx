import React from "react";
import Select from "react-select";
type SelectProps = {
  label: string;
  id: string;
  options: any[];
  isMulti?: boolean;
  value?: any;
  onChange: (value: any) => void;
  required?: boolean;
};

export const SelectField: React.FC<SelectProps> = ({ label, id, options, isMulti, value, onChange, required }) => (
  <div className="form-group row">
    <label htmlFor={id} className="col-sm-2 col-form-label">
      {label}
    </label>
    <div className="col-sm-10">
      <Select
        placeholder={label}
        id={id}
        isMulti={isMulti}
        name={id}
        options={options}
        value={value}
        required={required}
        onChange={onChange}
        className="basic-multi-select"
        classNamePrefix="select"
      />
    </div>
  </div>
);