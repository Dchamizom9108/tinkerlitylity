import React from 'react';

type InputProps = {
  label: string;
  id: string;
  placeholder: string;
  value?: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
  readOnly?: boolean;
};

export const InputField: React.FC<InputProps> = ({ label, id, placeholder, value, onChange, required, readOnly }) => (
  <div className="form-group row">
    <label htmlFor={id} className="col-sm-2 col-form-label">
      {label}
    </label>
    <div className="col-sm-10">
      <input
        type="text"
        className="form-control"
        id={id}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        required={required}
        readOnly={readOnly}
      />
    </div>
  </div>
);