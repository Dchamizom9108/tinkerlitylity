import React from 'react';

type TextAreaProps = {
  label: string;
  id: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
};

export const TextAreaField: React.FC<TextAreaProps> = ({ label, id, onChange }) => (
  <div className="form-group row">
    <label htmlFor={id} className="col-sm-2 col-form-label">
      {label}
    </label>
    <div className="col-sm-10">
      <textarea className="form-control" id={id} onChange={onChange} />
    </div>
  </div>
);