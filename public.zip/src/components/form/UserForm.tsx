import React, { useState, useEffect } from "react";
import Select from "react-select";
import DatePicker from "react-datepicker";
import { OptionType, FormData } from "@app/types";

import { getDepartmentsNames } from "@app/services/user";

import "react-datepicker/dist/react-datepicker.css";

interface UserFormProps {
  formData: FormData;
  setFormData: React.Dispatch<React.SetStateAction<FormData>>;
  handleSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
}

const jobTitleOptions: OptionType[] = [
  { value: "AR", label: "AR" },
  { value: "Attorney", label: "Attorney" },
  { value: "CM Local", label: "CM Local" },
  { value: "CM Remote", label: "CM Remote" },
  { value: "CM National P1", label: "CM National P1" },
  { value: "CM National P2", label: "CM National P2" },
  { value: "Screener Local", label: "Screener Local" },
  { value: "Screener National", label: "Screener National" },
  { value: "Legal Assistant", label: "Legal Assistant (MX)" },
  { value: "Paralegal", label: "Paralegal (US)" },
  { value: "Paralegal MX", label: "Paralegal (MX)" },
  { value: "Custom", label: "Custom" },
];

export const UserForm: React.FC<UserFormProps> = ({
  formData,
  setFormData,
  handleSubmit,
}) => {
  const customStyles = {
    control: (provided: any) => ({
      ...provided,
      backgroundColor: "#343a4000",
      color: "#fff",
    }),
    menu: (provided: any) => ({
      ...provided,
      backgroundColor: "#70757a",
      color: "#000",
    }),
    singleValue: (provided: any) => ({
      ...provided,
      color: "#fff",
    }),
    placeholder: (provided: any) => ({
      ...provided,
      color: "#bbb",
    }),
  };

  const [defaultDepartments, setDefaultDepartments] = useState<OptionType[]>(
    []
  );
  const [loaded, setLoaded] = useState(false);
  const [startDate, setStartDate] = useState<Date | null>(null);

  useEffect(() => {
    const fetchDepartments = async () => {
      const departments = await getDepartmentsNames();
      setDefaultDepartments(
        departments.data.data.map((dep: any) => ({
          value: dep.id,
          label: dep.attributes.name,
        }))
      );
      return departments;
    };

    if (!loaded) {
      setLoaded(true);
      fetchDepartments();
    }
  }, [loaded]);

  const handleFormChange = (e: any, field: string) => {
    if (field === "jobTitle") {
      const newDepartments = getDefaultDepartmentsByJobTitle(e.value);
      setFormData({
        ...formData,
        jobTitle: e.value,
        departments: newDepartments.map((dep) => dep?.label || ""),
      });
    } else {
      setFormData({ ...formData, [field]: e });
    }
  };

  const handleDepartmentChange = (e: any) => {
    const updatedDep = e.map((option: OptionType) => option.label);
    setFormData({ ...formData, departments: updatedDep });
  };

  const findOptionByLabel = (label: string) => {
    return defaultDepartments.find((option) => option.label === label);
  };

  const getDefaultDepartmentsByJobTitle = (jobTitle: string) => {
    console.log("jobTitle", jobTitle);

    switch (jobTitle) {
      case "AR":
        return [
          findOptionByLabel("AR")!,
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
        ];
      case "Attorney":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - US")!,
          findOptionByLabel("Global - Backoffice")!,
          findOptionByLabel("Global - Attorney")!,
        ];
      case "CM Local":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - US")!,
          findOptionByLabel("Sales - Local")!,
        ];
      case "CM Remote":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Global - Sales")!,
          findOptionByLabel("Sales - P1")!,
          findOptionByLabel("Sales - Remote")!,
        ];
      case "CM National P1":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Global - Sales")!,
          findOptionByLabel("Sales - P1")!,
        ];
      case "CM National P2":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Global - Sales")!,
          findOptionByLabel("Sales - P2")!,
        ];
      case "Screener Local":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Global - Sales")!,
          findOptionByLabel("Sales - Screener Local")!,
        ];
      case "Screener National":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Sales - Local")!,
          findOptionByLabel("Sales - Screener National")!,
        ];
      case "Legal Assistant":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Global - Backoffice")!,
        ];
      case "Paralegal":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - US")!,
          findOptionByLabel("Global - Backoffice")!,
          findOptionByLabel("Global - Backoffice - Legal")!,
        ];
      case "Paralegal MX":
        return [
          findOptionByLabel("Global")!,
          findOptionByLabel("Global - MX")!,
          findOptionByLabel("Global - Backoffice")!,
          findOptionByLabel("MX - Paralegal")!,
        ];
      case "Custom":
        return [findOptionByLabel("Global")!];
      default:
        return [];
    }
  };

  return (
    <div>
      <div className="form-group row">
        <label htmlFor="jobTitle" className="col-sm-2 col-form-label">
          Job Title
        </label>
        <div className="col-sm-10">
          <Select
            id="jobTitle"
            name="jobTitle"
            options={jobTitleOptions}
            styles={customStyles}
            onChange={(e) => handleFormChange(e, "jobTitle")}
          />
        </div>
      </div>
      <div className="form-group row">
        <label htmlFor="departments" className="col-sm-2 col-form-label">
          Departments
        </label>
        <div className="col-sm-10">
          <Select
            placeholder="Department"
            id="departments"
            name="departments"
            className="basic-multi-select"
            isMulti
            styles={customStyles}
            options={defaultDepartments}
            value={defaultDepartments.filter((option) =>
              formData.departments.includes(option.label)
            )}
            onChange={handleDepartmentChange}
          />
        </div>
      </div>
      <div className="form-group row">
        <label htmlFor="startDate" className="col-sm-2 col-form-label">
          Start Date
        </label>
        <div className="col-sm-10">
          <DatePicker
            selected={startDate}
            onChange={(date: Date | null) => {
              setStartDate(date);
              setFormData({ ...formData, startDate: date });
            }}
          />
        </div>
      </div>
      <div className="form-group row">
        <label htmlFor="notes" className="col-sm-2 col-form-label">
          Notes
        </label>
        <div className="col-sm-10">
          <textarea
            id="notes"
            className="form-control"
            value={formData.notes}
            onChange={(e) =>
              setFormData({ ...formData, notes: e.target.value })
            }
          />
        </div>
      </div>
    </div>
  );
};
