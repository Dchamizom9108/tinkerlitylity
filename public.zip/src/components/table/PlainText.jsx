import PropTypes from "prop-types";

function PlainText({ props }) {
  // eslint-disable-next-line react/prop-types
  const timePart = props?.split(".")[0];
  return (
    <>
      <ul className="m-0 p-0">
            <li style={{ listStyle: "none", float: "left" }}>
              <span
                className="badge badge-secondary mr-1"
                style={{ fontSize: 11 }}
              >
                {timePart}
              </span>
            </li>
      </ul>
    </>
  );
}

PlainText.propTypes = {
  props: PropTypes.string,
};

export default PlainText;