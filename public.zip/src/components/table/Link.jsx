import PropTypes from "prop-types";

function RecordLink({ props }) {
  const url = `${props.link}`;
  return (
    <div
      style={{
        overflow: "hidden",
        whiteSpace: "nowrap",
        textOverflow: "ellipsis",
        maxWidth: "240px",
      }}
    >
      <a href={url}>
        {props.name}
        {props.ignoreErrors ? (
          <i className="fas fa-exclamation-circle text-orange ml-1"></i>
        ) : (
          ""
        )}
      </a>
    </div>
  );
}

RecordLink.propTypes = {
  props: PropTypes.object,
  link: PropTypes.string,
  name: PropTypes.string,
  ignoreErrors: PropTypes.bool,
};

export default RecordLink;
