import React from 'react';

type PaginationProps = {
  pagination: {
    pageIndex: number;
    pageCount: number;
    pageSize: number;
    total: number;
  };
  setPagination: React.Dispatch<React.SetStateAction<{
    pageIndex: number;
    pageCount: number;
    pageSize: number;
    total: number;
  }>>;
};

const Pagination: React.FC<PaginationProps> = ({ pagination, setPagination }) => {
  const { pageIndex, pageCount, pageSize, total } = pagination;

  const getPaginationNumbers = () => {
    const paginationNumbers: (number | string)[] = [];
    if (pageCount <= 6) {
      for (let i = 1; i <= pageCount; i++) {
        paginationNumbers.push(i);
      }
    } else {
      if (pageIndex <= 3) {
        paginationNumbers.push(1, 2, 3, 4, '...', pageCount);
      } else if (pageIndex >= pageCount - 2) {
        paginationNumbers.push(1, '...', pageCount - 3, pageCount - 2, pageCount - 1, pageCount);
      } else {
        paginationNumbers.push(1, '...', pageIndex - 1, pageIndex, pageIndex + 1, '...', pageCount);
      }
    }
    return paginationNumbers;
  };

  return (
    <div>
      <div className="row">
        <div className="col-sm-6">
          <div className="dataTables_info small ml-2">
            <b>
              Showing {pageSize * (pageIndex - 1) + 1} to{' '}
              {pageSize * pageIndex > total ? total : pageSize * pageIndex} of {total}{' '}
              entries
            </b>
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', flexWrap: 'nowrap', justifyContent: 'space-between' }}>
        <div>
          <select
            value={pageSize}
            onChange={(e) => setPagination({ ...pagination, pageSize: Number(e.target.value) })}
            className="custom-select"
          >
            {[10, 20, 30, 40, 50, -1].map((size) => (
              <option key={size} value={size}>
                {size === -1 ? 'All' : `Show ${size}`}
              </option>
            ))}
          </select>
        </div>
        <div>
          <div className="dataTables_paginate paging_simple_numbers">
            <ul className="pagination">
              <li className={`paginate_button page-item previous ${pageIndex === 1 ? 'disabled' : ''}`}>
                <button className="page-link" onClick={() => setPagination({ ...pagination, pageIndex: pageIndex - 1 })} disabled={pageIndex === 1}>
                  Previous
                </button>
              </li>
              {getPaginationNumbers().map((el, index) => (
                <li
                  key={index}
                  className={`paginate_button page-item ${pageIndex === el ? 'active' : ''} ${el === '...' ? 'disabled' : ''}`}
                >
                  {el === '...' ? (
                    <button className="page-link" disabled>
                      ...
                    </button>
                  ) : (
                    <button className="page-link" onClick={() => setPagination({ ...pagination, pageIndex: Number(el) })}>
                      {el}
                    </button>
                  )}
                </li>
              ))}
              <li className={`paginate_button page-item next ${pageIndex === pageCount ? 'disabled' : ''}`}>
                <button className="page-link" onClick={() => setPagination({ ...pagination, pageIndex: pageIndex + 1 })} disabled={pageIndex === pageCount}>
                  Next
                </button>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pagination;

