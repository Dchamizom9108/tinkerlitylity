import PropTypes from "prop-types";

function List({ items }) {
  return (
    <>
      <ul className="m-0 p-0">
        { items.length > 0 && items.map((e, i) => {
          return (
            <li key={i} style={{ listStyle: "none", float: "left" }}>
              <span
                className="badge badge-secondary mr-1"
                style={{ fontSize: 11 }}
              >
                {e}
              </span>
            </li>
          );
        })}
      </ul>
    </>
  );
}

List.propTypes = {
  items: PropTypes.array,
};

export default List;
