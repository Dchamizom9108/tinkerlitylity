import PropTypes from "prop-types";

function ClearFilter({ filter, clear }) {
  let filtered = false;

  Object.keys(filter).map((el) => {
    if (filter[el]) {
      filtered = true;
    }
    return null;
  });

  const clearFilter = () => {
    clear();
  };

  return (
    <>
      {filtered ? (
        <span className="input-group-append">
          <button
            type="button"
            className="btn btn-danger btn-flat ml-2"
            onClick={clearFilter}
          >
            <i className="fas fa-times"></i>
          </button>
        </span>
      ) : (
        ""
      )}
    </>
  );
}

ClearFilter.propTypes = {
  filter: PropTypes.object.isRequired,
  clear: PropTypes.func.isRequired,
};

export default ClearFilter;
