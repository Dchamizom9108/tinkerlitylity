import React from "react";

interface ToggleProps {
  filterChange: (data: any) => void; // Función para cambiar los datos filtrados
  label: string; // Texto del label
  fullData: any[]; // Datos completos (antes del filtro)
}

const Toggle: React.FC<ToggleProps> = ({ filterChange, label, fullData }) => {
  const [previousData, setPreviousData] = React.useState<any[]>([]);

  // Función para manejar el cambio de estado del toggle
  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isChecked = e.target.checked;

    if(isChecked){ // Si esta activado, se guardan los datos previos
      setPreviousData(fullData);
    }

    // Filtrar los datos según el estado del toggle (status de 3cx)
    const filteredData = isChecked
      ? fullData.filter((item) => item.tcx && item.tcx.status === true) // Filtra si está activado
      : previousData; // Devuelve todos los datos si está desactivado

    // Actualiza los datos en el componente principal
    filterChange(filteredData);
  };

  return (
    <div className="ml-2 col-2 d-flex">
      <div className="custom-control custom-switch">
        <input
          type="checkbox"
          className="custom-control-input"
          id="customSwitch1"
          onChange={onChange}
        />
        <label
          className="custom-control-label"
          htmlFor="customSwitch1"
          style={{ zoom: "1.5", marginLeft: "0.45rem" }}
        ></label>
      </div>
      <div className="pt-2">{label}</div>
    </div>
  );
};

export default Toggle;

