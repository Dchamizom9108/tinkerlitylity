import React from "react";
import PropTypes from "prop-types";

function InputFilter({ filterChange, field, filter, className }) {
  React.useEffect(() => {
    if (!filter?.[field]) {
      document.getElementById("search").value = "";
    }
  }, [field, filter]);

  function debounce(func, timeout = 300) {
    let timer;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        func.apply(this, args);
      }, timeout);
    };
  }

  function saveInput(e) {
    let search = e.target.value
      ? `&filters[${field}][$containsi]=${e.target.value}`
      : "";
    filter[field] = search;
    filterChange({ ...filter });
  }
  const processChange = debounce((e) => saveInput(e));

  return (
    <>
      <input
        id="search"
        className={`form-control ${className}`}
        placeholder="Search..."
        onChange={(e) => processChange(e)}
      />
    </>
  );
}

InputFilter.propTypes = {
  filterChange: PropTypes.func.isRequired,
  field: PropTypes.string.isRequired,
  filter: PropTypes.object.isRequired,
  className: PropTypes.string,
};

export default InputFilter;
