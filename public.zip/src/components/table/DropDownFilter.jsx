import PropTypes from "prop-types";
import React from "react";

function DropDownFilter({ filterChange, field, options, filter, className }) {
  const [option, setOption] = React.useState("");

  React.useEffect(() => {
    if (!filter?.[field]) {
      setOption("");
    }
  }, [field, filter]);

  const onChange = (e) => {
    setOption(e.target.value);
    let val = e.target.value ? `&filters${field}=${e.target.value}` : "";
    filter[field] = val;
    return { ...filter };
  };
  //console.log(options)

  return (
    <>
      <select
        className={"custom-select ml-4 " + className}
        onChange={(e) => filterChange(onChange(e))}
        value={option}
      >
        <option value="">All</option>
        {options.map((option, i) => {
          return (
            <option key={i} value={option}>
              {option}
            </option>
          );
        })}
      </select>
    </>
  );
}

DropDownFilter.propTypes = {
  filterChange: PropTypes.func,
  field: PropTypes.string,
  options: PropTypes.array,
  filter: PropTypes.object,
  className: PropTypes.string,
};

export default DropDownFilter;
