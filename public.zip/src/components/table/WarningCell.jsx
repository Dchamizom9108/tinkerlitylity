/* eslint-disable react/prop-types */
function WarningCell({props}) {
    // console.log(props)
    if(props.status && props.warning && props.status !== 'Inactive'){
        return <span className="badge badge-warning"><i className="fas fa-exclamation-circle mr-1"></i>Active</span> 
    } else if(!props.status || props.status === 'Inactive'){
        return <span className="badge badge-danger"><i className="fas fa-times-circle mr-1"></i>Inactive</span> 
    } else {
        return <span className="badge badge-success"><i className="fas fa-check-circle mr-1"></i>Active</span> 
    }
}

export default WarningCell