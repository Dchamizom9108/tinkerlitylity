import React, { useState, useEffect } from "react";

const DataTableCh = ({ dataUsersIn, loading, handleQueueUpdate }) => {
  const [data, setData] = useState([]);
  const [sortConfig, setSortConfig] = useState(null);

  useEffect(() => {
    setData(dataUsersIn);
  }, [dataUsersIn]);

  const handleSort = (key) => {
    let direction = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
    const sortedData = [...data].sort((a, b) => {
      if (a[key] < b[key]) {
        return direction === 'ascending' ? -1 : 1;
      }
      if (a[key] > b[key]) {
        return direction === 'ascending' ? 1 : -1;
      }
      return 0;
    });
    setData(sortedData);
  };

  return (
    <table className="data-table" id="table-headers">
      <thead>
        <tr>
          <th onClick={() => handleSort('phone_ext_c')}>Ext</th>
          <th onClick={() => handleSort('team')}>Team</th>
          <th onClick={() => handleSort('fullname')}>Agent</th>
          <th onClick={() => handleSort('qStatus')}>Q Status</th>
          <th onClick={() => handleSort('lastChecked')}>Date Check</th>
        </tr>
      </thead>

      <tbody id="teamBody">
        {data.length > 0 ? (
          data.map((user, index) => (
          <tr key={index}>
            <td>{user.phone_ext_c}</td>
            <td>{user.team}</td>
            <td>{user.fullname}</td>
            <td>
              {loading ? (<i className="fas fa-spinner mr-2 fa-spin"></i>) : ("")}
              <span
                style={{ cursor: loading ? "not-allowed" : "pointer" }}
                onClick={loading ? null : () => handleQueueUpdate(user.phone_ext_c, user.qStatus)} 
              >
                {user.qStatus}
              </span>
            </td>
            <td>{user.lastChecked}</td>
          </tr>
          ))
        ) : (
          <tr>
            <td colSpan="5">No data available</td>
          </tr>
        )}
      </tbody>
    </table>
  );
};

export default DataTableCh;
