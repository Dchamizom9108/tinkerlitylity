import PropTypes from "prop-types";

function OrderByLink({ label, onClick, order, column }) {
  const setOrder = () => {
    order = {
      column: column,
      direction:
        order.direction === "asc" && order.column === column ? "desc" : "asc",
    };
    return order;
  };
  return (
    <button
      className="btn btn-link p-0 text-dark"
      onClick={() => onClick(setOrder())}
    >
      <b>{label}</b>
    </button>
  );
}

OrderByLink.propTypes = {
  label: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
  order: PropTypes.object.isRequired,
  column: PropTypes.string.isRequired,
};

export default OrderByLink;
