import PropTypes from "prop-types";

function Data({ columns, data }) {
  return (
    <>
      <div className="col-sm-12">
        <table
          id="example1"
          className="table table-striped dataTable dtr-inline"
          aria-describedby="example1_info"
        >
          <thead>
            <tr>
              {columns.map((col, i) => {
                return (
                  <th className="sorting" key={i} width={col.width}>
                    {col.Header}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {data.length > 0
              ? data.map((el, i) => {
                  return (
                    <tr key={i}>
                      {columns.map((col, i) => {
                        if (col.component) {
                          return (
                            <td key={i}>{col.component(el[col.accessor])}</td>
                          );
                        } else {
                          return <td key={i}>{el[col.accessor]}</td>;
                        }
                      })}
                    </tr>
                  );
                })
              : [...Array(10).keys()].map((el, i) => {
                  return (
                    <tr key={i}>
                      {columns.map((col, i) => {
                        return (
                          <td key={i}>
                            <div className="p-2 m-1 bg-light"></div>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
          </tbody>
        </table>
      </div>
    </>
  );
}

Data.propTypes = {
  columns: PropTypes.array.isRequired,
  data: PropTypes.array.isRequired,
};

export default Data;
