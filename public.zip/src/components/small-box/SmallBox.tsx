import { Link } from 'react-router-dom';

export interface SmallBoxProps {
  colClass: string;
  cardStyle: string;
  alt?: string;
  icon?: string;
  title: string;
  href: string;
}

const SmallBox = ({
  colClass,
  cardStyle,
  alt,
  icon,
  title,
  href,
}: SmallBoxProps) => {

  return (
    <div className={colClass}>
      <div className={cardStyle}>
        <div className="icon d-flex" style={{ height: '120px' }}>
          <img src={icon} alt={alt} width="70" className="m-auto" />
        </div>
        <Link to={href} className="small-box-footer">
          <span className="mr-2">{title}</span>
          <i className="fa fa-arrow-circle-right" />
        </Link>
      </div>
    </div>
  );
};

export default SmallBox;


