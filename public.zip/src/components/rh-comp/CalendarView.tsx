import { useState, useEffect } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import { GETDepartmentCalendar } from "@app/services/user";
import { UserAttributes } from "@app/types";

const CalendarView = (depID: { depID: number }) => {
  const [department, setDepartment] = useState<UserAttributes[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [events, setEvents] = useState([]); // Almacena eventos para FullCalendar
  const [noCalendarUsers, setNoCalendarUsers] = useState<UserAttributes[]>([]);
  const [dayDetails, setDayDetails] = useState<any>(null); // Detalle del día seleccionado

  useEffect(() => {
    const fetchCalendarView = async () => {
      try {
        const response = await GETDepartmentCalendar(depID.depID);
        console.log("response", response);
        // set site title
        document.title = `${response.data.data.attributes.name} - Calendar`;

        const formattedAccounts =
          response.data.data.attributes.accounts.data.map((account: any) => ({
            id: account.id,
            firstName: account.attributes.firstName,
            lastName: account.attributes.lastName,
            email: account.attributes.email,
            name: `${account.attributes.firstName.split(" ")[0]} ${account.attributes.lastName.split(" ")[0]}`,
            calendar: account.attributes.asignedCalendar || {},
          }));

        const usersWithNoCalendar = formattedAccounts.filter(
          (account: any) =>
            !account.calendar || Object.keys(account.calendar).length === 0
        );

        setNoCalendarUsers(usersWithNoCalendar);

        const formattedEvents = Object.entries(
          formattedAccounts.reduce((acc: any, account: any) => {
            Object.entries(account.calendar).forEach(
              ([date, shift]: [string, any]) => {
                acc[date] = acc[date] || {
                  working: 0,
                  resting: 0,
                  morning: 0,
                  afternoon: 0,
                  vacation: 0,
                  users: [],
                };

                if (shift.work) {
                  acc[date].working += 1;
                  shift.startwork === "09:00:00 AM" && (acc[date].morning += 1);
                  shift.startwork === "12:00:00 PM" &&
                    (acc[date].afternoon += 1);
                  acc[date].users.push({ ...account, shift });
                } else {
                  acc[date].resting += 1;
                  if (shift.motive === "vacation") {
                    acc[date].vacation += 1;
                  }
                  acc[date].users.push({ ...account, shift });
                }
              }
            );
            return acc;
          }, {})
        ).map(([date, data]: [string, any]) => ({
          title: `W: ${data.working}, R: ${data.resting}, M: ${data.morning}, A: ${data.afternoon}`,
          start: date,
          // color: data.working > 0 ? "green" : "red",
          extendedProps: data, // Pasar detalles para interacción
        }));

        console.log("formattedEvents", formattedEvents);

        setDepartment(formattedAccounts);
        setEvents(formattedEvents);
      } catch (err) {
        console.error("Error fetching shift details:", err);
        setError("No se pudieron cargar los detalles del turno.");
      } finally {
        setLoading(false);
      }
    };

    fetchCalendarView();
  }, [depID]);

  const handleDayClick = (info: any) => {
    // Mostrar detalle del día
    const clickedDay = events.find(
      (event: any) => event.start === info.dateStr
    )?.extendedProps;
    setDayDetails(clickedDay || null);
  };

  if (loading) return <div>Cargando...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="container">
      {noCalendarUsers.length > 0 && !dayDetails ? (
        <div>
          <h3>Usuarios sin calendario asignado</h3>

          <ul>
            {noCalendarUsers.map((user) => (
              <li key={user.id}>
                {user.name} - {user.email}
              </li>
            ))}
          </ul>
        </div>
      ) : (
        ""
      )}

      {dayDetails && (
        <div className="card">
          <div
            className="card-header"
            style={{ display: "flex", justifyContent: "space-between" }}
          >
            <h4>Detalles del Día: {dayDetails.date}</h4>
            <div style={{ display: "flex", gap: "1rem", alignItems: "center" }}>
              <i className="fas fa-print"></i>
              <i
                className="fas fa-times"
                onClick={() => setDayDetails(null)}
              ></i>
            </div>
          </div>

          <h4>Trabajando:</h4>
          <ul>
            {dayDetails.users
              .filter((user: any) => user.shift.work)
              .map((user: any) => (
                <li key={user.id}>
                  {user.name} - {user.shift.startwork} a {user.shift.endwork}
                </li>
              ))}
          </ul>
          <h4>Descansando:</h4>
          <ul>
            {dayDetails.users
              .filter((user: any) => !user.shift.work)
              .map((user: any) => (
                <li key={user.id}>
                  {user.name} - {user.shift.motive || "Descanso"}
                </li>
              ))}
          </ul>
        </div>
      )}

      <FullCalendar
        plugins={[dayGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        showNonCurrentDates={false}
        headerToolbar={{
          left: "prev,next",
          center: "title",
          right: "dayGridMonth",
        }}
        events={events}
        editable={true}
        dateClick={handleDayClick}
        locale="es"
        aspectRatio={2}
      />
    </div>
  );
};

export default CalendarView;

/*
import React from 'react'
import {
  EventApi,
  DateSelectArg,
  EventClickArg,
  EventContentArg,
  formatDate,
} from '@fullcalendar/core'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import { INITIAL_EVENTS, createEventId } from './event-utils'

interface DemoAppState {
  weekendsVisible: boolean
  currentEvents: EventApi[]
}

export default class DemoApp extends React.Component<{}, DemoAppState> {

  state: DemoAppState = {
    weekendsVisible: true,
    currentEvents: []
  }

  render() {
    return (
      <div className='demo-app'>
        {this.renderSidebar()}
        <div className='demo-app-main'>
          <FullCalendar
            plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
            headerToolbar={{
              left: 'prev,next today',
              center: 'title',
              right: 'dayGridMonth,timeGridWeek,timeGridDay'
            }}
            initialView='dayGridMonth'
            editable={true}
            selectable={true}
            selectMirror={true}
            dayMaxEvents={true}
            weekends={this.state.weekendsVisible}
            initialEvents={INITIAL_EVENTS} // alternatively, use the `events` setting to fetch from a feed
            select={this.handleDateSelect}
            eventContent={renderEventContent} // custom render function
            eventClick={this.handleEventClick}
            eventsSet={this.handleEvents} // called after events are initialized/added/changed/removed
            // you can update a remote database when these fire:
            //eventAdd={function(){}}
            //eventChange={function(){}}
            //eventRemove={function(){}}
            
            />
            </div>
          </div>
        )
      }
    
      renderSidebar() {
        return (
          <div className='demo-app-sidebar'>
            <div className='demo-app-sidebar-section'>
              <h2>Instructions</h2>
              <ul>
                <li>Select dates and you will be prompted to create a new event</li>
                <li>Drag, drop, and resize events</li>
                <li>Click an event to delete it</li>
              </ul>
            </div>
            <div className='demo-app-sidebar-section'>
              <label>
                <input
                  type='checkbox'
                  checked={this.state.weekendsVisible}
                  onChange={this.handleWeekendsToggle}
                ></input>
                toggle weekends
              </label>
            </div>
            <div className='demo-app-sidebar-section'>
              <h2>All Events ({this.state.currentEvents.length})</h2>
              <ul>
                {this.state.currentEvents.map(renderSidebarEvent)}
              </ul>
            </div>
          </div>
        )
      }
    
      handleWeekendsToggle = () => {
        this.setState({
          weekendsVisible: !this.state.weekendsVisible
        })
      }
    
      handleDateSelect = (selectInfo: DateSelectArg) => {
        let title = prompt('Please enter a new title for your event')
        let calendarApi = selectInfo.view.calendar
    
        calendarApi.unselect() // clear date selection
    
        if (title) {
          calendarApi.addEvent({
            id: createEventId(),
            title,
            start: selectInfo.startStr,
            end: selectInfo.endStr,
            allDay: selectInfo.allDay
          })
        }
      }
    
      handleEventClick = (clickInfo: EventClickArg) => {
        if (confirm(`Are you sure you want to delete the event '${clickInfo.event.title}'`)) {
          clickInfo.event.remove()
        }
      }
    
      handleEvents = (events: EventApi[]) => {
        this.setState({
          currentEvents: events
        })
      }
    
    }
    
    function renderEventContent(eventContent: EventContentArg) {
      return (
        <>
          <b>{eventContent.timeText}</b>
          <i>{eventContent.event.title}</i>
        </>
      )
    }
    
    function renderSidebarEvent(event: EventApi) {
      return (
        <li key={event.id}>
          <b>{formatDate(event.start!, {year: 'numeric', month: 'short', day: 'numeric'})}</b>
          <i>{event.title}</i>
        </li>
      )
    }
*/
