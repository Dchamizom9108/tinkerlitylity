import React, { useState, useEffect } from "react";
import { GETMyselfUserData } from "@app/services/rh";
import moment from "moment";
import styled from "@emotion/styled";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMinus, faTimes } from "@fortawesome/free-solid-svg-icons";
import { faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons';
import DatePicker from "react-datepicker";
import Swal from "sweetalert2";

import styles from "./assistancesTable.module.css";
import "react-datepicker/dist/react-datepicker.css";

import { DepartmentsType, UserRh } from "@app/types";

interface UserCardProps {
  title: string;
  users: UserRh[]; // Un array de usuarios
  badgeColor: string;
}

interface UserLogoProps {
  id: number;
  name: string;
}

interface Column {
  field: string;
  headerName: string;
  width: number;
  renderCell?: (params: { row: Record<string, any> }) => React.ReactNode;
}

interface TableProps {
  columns: Column[];
  data: Record<string, any>[];
  onRowClick?: (id: string | number) => void;
}

interface SearchFilterProps {
  searchTerm: string;
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

interface ExpandButtonProps {
  isExpanded: boolean;
  onClick: () => void;
}

interface CustomDatePickerProps {
  selectedDate: Date | null;
  onChange: (date: Date | null) => void;
}

const StyledLogo = styled.div`
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  color: white;
  font-size: 16px;
  font-weight: 600;
  background-color: #009fdb;
  background: linear-gradient(45deg, rgb(21 87 205) 0%, rgb(90 225 255) 100%);
  margin-bottom: 5px;
`;

const DepartmentHeader = styled.div`
  cursor: pointer;
  font-weight: bold;
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  border-radius: 6px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: background-color 0.3s, box-shadow 0.3s;

  &:hover {
    background-color: #d8e2eb;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
    color: #333;
  }
`;

const UsersList = styled.ul`
  list-style: none;
  padding: 10px 0 0;
  margin: 0;
  display: flex;
  flex-wrap: wrap;
  gap: 25px;
  justify-content: center;
`;

const UserListItem = styled.li`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  width: 60px;
`;

export const UserList = ({ users }: { users: UserRh[] }) => {
  const [expandedDepartments, setExpandedDepartments] = useState<string[]>([]);

  // Agrupar usuarios por departamento
  const groupByDepartment = (users: UserRh[]) => {
    return users.reduce((acc, user) => {
      const department = user.department || "Sin Departamento";
      if (!acc[department]) {
        acc[department] = [];
      }
      acc[department].push(user);
      return acc;
    }, {} as Record<string, UserRh[]>);
  };

  const groupedUsers = groupByDepartment(users);

  // Alternar expansión de un departamento
  const toggleDepartment = (department: string) => {
    setExpandedDepartments((prev) =>
      prev.includes(department)
        ? prev.filter((dep) => dep !== department)
        : [...prev, department]
    );
  };

  return (
    <div className="card-body p-0 dchm-card">
      {Object.entries(groupedUsers).map(([department, users]) => (
        <div key={department} style={{ marginBottom: "15px" }}>
          {/* Encabezado del Departamento */}
          <DepartmentHeader onClick={() => toggleDepartment(department)}>
            <span>
              {department} ({users.length})
            </span>
            <span>{expandedDepartments.includes(department) ? "▲" : "▼"}</span>
          </DepartmentHeader>

          {/* Lista de Usuarios */}
          {expandedDepartments.includes(department) && (
            <UsersList>
              {users.map((user) => {
                const fullName = `${user.firstName} ${user.lastName}`;
                const names = fullName.split(" ");
                const firstTwoNames = names.slice(0, 1).join(" ");
                const firstLetter = names[0].charAt(0);
                const secondLetter = names.length > 1 ? names[1].charAt(0) : "";
                const initials = firstLetter + secondLetter;

                return (
                  <UserListItem key={user.userId}>
                    <StyledLogo>{initials}</StyledLogo>
                    <a
                      className="users-list-name"
                      href={`/users/${user.userId}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {firstTwoNames}
                    </a>
                  </UserListItem>
                );
              })}
            </UsersList>
          )}
        </div>
      ))}
    </div>
  );
};

export const UserLogo = ({ id, name } : UserLogoProps) => {
  const initials = name.split(' ').map((word) => word.charAt(0)).join('');

  const handleClick = () => {
    window.location.replace(`/users/${id}`);
  };

  return (
    <li
      style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}
    >
      <StyledLogo>{initials}</StyledLogo>
      <a className="users-list-name" onClick={handleClick}>
        {name}
      </a>
    </li>
  );
};

export const UserCard = ({ title, users, badgeColor }: UserCardProps) => {
  return (
    <div className={`col-md-6`}>
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">{title}</h3>
          <div className="card-tools">
            <span className={`badge badge-${badgeColor}`}>
              {users?.length} Users
            </span>
            <button
              type="button"
              className="btn btn-tool"
              data-card-widget="collapse"
            >
              <FontAwesomeIcon icon={faMinus} />
            </button>
            <button
              type="button"
              className="btn btn-tool"
              data-card-widget="remove"
            >
              <FontAwesomeIcon icon={faTimes} />
            </button>
          </div>
        </div>

        <UserList users={users} />

        <div className="card-footer text-center">
          <a href="">View All Users</a>
        </div>
      </div>
    </div>
  );
};

export const Table: React.FC<TableProps> = ({ columns, data, onRowClick = () => {} }) => {
  return (
    <table className="table table-striped">
      <thead>
        <tr>
          {columns.map((col) => (
            <th key={col.field} style={{ width: col.width }}>
              {col.headerName}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {data.map((row) => (
          <tr
            key={row.id}
            className={row.status === "Late" ? styles.lateRow : ""}
            onClick={() => onRowClick(row.id)}
          >
            {columns.map((col) => (
              <td key={col.field}>
                {col.field === "expand" && col.renderCell
                  ? col.renderCell({ row })
                  : row[col.field]}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export const SearchFilter: React.FC<SearchFilterProps> = ({ searchTerm, onChange }) => {
  return (
    <input
      type="text"
      placeholder="Search by name"
      className={`form-control ${styles.searchInput}`}
      value={searchTerm}
      onChange={onChange}
    />
  );
};

export const ExpandButton = ({ isExpanded, onClick } : ExpandButtonProps) => {
  return (
    <button className="btn btn-link p-0" onClick={onClick}>
      <FontAwesomeIcon icon={isExpanded ? faChevronLeft : faChevronRight} />
    </button>
  );
};

export const CustomDatePicker: React.FC<CustomDatePickerProps> = ({ selectedDate, onChange }) => {
  return (
    <DatePicker
      selected={selectedDate}
      onChange={onChange}
      className={styles.datePicker}
      minDate={new Date("2024-07-01")}
    />
  );
};

export const ShowAlert = (
  icon: "success" | "error" | "warning" | "info" | "question", 
  title: string, 
  text: string, 
  showCancelButton: boolean = false, 
  confirmButtonText: string = "OK"
) => {
  return Swal.fire({
    icon,
    title,
    text,
    showCancelButton,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText,
  });
};

/*  /////////////////////////////////////////////////////////////////////////////////////////////////////// */
/* /////////////////////////////////////////// DepartmentFilter /////////////////////////////////////////// */
/* /////////////////////////////////////////////////////////////////////////////////////////////////////// */


interface DropDownFilterProps {
  filterChange: (filter: any) => void;
  options: DepartmentsType[];
  filter: any;
  className: string;
}

export function DepartmentFilter({ filterChange, options, filter, className }: DropDownFilterProps) {
  const [option, setOption] = React.useState("");

  React.useEffect(() => {
    if (!filter) {
      setOption("");
    }
  }, [filter]);

  const onChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setOption(e.target.value);
    return  e.target.value
  };

  return (
    <>
      <select
        className={"custom-select ml-4 " + className}
        onChange={(e) => filterChange(onChange(e))}
        value={option}
      >
        {options.map((option, i) => {
          return (
            <option key={i} value={option.id}>
              {option.name}
            </option>
          );
        })}
      </select>
    </>
  );
}

/*  /////////////////////////////////////////////////////////////////////////////////////////////////////// */
/* /////////////////////////////////////////// DepartmentFilter /////////////////////////////////////////// */
/* /////////////////////////////////////////////////////////////////////////////////////////////////////// */

export const Timeline = () => {
  const [userData, setUserData] = useState<any | null>(null);
  const [currentWeek, setCurrentWeek] = useState<moment.Moment>(moment().startOf("isoWeek")); // Lunes como inicio
  const [load, setLoad] = useState(false);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const userData = await GETMyselfUserData();
        setUserData(userData);
      } catch (error) {
        console.error(error);
      }
    };

    if (!load) {
      fetchUserData();
      setLoad(true);
    }
  }, [load]);

  const getWeekData = () => {
    if (!userData?.asignedCalendar) return [];

    const startOfWeek = currentWeek.clone().startOf("isoWeek");
    const endOfWeek = currentWeek.clone().endOf("isoWeek");

    return Object.entries(userData.asignedCalendar).filter(([date]) => {
      const day = moment(date);
      return day.isBetween(startOfWeek, endOfWeek, undefined, "[]");
    });
  };

  const weekData = getWeekData();

  const handlePreviousWeek = () => {
    setCurrentWeek((prev) => prev.clone().subtract(1, "week"));
  };

  const handleNextWeek = () => {
    setCurrentWeek((prev) => prev.clone().add(1, "week"));
  };

  return (
    <div style={{
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      color: "white",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <button className="btn btn-primary" onClick={handlePreviousWeek}>
          &lt; Previous
        </button>
        <span style={{ fontWeight: "bold" }}>
          {currentWeek.format("MMMM D, YYYY")} -{" "}
          {currentWeek.clone().endOf("isoWeek").format("MMMM D, YYYY")}
        </span>
        <button className="btn btn-primary" onClick={handleNextWeek}>
          Next &gt;
        </button>
      </div>

      <div style={{ 
          display: "flex",
          flexDirection: "row",
          flexWrap: "wrap",
          alignItems: "flex-start",
          gap: "10px",
      }}>
        {weekData.length > 0 ? (
          weekData.map(([date, details]: [string, any]) => (
            <div key={date} className={`timeline-day_dchm ${details.work ? "work-day" : "day-off"}`}>
              <div className="time-label">
                <span>{moment(date).format("dddd, D MMM. YYYY")}</span>
              </div>
              <div className="timeline-content">
                <i className={`icon fas fa-${details.work ? "check" : "times"}`} />
                <div className="timeline-item">
                  {details.work ? (
                    <>
                      <span className="time">
                        <i className="far fa-clock" /> {details.startwork?.slice(0, 2) + " " + details.startwork?.slice(9, 11)} - {details.endwork?.slice(0, 2) + " " + details.endwork?.slice(9, 11)}
                      </span>
                      <h5>Work Day</h5>
                    </>
                  ) : (
                    <h3>Day Off</h3>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="no-data">No data available for this week.</div>
        )}
      </div>
    </div>
  );
};

