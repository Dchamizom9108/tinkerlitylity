import Swal from "sweetalert2";
const ShowAlert = (
  icon: "success" | "error" | "warning" | "info" | "question", 
  title: string, 
  text: string, 
  showCancelButton: boolean = false, 
  confirmButtonText: string = "OK"
) => {
  return Swal.fire({
    icon,
    title,
    text,
    showCancelButton,
    confirmButtonColor: "#3085d6",
    cancelButtonColor: "#d33",
    confirmButtonText,
  });
};

export default ShowAlert