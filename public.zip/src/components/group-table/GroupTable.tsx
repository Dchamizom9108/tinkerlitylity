export interface GroupTableProps {
  groups: Array<string>;
  tableName: string;
  tableColor: string;
}

const GroupsTable = (props: GroupTableProps) => {
  return (
    <>
      <table className="table">
        <thead>
          <tr className={props.tableColor}>
            <th className="col-sm-5">{props.tableName}</th>
          </tr>
        </thead>
        <tbody>
          {props.groups.map((val, key) => {
            return (
              <tr key={key}>
                <td>{val}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </>
  );
}

export default GroupsTable;
