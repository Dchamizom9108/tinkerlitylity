var express = require('express');
var router = express.Router();

const qManager = require('../bots/tcx/qManager.js')

/* GET API */
router.get('/', function(req, res, next) {
  res.send('Welcome to the Epower Solutions Bots API please enter an Entry Point to get some results');
});
/*
router.post('/tcx-user-out-of-queue', async function(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  const ext = await qManager.disableUsers(req.body.parameters);
  res.end(JSON.stringify({ request: ext }));
});

router.post('/tcx-user-add-to-queue', async function(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  const ext = await qManager.enableUsers(req.body.parameters);
  res.end(JSON.stringify({ request: ext }));
});
*/
module.exports = router;
