var express = require('express');
var router = express.Router();
const sendEmail = require('../bots/email/sendEmail.js')
const emailService = require('../bots/email/emailService.js')
const rhEmailService = require('../bots/email/rhEmailService.js')

/* GET API */
router.get('/', function(req, res, next) {
  res.send('Welcome to the Epower Solutions Bots API please enter an Entry Point to get some results');
});

router.post('/sendEmail', async function(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  console.log(req.body);
  const dataFromUser = await sendEmail.add(req.body)
  res.end(JSON.stringify({ request: dataFromUser }));
});


/* POST API */
router.post('/emailService', async function(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  console.log(req.body);
  const emailData = await emailService.sendEmail(req.body)
  res.end(JSON.stringify({ request: emailData }));
});

/* POST API */
router.post('/rhEmailService', async function(req, res, next) {
  res.setHeader('Content-Type', 'application/json');
  const emailData = await rhEmailService.add(req.body)
  res.end(JSON.stringify({ request: emailData }));
});


module.exports = router;
