const fs = require('fs');


// Nuevo valor de token aleatorio
const newToken = Math.random().toString(10).substring(2, 15) + Math.random().toString(10).substring(2, 15);

// Guardar el nuevo token en un archivo
fs.writeFileSync('./tokenGen.json', JSON.stringify({ token: newToken }));