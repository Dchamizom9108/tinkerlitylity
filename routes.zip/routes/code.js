const express = require("express");
const router = express.Router();
const fs = require("fs");

const apiToken =
  "b2ea302026b21c00384902e9ffadff9c8fdeabcd8d317996ce7bdd8571b5147fd02faec162ce22a3b443e6f0b1383d116a30823c4042a14a1299125e9ca525348f678e26e4afabf47e11937b3f6291b301a5f1ad7619239de1867d35f0fdc6887b7f8557e89facec25ce65fa1553c7bf434dc26cf01c598bd59f641912a6684a"; // Tu palabra clave

// b2ea302026b21c00384902e9ffadff9c8fdeabcd8d317996ce7bdd8571b5147fd02faec162ce22a3b443e6f0b1383d116a30823c4042a14a1299125e9ca525348f678e26e4afabf47e11937b3f6291b301a5f1ad7619239de1867d35f0fdc6887b7f8557e89facec25ce65fa1553c7bf434dc26cf01c598bd59f641912a6684a
// Función para generar una clave a partir de la palabra clave

/* GET API */
router.get("/", function (req, res, next) {
  res.send(
    "Welcome to the Epower Solutions API please enter an Entry Point to get some results"
  );
});

router.get("/encrypted-token", (req, res) => {
  fs.readFile("./tokenGen.json", "utf8", (err, data) => {
    if (err) {
      return res.status(500).json({ error: "Failed to read token file" });
    }
    const secretKey = JSON.parse(data).token;
    console.log('from file', secretKey);
    res.json({ encryptedToken: secretKey });
  });
});

// Endpoint para desencriptar el código
router.post('/encrypted-token', (req, res) => {
  const { encryptedCode } = req.body;
  console.log('from api'. encryptedCode);
  const secretKey = require("./tokenGen.json").token;
  console.log('from file', secretKey);
  if (encryptedCode !== secretKey) {
    return res.status(400).json({ error: 'Invalid token' });
  } 
  res.json({ apiToken });
});

module.exports = router;
