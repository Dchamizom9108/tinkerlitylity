const express = require('express')
const app = express()
const port = 3000
const httpServer = require('http').Server(app);
const request = require('request');
const cors = require('cors')
const axios = require('axios');
const session = require('express-session');

const apiRouter = require('./routes/api');
const tcxRouter = require('./routes/tcx');
const codeRouter = require('./routes/code');


app.use(cors())
app.use(express.json()) // for parsing application/json
app.use(express.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded

app.use(session({
  secret: 'inilnomine',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Note: a secure cookie requires an HTTPS connection
}));

const io = require('socket.io')(httpServer, 
{
  cors: {
    origin: ["https://sugar.consumerlaw.com", "https://reports.consumerlaw.com","https://consumerlaw.my3cx.us","https://justicialaboral.my3cx.us","https://scoreboard.consumerlaw.com", "https://www.consumerlaw.com", "https://itback.consumerlaw.com",],
    methods: ["GET", "POST"]
  }
}
);

io.on('connection', (socket) => {
  socket.on('number dialed', (msg) => {
        io.emit('number dialed', msg);
        console.log('message: ' + msg.id);
  });
});

app.get('/', function(req, res) {
  res.sendFile('index.html', {root: __dirname });
});

app.use('/api', apiRouter);

//app.use('/tcx', tcxRouter);

app.use('/code', codeRouter)

app.post('/proxy', async (req, res) => {
  let data = JSON.stringify({
    "parameters": req.body.parameters
  });
  
  let config = {
    method: 'post',
    maxBodyLength: Infinity,
    url: req.body.url,
    headers: { 
      'Content-Type': 'application/json',
    },
    data : data
  };

  axios.request(config)
  .then((response) => {
    res.json(response.data);
  })
  .catch((error) => {
    res.json(error);
  });
});

app.post('/proxy_sugar_data', async (req, res) => {

  console.log('request: ', req.body)
  let data = JSON.stringify({
    "parameters": req.body.parameters
  });
  
  let config = {
    method: 'post',
    maxBodyLength: Infinity,
    url: req.body.url,
    headers: { 
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${req.body.token}` // Pass the token in the header
    },
    data : data
  };

  axios.request(config)
  .then((response) => {
    res.json(response.data);
  })
  .catch((error) => {
    res.json(error);
  });
});

app.post('/proxy_post', async (req, res) => {
    let data = JSON.stringify({
      "parameters": req.body.parameters
    });
    
    let config = {
      method: 'post',
      maxBodyLength: Infinity,
      url: req.body.url,
      headers: { 
        'Content-Type': 'application/json'
      },
      data : data
    };

    axios.request(config)
    .then((response) => {
      res.json(response.data);
    })
    .catch((error) => {
      res.json(error);
    });
});

// Create a function to save the token
app.post('/proxy_sugar_token', async (req, res) => {
  console.log('request: ', req.body)
  let data = JSON.stringify({
    "password": req.body.password,
    "username": req.body.username,
    "client_secret": "",
    "client_id": "sugar",
    "grant_type": "password"
  });

  let config = {
    method: 'post',
    url: 'https://sugar.consumerlaw.com/rest/v11/oauth2/token',
    headers: {
      'Content-Type': 'application/json'
    },
    data : data
  };

  try {
    const response = await axios.request(config);
    console.log(response.data.access_token);
    res.json(response.data.access_token);
  } catch (error) {
    console.log(error);
  }
});


// Return client IP address
app.get('/ip', (req, res) => {
  console.log(req.ip);
  res.json(req.ip);
});

httpServer.listen(port, () => {
  console.log('go to http://localhost:3000');
});

