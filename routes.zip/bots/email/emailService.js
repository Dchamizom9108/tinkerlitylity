const nodemailer = require('nodemailer');

module.exports = {
  sendEmail: async (data) => {
    const transporter = nodemailer.createTransport({
      host: "smtp.office365.com",
      port: 587,
      secure: false,
      auth: {
        user: "support@consumerlaw.com",
        pass: "9OIgzAU0fplr",
      },
    });
    try {

      const createOptionsToMail = {
        from: "support@consumerlaw.com",
        to: data.recipients,
        subject: data.subject,
        html: data.emailBody,
      };

      // Send the email
      transporter.sendMail(createOptionsToMail, (error, info) => {
        if (error) {
          console.error(error);
        } else {
          console.log("Email sent: " + info.response);
        }
      });

      return `Email sent successfully to ${data.recipients}`;
    } catch (error) {
      console.error(error);
      return "error";
    }
  }
}