const nodemailer = require("nodemailer");

module.exports.add = async function (userData) {
  console.log(userData);
  // Create a Nodemailer transporter object
  const transporter = nodemailer.createTransport({
    host: "smtp.office365.com",
    port: 587,
    secure: false,
    auth: {
      user: "clg.notifications@consumerlaw.com",
      pass: "qzwvbcqjmhfngxtd",
    },
  });



  const userId = userData.body.userId || "";
  const userName = userData.body.userName || "";
  const userEmail = userData.body.userEmail || "";
  const userRole = userData.body.userRole || "";
  const userLogType = userData.body.logType || "";

  const action = userData.body.action || "";
  const manualMessage = userData.body.manual || "";

  const waittingCalls = userData.body.waittingCalls || 0;
  const servicedCalls = userData.body.servicedCalls || 0;
  const listOfUsers = userData.body.listOfUsers || [];

  const htmlBodyLate = `
    <html>
    <head>
      <style>
        .container {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          padding: 20px;
          border: 1px solid #ddd;
          border-radius: 10px;
          max-width: 600px;
          margin: auto;
        }
        .header {
          text-align: center;
          padding-bottom: 20px;
        }
        .header h1 {
          margin: 0;
          font-size: 24px;
          color: #0056b3;
        }
        .content {
          padding: 20px 0;
        }
        .footer {
          text-align: center;
          padding-top: 20px;
          font-size: 12px;
          color: #777;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Notificación de Tardanza en el Registro</h1>
        </div>
        <div class="content">
          <p>Estimado(a) Usuario(a),</p>
          <p>Lamentamos informarle que su registro <strong>${userLogType}</strong> está experimentando una tardanza.</p>
          <p>Por favor comunicarse con su supervisor.</p>
          <p>Atentamente,</p>
          <p>El Equipo de Consumer Law</p>
        </div>
        <div class="footer">
          <p>Este es un correo generado automáticamente, por favor no responda a este mensaje.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  const htmlBodyMissing = `
  <html>
  <head>
    <style>
      .container {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        color: #333;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 10px;
        max-width: 600px;
        margin: auto;
      }
      .header {
        text-align: center;
        padding-bottom: 20px;
      }
      .header h1 {
        margin: 0;
        font-size: 24px;
        color: #0056b3;
      }
      .content {
        padding: 20px 0;
      }
      .footer {
        text-align: center;
        padding-top: 20px;
        font-size: 12px;
        color: #777;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <div class="header">
        <h1>Notificación de Tardanza en el Registro</h1>
      </div>
      <div class="content">
        <p>Estimado(a) Usuario(a),</p>
        <p>Lamentamos informarle que su registro <strong>${userLogType}</strong> no se encuentra en nuestro sistema.</p>
        <p>Por favor contacte con su supervisor para la correspondiente aclaracion.</p>
        <p>Atentamente,</p>
        <p>El Equipo de Consumer Law</p>
      </div>
      <div class="footer">
        <p>Este es un correo generado automáticamente, por favor no responda a este mensaje.</p>
      </div>
    </div>
  </body>
  </html>
`;

  const htmlBodyPersonalized = `
  <html>
  <head>
    <style>
      .container {
        font-family: Arial, sans-serif;
        line-height: 1.6;
        color: #333;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 10px;
        max-width: 600px;
        margin: auto;
      }
      .header {
        text-align: center;
        padding-bottom: 20px;
      }
      .header h1 {
        margin: 0;
        font-size: 24px;
        color: #0056b3;
      }
      .content {
        padding: 20px 0;
      }
      .footer {
        text-align: center;
        padding-top: 20px;
        font-size: 12px;
        color: #777;
      }
    </style>
  </head>
  <body>
    <div class="container">
      ${manualMessage}
    </div>
  </body>
  </html>
  `;

  const htmlBodyLegalQ = `
    <html>
    <head>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
        }
        .container {
          margin: 20px;
        }
        .highlight {
          font-weight: bold;
          color: #ff0000;
        }
        .highlighgreen {
          color: green;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <p>Todos los agentes disponibles, por favor conéctense a la Q.</p>
        <p>Tenemos <span class="highlight">${waittingCalls}</span> llamadas en espera:</p>
        <ul>
          ${listOfUsers.map(user => `<li>${user}</li>`).join('')}
        </ul>
        <p>Gracias.</p>
        <p><span class="highlightgreen">${servicedCalls}</span> llamadas ya han sido atendidas.</p>
      </div>
    </body>
    </html>
  `;

  let body = "";

  switch (action) {
    case "late":
      body = htmlBodyLate;
      console.log("late");
      break;
    case "missing":
      body = htmlBodyMissing;
      console.log("missing");
      break;
    case "personalized":
      body = htmlBodyPersonalized;
      console.log("personalized");
      break;
    case "legalQ":
      body = htmlBodyLegalQ;
      console.log("legalQ");
      break;
    default:
      break;
  }

  const mailOptions = {
    from: "clg.notifications@consumerlaw.com",
    to: `${userData.emailTo}`,
    subject: `${userData.subject}`,
    html: body,
  };

  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });

  return "todo completo ok";
  // })();
};
