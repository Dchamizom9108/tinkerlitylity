const nodemailer = require("nodemailer");

module.exports.add = async function (userData) {
  // Create a Nodemailer transporter object
  const transporter = nodemailer.createTransport({
    host: "smtp.office365.com",
    port: 587,
    secure: false,
    auth: {
      user: "clg.notifications@consumerlaw.com",
      pass: "qzwvbcqjmhfngxtd",
    },
  });

  console.log(userData);


  // Format departments if exist an array on userData.departments
  let formattedDepartments = "";
  if (userData.departments.length > 0) {
    userData.departments.forEach((department) => {
      formattedDepartments += department + "<br> ";
    });
  }

  let mailOptions = {};

  if (userData.actionToExecute === "Modify") {
    mailOptions = {
      from: "clg.notifications@consumerlaw.com",
      to: "dchamizo@consumerlaw.com, helpdesk@consumerlaw.com",
      subject: `Modify User ${userData.firstName}`,
      html: `<br> <br> 
          The user <strong>${
            userData.whoSendModification
          }</strong> has send a request to modify the user <strong>${
        userData.firstName
      } ${userData.lastName}</strong> <br> <br> 
          This is the request: <br> <br> 
          Job Title: ${userData.jobTitle} <br> <br> 
          Departments: <br> <br> 
          ${formattedDepartments} <br> <br> 
          Aditional Notes: ${userData.notes} <br> <br> 
          This should be done on this date: ${userData.effectiveDate.split("T")[0]}  <br> <br> 
          User Portal: <a href="https://users.consumerlaw.com/users/${
            userData.strappiUserId
          }" target="_blank">Users</a> <br> <br>  
          `,
    };
  } else if (userData.actionToExecute === "Deactivate") {
    mailOptions = {
      from: "clg.notifications@consumerlaw.com",
      to: "dchamizo@consumerlaw.com, helpdesk@consumerlaw.com",
      subject: `Deactivate User ${userData.firstName}`,
      html: `<br> <br> 
          The user <strong>${
            userData.whoSendModification
          }</strong> has send a request to Deactivate the user <strong>${
        userData.firstName
      } ${userData.lastName}</strong> <br> <br> 
          Aditional Notes: ${userData.deactNotes} <br> <br> 
          This should be done on this date: ${userData.deactDate.split("T")[0]}  <br> <br> 
          User Portal: <a href="https://users.consumerlaw.com/users/${
            userData.strappiUserId
          }" target="_blank">Users</a> <br> <br> 
          `,
    };
  } else if (userData.actionToExecute === "Suspend") {
    mailOptions = {
      from: "clg.notifications@consumerlaw.com",
      to: "dchamizo@consumerlaw.com, helpdesk@consumerlaw.com",
      subject: `Suspend User ${userData.firstName}`,
      html: `<br> <br> 
          The user <strong>${
            userData.whoSendModification
          }</strong> has send a request to Suspend the user <strong>${
        userData.firstName
      } ${userData.lastName}</strong> <br> <br> 
          Notes: ${userData.deactNotes} <br> <br>
          This should be done on this date: ${ userData.deactDate.split("T")[0]
          }  <br> <br> 
          User Portal: <a href="https://users.consumerlaw.com/users/${userData.strappiUserId}" target="_blank">Users</a> <br> <br> 
  `,
    };
  } else if (userData.actionToExecute === "Create") {
    mailOptions = {
      from: "clg.notifications@consumerlaw.com",
      to: "dchamizo@consumerlaw.com, helpdesk@consumerlaw.com",
      subject: `New User ${userData.firstName}`,
      html: `<br> <br> 
          The user <strong>${
            userData.whoSendModification
          }</strong> has send a request to create the user <strong>${
        userData.firstName
      } ${userData.lastName}</strong> <br> <br> 
          This is the request: <br> <br> 
          Job Title: ${userData.jobTitle} <br> <br> 
          Aditional Notes: ${userData.notes} <br> <br> 
          This user start date: ${userData.effectiveDate.split("T")[0]}  <br> <br> 
          User Portal: <a href="https://users.consumerlaw.com/users/${
            userData.strappiUserId
          }" target="_blank">Users</a> <br> <br> 
          <br> <br> 
          `,
    };
  }


  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });

  return "todo completo ok";
  // })();
};
