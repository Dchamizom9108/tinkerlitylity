const puppeteer = require("puppeteer");

module.exports.add = async function (activeExtension) {
  // (async () => {
  // const browser= await puppeteer.launch({headless: false, args: ['--no-sandbox', '--start-maximized', '--download.default_directory=./tmp/']/* , slowMo: 50*/, defaultViewport: null});
  const browser = await puppeteer.launch({
    headless: false,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage();
  await page.goto("https://consumerlaw.my3cx.us/#/app/queues");
  await page.type('input[id="loginInput"]', "666");
  await page.type('input[id="passwordInput"]', "@dm1nB0t23");
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  const [button] = await page.$x(
    "/html/body/modal-container/div[2]/div/ng-component/div[1]/button"
  );
  if (button) {
    await button.click();
  }
  await page.click('a[id="menuSwitchboard"]');
  await page.click('button[id="button-alignment"]');
  // Encontrar el enlace con el texto "Queue"
  const [queue] = await page.$x("//a[contains(., '806 Test IT')]");
  if (queue) {
    await queue.click();
  }

  const extensions = await page.$$("li.queue-tile");

  // activeExtension is expected to be an array with the extension that should be active in the queue,
  // this is a parameter receive in the function
  const activeUser = activeExtension;

  const liArray = await Promise.all(
    extensions.map(async (li) => {
      const phone = await li.$('span[data-id="extPhone"]');
      const linkTextE = await li.$("span.status u");
      const link = await li.$("span.status a");
      const ext = await phone.evaluate((node) => node.innerText);
      const linkText = await linkTextE.evaluate((node) => node.innerText);
      // const linkText = await link.evaluate(node => console.log(node));
      return { ext, linkText, link };
    })
  );
  for (let i = 0; i < liArray.length; i++) {
    await new Promise((r) => setTimeout(r, 500));
    if (activeUser.includes(liArray[i].ext)) {
      if (liArray[i].linkText == "Logged out") {
        // console.log(liArray[i].ext, liArray[i].linkText, "a")
        liArray[i].link.click();
      }
    } else {
      if (liArray[i].linkText == "Logged in") {
        // console.log(liArray[i].ext, liArray[i].linkText, "b")
        liArray[i].link.click();
      }
    }
  }

  await new Promise((r) => setTimeout(r, 500));
  await browser.close();

  return "Todo completo ok";
  // })();
};
