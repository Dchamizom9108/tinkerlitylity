const puppeteer = require("puppeteer");

// module.exports.add = async function (activeExtension) {
// console.log("active extension", activeExtension);
(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ["--no-sandbox"],
  });

  const page = await browser.newPage();
  await page.goto("https://consumerlaw.my3cx.us/#/app/queues");
  await page.type('input[ng-model="$ctrl.user.username"]', "666");
  await page.type('input[type="password"]', "@dm1nB0t23");
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: "networkidle0" }),
  ]);

  const sample2 = 192;
  const bucket1 = await setOutForQueue(904, sample2);
  const bucket2 = await setOutForQueue(905, sample2);
  async function setOutForQueue(queueNumber, extensionsArray) {
    await new Promise((r) => setTimeout(r, 1000));
    const searchBar = await page.$("input[id='inputSearch']");
    await searchBar.focus();
    await page.keyboard.type(queueNumber.toString());
    await new Promise((r) => setTimeout(r, 500));
    const selectReport = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/list-control/div/div/div[2]/div/div[3]/table/tbody/tr/td[1]'
    );
    await selectReport[0].click();
    await new Promise((r) => setTimeout(r, 250));
    const editButton = await page.$("button[id='btnEdit']");
    await editButton.click();
    await new Promise((r) => setTimeout(r, 500));
    const agentsTab = await page.$x(
      '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/ul/li[2]'
    );
    await agentsTab[0].click();
    await new Promise((r) => setTimeout(r, 500));
    const addUsers = await page.$("button#btnAdd");
    await addUsers.click();
    const searchUser = await page.$("input[ng-model='$ctrl.search']");
    await searchUser.focus();
    await new Promise((r) => setTimeout(r, 250));
    await searchUser.type(extensionsArray.toString());
    await new Promise((r) => setTimeout(r, 650));
    const selectUser = await page.$x( "/html/body/div[1]/div/div/select-extensions-modal/div[2]/div/table/tbody/tr/td[2]" );
    if (selectUser.length > 0) {
      await selectUser[0].click();
    } else {
      console.error("No se encontró ninguna celda con el valor 904.");
    }
    const okListButton = await page.$( "button[translate='REPOS.BUTTONS.OK_BTN']" );
    await okListButton.click();
    await new Promise((r) => setTimeout(r, 500));
    const okButton = await page.$("button[id='btnSave']");
    await okButton.click();
  }
  await browser.close();
  return "success";

})();

// };
