const puppeteer = require("puppeteer");

module.exports = {
  disableUsers: async (params) => {
    try {
      const browser = await puppeteer.launch({
        headless: 'new',
        args: ["--no-sandbox"],
        executablePath: "/usr/bin/chromium-browser",
      });
      const page = await browser.newPage();
      await page.goto("https://consumerlaw.my3cx.us/#/app/queues");
      await page.type('input[ng-model="$ctrl.user.username"]', "666");
      await page.type('input[type="password"]', "@dm1nB0t23");
      await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: "networkidle0" }),
      ]);
      // const bucket1 = await setOutForQueue(904, extension);
      const bucket = await setOutForQueue(params.qNumber, params.extension);
      async function setOutForQueue(queueNumber, extensionsArray) {
        await new Promise((r) => setTimeout(r, 1000));
        const searchBar = await page.$("input[id='inputSearch']");
        await searchBar.focus();
        await page.keyboard.type(queueNumber.toString());
        await new Promise((r) => setTimeout(r, 500));
        const selectReport = await page.$x('//*[@id="app-container"]/div[2]/div[2]/list-control/div/div/div[2]/div/div[3]/table/tbody/tr/td[1]');
        await selectReport[0].click();
        await new Promise((r) => setTimeout(r, 250));
        const editButton = await page.$("button[id='btnEdit']");
        await editButton.click();
        await new Promise((r) => setTimeout(r, 500));
        const agentsTab = await page.$x( '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/ul/li[2]' );
        await agentsTab[0].click();
        await new Promise((r) => setTimeout(r, 500));
        const searchUser = await page.$("input[ng-model='$ctrl.search']");
        await searchUser.focus();
        await new Promise((r) => setTimeout(r, 250));
        await searchUser.type(extensionsArray.toString());
        await new Promise((r) => setTimeout(r, 650));
        const selectUser = await page.$x('//*[@id="app-container"]/div[2]/div[2]/div/div[2]/form/div/ui-view/div/div[2]/mc-extensions/div/div[2]/table/tbody/tr/td[2]');
        if (selectUser.length > 0) {
          await selectUser[0].click();
          const deleteButton = await page.$("button#btnDelete");
          await deleteButton.click();
          await new Promise((r) => setTimeout(r, 500));
          const okButton = await page.$("button[id='btnSave']");
          await okButton.click();

          await new Promise((r) => setTimeout(r, 500));

          return "success";
        } else {
          console.error(`No se encontró la ext ${extensionsArray} en el queue ${queueNumber}`);
          const cancelButton = await page.$( "button[id='btnCancel']" );
          await cancelButton.click();

          return "error";
        }
      }
      await browser.close();
      return bucket;
    } catch (error) {
      console.error(error);
      return "error"
    }
  },

  enableUsers: async (params) => {
    try {
      const browser = await puppeteer.launch({
        headless: 'new',
        args: ["--no-sandbox"],
        executablePath: "/usr/bin/chromium-browser",
      });
    
      const page = await browser.newPage();
      await page.goto("https://consumerlaw.my3cx.us/#/app/queues");
      await page.type('input[ng-model="$ctrl.user.username"]', "666");
      await page.type('input[type="password"]', "@dm1nB0t23");
      await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: "networkidle0" }),
      ]);
      // const bucket1 = await setOutForQueue(904, extension);
      const bucket = await setOutForQueue(params.qNumber, params.extension);
      async function setOutForQueue(queueNumber, extensionsArray) {
        await new Promise((r) => setTimeout(r, 1000));
        const searchBar = await page.$("input[id='inputSearch']");
        await searchBar.focus();
        await page.keyboard.type(queueNumber.toString());
        await new Promise((r) => setTimeout(r, 500));
        const selectReport = await page.$x(
          '//*[@id="app-container"]/div[2]/div[2]/list-control/div/div/div[2]/div/div[3]/table/tbody/tr/td[1]'
        );
        await selectReport[0].click();
        await new Promise((r) => setTimeout(r, 250));
        const editButton = await page.$("button[id='btnEdit']");
        await editButton.click();
        await new Promise((r) => setTimeout(r, 500));
        const agentsTab = await page.$x(
          '//*[@id="app-container"]/div[2]/div[2]/div/div[2]/ul/li[2]'
        );
        await agentsTab[0].click();
        await new Promise((r) => setTimeout(r, 500));
        const addUsers = await page.$("button#btnAdd");
        await addUsers.click();
        const searchUser = await page.$("input[ng-model='$ctrl.search']");
        await searchUser.focus();
        await new Promise((r) => setTimeout(r, 250));
        await searchUser.type(extensionsArray);
        await new Promise((r) => setTimeout(r, 650));
        const selectUser = await page.$x( "/html/body/div[1]/div/div/select-extensions-modal/div[2]/div/table/tbody/tr/td[2]" );
        if (selectUser.length > 0) {
          await selectUser[0].click();
          const okListButton = await page.$( "button[translate='REPOS.BUTTONS.OK_BTN']" );
          await okListButton.click();
          await new Promise((r) => setTimeout(r, 500));
          const okButton = await page.$("button[id='btnSave']");
          await okButton.click();

          await new Promise((r) => setTimeout(r, 500));

          return "success";
        } else {
          console.error(`No se encontró la ext ${extensionsArray} en el queue ${queueNumber}`);
          const cancelListButton = await page.$( "button[translate='REPOS.BUTTONS.CANCEL_BTN']" );
          await cancelListButton.click();
          await new Promise((r) => setTimeout(r, 500));
          const cancelButton = await page.$( "button[id='btnCancel']" );
          await cancelButton.click();

          return "error";

        }
      }
      await browser.close();
      return bucket;
    } catch (error) {
      console.error(error);
      return "error"
    }
  }
}