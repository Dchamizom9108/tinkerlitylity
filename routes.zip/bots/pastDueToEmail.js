const puppeteer = require('puppeteer');
const nodemailer = require('nodemailer');

module.exports.Screenshot = async (data) => {
  // console.log(data)
  const url = decodeURIComponent(data.url);
  const element = data.div;
  const email = data.email;
  const browser = await puppeteer.launch({headless: true, args: ['--no-sandbox']});
  const page = await browser.newPage();

  // Create a Nodemailer transporter object
  const transporter = nodemailer.createTransport({
    host: 'smtp.office365.com',
    port: 587,
    secure: false,
    auth: {
      user: 'support@consumerlaw.com',
      pass: '9OIgzAU0fplr'
    }
  });

  await page.goto(`${url}`);

  // Get the dimensions and position of the div you want to screenshot
  await new Promise(r => setTimeout(r, 10000));
  const divSelector = `${element}`;
  const divHandle = await page.$(divSelector);
  const { x, y, width, height } = await divHandle.boundingBox();

  // Take a screenshot of the div
  await page.screenshot({
    path: './public/images/screenshot.png',
    clip: { x, y, width, height }
  });

  await browser.close();

  // Define the email options
  const mailOptions = {
    from: 'support@consumerlaw.com',
    to: `${email}`,
    subject: 'Test email from node',
    text: 'Here is the report',
    html: `<img src="cid:image"><br>`,
    attachments: [{
      filename: 'screenshot.png',
      path: './public/images/screenshot.png',
      cid: 'image'
    }]
  };
  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
};
