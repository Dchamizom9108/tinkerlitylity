module.exports = {
  senIP: async (data) => {
  }
}