const puppeteer = require('puppeteer');
const nodemailer = require('nodemailer');
const axios = require('axios');

module.exports.run = async () => {
    var config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'https://itback.consumerlaw.com/api/report-scheduleds/',
        headers: { }
      };
      
      axios(config)
      .then(function (response) {

        console.log(JSON.parse(JSON.stringify(response.data.data)));
        // response.data.map(el => {
        //     console.log(el)
        // })
      })
      .catch(function (error) {
        console.log(error);
      });
    return "123";
};
