const puppeteer = require('puppeteer');
const nodemailer = require('nodemailer');
const fs = require('fs');

/*
const fs = require('fs');
const path = require('path');

const directorio = './';
const archivoMantener = 'p1Teams.fs';

fs.readdir(directorio, (error, archivos) => {
  if (error) {
    console.error(error);
    return;
  }

  archivos.forEach((archivo) => {
    // Verificar si el archivo actual es diferente al archivo que se desea mantener
    if (archivo !== archivoMantener) {
      // Eliminar el archivo
      fs.unlink(path.join(directorio, archivo), (error) => {
        if (error) {
          console.error(error);
          return;
        }
        console.log(`El archivo ${archivo} ha sido eliminado exitosamente`);
      });
    }
  });
});
*/

(async () => {
  const browser = await puppeteer.launch({headless: true, args: ['--no-sandbox']});
  const page = await browser.newPage();

  // Create a Nodemailer transporter object
  const transporter = nodemailer.createTransport({
    host: 'smtp.office365.com',
    port: 587,
    secure: false,
    auth: {
      user: 'support@consumerlaw.com',
      pass: '9OIgzAU0fplr'
    }
  });

  function randomName(cantC) {
    const caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const resultado = Array.from({length: cantC}, () => {
      return caracteres.charAt(Math.floor(Math.random() * caracteres.length));
    }).join('');
    return resultado;
  }
  const filename = randomName(10);  
  
  await page.goto('https://home.justicialaboral.com/bot_db/');

  // Get the dimensions and position of the div you want to screenshot
  await new Promise(r => setTimeout(r, 5000));
  const divSelector = '.tabulator';
  const divHandle = await page.$(divSelector);
  const { x, y, width, height } = await divHandle.boundingBox();

  // Take a screenshot of the div
  await page.screenshot({
    path: `./${filename}.png`,
    clip: { x, y, width, height }
  });

  await browser.close();

  // Define the email options
  const mailOptions = {
    from: 'support@consumerlaw.com',
    to: 'support@consumerlaw.com',
    subject: 'P1 - API Report',
    html: `<br><img src="https://home.justicialaboral.com/bot_db/p1Report/${filename}.png">`,
  };
  // Send the email
  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
})();